.. _static:

******
STATIC
******

:abbr:`STATIC` is a daemon that handles the installation and deletion
of static routes.

.. _starting-static:

Starting STATIC
===============

Default configuration file for *staticd* is :file:`staticd.conf`.  The typical
location of :file:`staticd.conf` is |INSTALL_PREFIX_ETC|/staticd.conf.

If the user is using integrated config, then :file:`staticd.conf` need not be
present and the :file:`frr.conf` is read instead.

If the user has not fully upgraded to using the staticd.conf and still has
a non-integrated config with zebra.conf holding the static routes, *staticd*
will read in the :file:`zebrad.conf` as a backup.

.. program:: staticd

:abbr:`STATIC` supports all the common FRR daemon start options which are
documented elsewhere.

.. _static-route-commands:

Static Route Commands
=====================

Static routing is a very fundamental feature of routing technology. It defines
a static prefix and gateway.

.. index:: ip route NETWORK GATEWAY table TABLENO nexthop-vrf VRFNAME DISTANCE vrf VRFNAME
.. clicmd:: ip route NETWORK GATEWAY table TABLENO nexthop-vrf VRFNAME DISTANCE vrf VRFNAME

.. index:: ipv6 route NETWORK from SRCPREFIX GATEWAY table TABLENO nexthop-vrf VRFNAME DISTANCE vrf VRFNAME
.. clicmd:: ipv6 route NETWORK from SRCPREFIX GATEWAY table TABLENO nexthop-vrf VRFNAME DISTANCE vrf VRFNAME

   NETWORK is destination prefix with a valid v4 or v6 network based upon
   initial form of the command.  GATEWAY is gateway for the prefix it currently
   must match the v4 or v6 route type specified at the start of the command.
   GATEWAY can also be treated as an interface name. If the interface name
   is ``null0`` then zebra installs a blackhole route.  TABLENO
   is an optional parameter for namespaces that allows you to create the
   route in a specified table associated with the vrf namespace. table will
   be rejected if you are not using namespace based vrfs.  ``nexthop-vrf``
   allows you to create a leaked route with a nexthop in the specified VRFNAME
   vrf VRFNAME allows you to create the route in a specified vrf.
   ``nexthop-vrf`` cannot be currently used with namespace based vrfs
   currently as well.
   The v6 variant allows the installation of a static source-specific route
   with the SRCPREFIX sub command.  These routes are currently supported
   on Linux operating systems only, and perform AND matching on packet's
   destination and source addresses in the kernel's forwarding path. Note
   that destination longest-prefix match is "more important" than source
   LPM, e.g.  ``2001:db8:1::/64 from 2001:db8::/48`` will win over
   ``2001:db8::/48 from 2001:db8:1::/64`` if both match.

.. _multiple-route-command:

Multiple nexthop static route
=============================

To create multiple nexthops to the same NETWORK, just reenter the same
network statement with different nexthop information.

.. code-block:: frr

   ip route 10.0.0.1/32 10.0.0.2
   ip route 10.0.0.1/32 10.0.0.3
   ip route 10.0.0.1/32 eth0


If there is no route to 10.0.0.2 and 10.0.0.3, and interface eth0
is reachable, then the last route is installed into the kernel.

If zebra has been compiled with multipath support, and both 10.0.0.2 and
10.0.0.3 are reachable, zebra will install a multipath route via both
nexthops, if the platform supports this.

::

   router> show ip route
   S>  10.0.0.1/32 [1/0] via 10.0.0.2 inactive
       via 10.0.0.3 inactive
     *       is directly connected, eth0


.. code-block:: frr

   ip route 10.0.0.0/8 10.0.0.2
   ip route 10.0.0.0/8 10.0.0.3
   ip route 10.0.0.0/8 null0 255


This will install a multihop route via the specified next-hops if they are
reachable, as well as a high-distance blackhole route, which can be useful to
prevent traffic destined for a prefix to match less-specific routes (e.g.
default) should the specified gateways not be reachable. E.g.:

::

   router> show ip route 10.0.0.0/8
   Routing entry for 10.0.0.0/8
     Known via "static", distance 1, metric 0
       10.0.0.2 inactive
       10.0.0.3 inactive

   Routing entry for 10.0.0.0/8
     Known via "static", distance 255, metric 0
       directly connected, Null0

Also, if the user wants to configure a static route for a specific VRF, then
a specific VRF configuration mode is available. After entering into that mode
with :clicmd:`vrf VRF` the user can enter the same route command as before,
but this time, the route command will apply to the VRF.

.. code-block:: frr

   # case with VRF
   configure
   vrf r1-cust1
    ip route 10.0.0.0/24 10.0.0.2
   exit-vrf


SR-TE Route Commands
====================

It is possible to specify a route using a SR-TE policy configured in Zebra.

e.g. to use the SR-TE policy with endpoint 6.6.6.6 and color 123 to reach the
network 9.9.9.9/24:

.. code-block:: frr

  ip route 9.9.9.9/24 6.6.6.6 color 123
