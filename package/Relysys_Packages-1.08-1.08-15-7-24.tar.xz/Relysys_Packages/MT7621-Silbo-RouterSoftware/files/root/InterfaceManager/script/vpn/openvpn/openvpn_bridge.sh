#!/bin/sh

. /lib/functions.sh

OpenvpnUCIPath=/etc/config/openvpn

EnableOpenvpn=$(uci get vpnconfig1.general.enableopenvpngeneral)

#DeletetheBridge
uci delete network.SW_LAN.type
uci set network.SW_LAN.ifname='eth0.1'

uci commit network

# restart the SW_LAN
ubus call network reload '{"config": "SW_LAN", "apply": true}'

ReadOpenvpnUCIConfig() {
    config_load "$OpenvpnUCIPath"
    config_foreach OpenvpnConfigParameters openvpn1
}

OpenvpnConfigParameters() {
    local OpenvpnConfigSection="$1"
    config_get Name "$OpenvpnConfigSection" name
    config_get Enable "$OpenvpnConfigSection" enable
    config_get Mode "$OpenvpnConfigSection" mode
    config_get Bridge "$OpenvpnConfigSection" bridge

    #Check the generalopenvpn && Opnvpn Enable
    if [ "$Enable" = "1" ] && [ "$EnableOpenvpn" = "1" ]; then

        if [ "$Mode" = "TUN" ]; then

            if [ "$Bridge" == "1" ]; then
                uci set openvpn.$Name.bridge="0"
                uci commit openvpn
            fi
        fi

        if [ "$Mode" = "TAP" ]; then

            if [ "$Bridge" == "1" ]; then

                uci set network.SW_LAN.type='bridge'
                uci set network.SW_LAN.ifname="eth0.1 tap_$Name"

                uci commit network

                # restart the SW_LAN
                ubus call network reload '{"config": "SW_LAN", "apply": true}'
            else
                uci delete network.SW_LAN.type
                uci set network.SW_LAN.ifname='eth0.1'

                uci commit network

                # restart the SW_LAN
                ubus call network reload '{"config": "SW_LAN", "apply": true}'
            fi
        fi
    else
        uci delete network.SW_LAN.type
        uci set network.SW_LAN.ifname='eth0.1'

        uci commit network

        # restart the SW_LAN
        ubus call network reload '{"config": "SW_LAN", "apply": true}'
    fi

}

ReadOpenvpnUCIConfig
