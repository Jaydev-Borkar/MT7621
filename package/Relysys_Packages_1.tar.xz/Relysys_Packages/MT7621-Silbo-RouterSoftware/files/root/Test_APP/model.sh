#!bin/bash

MODEL=$1
sed -i '/model/d' ./device_test_config.cfg
echo model=\"$1\" >> ./device_test_config.cfg
