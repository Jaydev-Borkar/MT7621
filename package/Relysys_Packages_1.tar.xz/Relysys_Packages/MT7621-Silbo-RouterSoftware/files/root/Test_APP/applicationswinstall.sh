#!/bin/sh

Module="$1"
SWversion="$2"

Hostnm=$(uci get system.system.ipkname)
EnableWifi=$(uci get system.system.enablewifi)
EnableGps=$(uci get system.system.enablegps)

if [ "$Module" = "1" ] || [ "$Module" = "2" ]
then
response=$(opkg remove BasicRouterSoftware)
sleep 5
	if [ "$EnableWifi" = "0" ]
	then
		Opkginstalloutput=$(opkg --force-overwrite install "/root/Test_APP/${Hostnm}_RouterSoftwareEC200T_"$SWversion"_mipsel_24kc.ipk" 2>&1)
		OpkginstalloutputVal=$?
	else
		Opkginstalloutput=$(opkg --force-overwrite install "/root/Test_APP/${Hostnm}_RouterSoftwareEC200T_WIFI_"$SWversion"_mipsel_24kc.ipk" 2>&1)
		OpkginstalloutputVal=$?
	fi
	if [ "$OpkginstalloutputVal" != 0 ]
	then
	echo 0 > /root/Test_APP/opkresult.txt
	else
	echo 1 > /root/Test_APP/opkresult.txt
	fi 
elif [ "$Module" = "3" ] || [ "$Module" = "4" ]
then
	response=$(opkg remove BasicRouterSoftware)
	sleep 5
	if [ "$EnableGps" = "0" ] || [ "$EnableWifi" = "0" ] 
	then
	Opkginstalloutput=$(opkg --force-overwrite install "/root/Test_APP/${Hostnm}_RouterSoftwareEC20_"$SWversion"_mipsel_24kc.ipk" 2>&1)
	OpkginstalloutputVal=$?
	elif [ "$EnableGps" = "1" ] || [ "$EnableWifi" = "0" ]
	then
	Opkginstalloutput=$(opkg --force-overwrite install "/root/Test_APP/${Hostnm}_RouterSoftwareEC20_GPS_"$SWversion"_mipsel_24kc.ipk" 2>&1)
	OpkginstalloutputVal=$?
	elif [ "$EnableGps" = "0" ] || [ "$EnableWifi" = "1" ]
	then
	Opkginstalloutput=$(opkg --force-overwrite install "/root/Test_APP/${Hostnm}_RouterSoftwareEC20_WIFI_"$SWversion"_mipsel_24kc.ipk" 2>&1)
	OpkginstalloutputVal=$?
	else
	Opkginstalloutput=$(opkg --force-overwrite install "/root/Test_APP/${Hostnm}_RouterSoftwareEC20_GPS_WIFI_"$SWversion"_mipsel_24kc.ipk" 2>&1)
	OpkginstalloutputVal=$?
	fi
	if [ "$OpkginstalloutputVal" != 0 ]
	then
	echo 0 > /root/Test_APP/opkresult.txt
	else
	echo 1 > /root/Test_APP/opkresult.txt
	fi 
elif [ "$Module" = "6" ] || [ "$Module" = "7" ]
then
   response=$(opkg remove BasicRouterSoftware)
   sleep 5
	if [ "$EnableWifi" = "0" ]
	then
		Opkginstalloutput=$(opkg --force-overwrite install "/root/Test_APP/${Hostnm}_RouterSoftwareEC25E_"$SWversion"_mipsel_24kc.ipk" 2>&1)
		OpkginstalloutputVal=$?
	else
		Opkginstalloutput=$(opkg --force-overwrite install "/root/Test_APP/${Hostnm}_RouterSoftwareEC25E_WIFI_"$SWversion"_mipsel_24kc.ipk" 2>&1)
		OpkginstalloutputVal=$?
	fi
	if [ "$OpkginstalloutputVal" != 0 ]
	then
	echo 0 > /root/Test_APP/opkresult.txt
	else
	echo 1 > /root/Test_APP/opkresult.txt
	fi 
elif [ "$Module" = "8" ] || [ "$Module" = "9" ]
then
   response=$(opkg remove BasicRouterSoftware)
   sleep 5
	if [ "$EnableWifi" = "0" ]
	then
		Opkginstalloutput=$(opkg --force-overwrite install "/root/Test_APP/${Hostnm}_RouterSoftwareEC200A_"$SWversion"_mipsel_24kc.ipk" 2>&1)
		OpkginstalloutputVal=$?
	else
		Opkginstalloutput=$(opkg --force-overwrite install "/root/Test_APP/${Hostnm}_RouterSoftwareEC200A_WIFI_"$SWversion"_mipsel_24kc.ipk" 2>&1)
		OpkginstalloutputVal=$?
	fi
	if [ "$OpkginstalloutputVal" != 0 ]
	then
	echo 0 > /root/Test_APP/opkresult.txt
	else
	echo 1 > /root/Test_APP/opkresult.txt
	fi 
else
echo "Unknown Module Type"
echo 0 > /root/Test_APP/opkresult.txt
fi
