#!bin/sh

. /lib/functions.sh

MACID="$1"
MACID1="$2"
MACID2="$3"
MACID3="$4"

Port2lanInterfaceName="SW_LAN"
Port5lanInterfaceName="EWAN2"

uci set networkold."${Port2lanInterfaceName}".macaddr="$MACID"
uci set networkold."${Port5lanInterfaceName}".macaddr="$MACID1"
uci set sysconfig.sysconfig.swlanmacid="$MACID"
uci set sysconfig.sysconfig.port5macid="$MACID1"

uci commit networkold	
uci commit sysconfig	
