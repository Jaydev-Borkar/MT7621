#!/bin/sh

atcsqtest=$(gcom -d /dev/ttyUSB1 -s /root/Test_APP/atcsq_test.gcom | awk 'NR==2' | cut -d ":" -f 2 | cut -d "," -f 1 | tr -d '\011\012\013\014\015\040')

echo "$atcsqtest" > /root/Test_APP/signalstrength.txt
