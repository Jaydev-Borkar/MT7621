#!/bin/sh

. /lib/functions.sh

MACID=$(uci get boardconfig.board.macid)
MACID1=$(uci get boardconfig.board.macid1)
MACID2=$(uci get boardconfig.board.macid2)
MACID3=$(uci get boardconfig.board.macid3)
Serialnum=$(uci get boardconfig.board.serialnum)

swlaninterface="SW_LAN"
ethwan2interface="EWAN2"
wifiinetrface="WIFI"

uci set network."${swlaninterface}".macaddr="$MACID"
uci set network."${ethwan2interface}".macaddr="$MACID1"
uci set wireless.ap.macaddr="$MACID2"
uci set wireless.sta.macaddr="$MACID3"
uci set sysconfig.sysconfig.wifi1ssid="Penguin_G300_$Serialnum"

uci set sysconfig.sysconfig.swlanmacid="$MACID"
uci set sysconfig.sysconfig.port5macid="$MACID1"


uci commit sysconfig

uci set siaserverconfig.siaserverconfig.serialnum="$Serialnum"
uci set boardconfigfile.boardconfigfile.serialnum="$Serialnum"
uci set system.system.hostname="$Serialnum" 
uci set wireless.ap.ssid="Penguin_G300_$Serialnum"

uci commit wireless
uci commit boardconfigfile

uci commit network

uci commit siaserverconfig	

uci commit system
uci commit wireless

rm /root/Test_APP/RouterSoftware*.ipk
