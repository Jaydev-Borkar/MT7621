#!bin/sh

ifconfig eth0.5 | grep 'inet addr:' | cut -d: -f2 | awk '{ print $1}' > wanip.txt
