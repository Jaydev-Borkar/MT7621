#!/bin/sh

ModuleType="$1"

GPSGcomScript="/root/Test_APP/enablegps.gcom"

if [ "$ModuleType" = 7 ] || [ "$ModuleType" = 8 ]
then
/usr/bin/gcom -d /dev/ttyUSB2 -s "$GPSGcomScript"
fi
