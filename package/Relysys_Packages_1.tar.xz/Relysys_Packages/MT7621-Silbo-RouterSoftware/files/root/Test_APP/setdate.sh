#!/bin/sh
#
#

date="$1"
year=$(echo $date | cut -d "/" -f 1)
time=$(echo $date | cut -d "/" -f 2)

date -s "$year $time"

hwclock -w --localtime
