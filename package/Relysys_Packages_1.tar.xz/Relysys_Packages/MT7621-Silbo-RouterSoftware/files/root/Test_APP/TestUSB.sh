#!/bin/sh

VendorId="$1"
ProductId="$2"

ReadVendorId=$(cat /sys/devices/platform/101c0000.ehci/usb1/1-1/idVendor)
ReadProductId=$(cat /sys/devices/platform/101c0000.ehci/usb1/1-1/idProduct)

if [ "$VendorId" = "$ReadVendorId" ]
then
	if [ "$ProductId" = "$ReadProductId" ]
	then
	   echo 1 > /root/Test_APP/usbid.txt
	else
	   echo 0 > /root/Test_APP/usbid.txt
	fi
else
  echo 0 > /root/Test_APP/usbid.txt
fi
