#!/bin/bash
#CurrentDateTime=$(TZ='Africa/accra' date | awk '{print $2,$3,$4,$6}')
#echo $CurrentDateTime
#epochdatetime=$(date --date '$CurrentDateTime' +%s)
#echo $epochdatetime

datetime2=$1
echo "$datetime2"
datetime1=$(TZ='Asia/Kolkata' date | awk '{print $2,$3,$4,$6}')
temp=$(date -d "$datetime1" +%Y%m%d%H%M%S)
temp2=$(date -d "$datetime2" +%Y%m%d%H%M%S)
echo $temp2
echo $temp
difftime=$((temp - temp2))
difftime2=$((temp2 - temp))
if [ "$difftime" -le 0 ]
then 
	echo "$difftime2" > "RTCTestPCResult.txt"
else
	echo "$difftime" > "RTCTestPCResult.txt"
fi
