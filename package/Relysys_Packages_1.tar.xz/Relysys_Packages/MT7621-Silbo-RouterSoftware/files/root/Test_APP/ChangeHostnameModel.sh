#!/bin/sh
. /usr/share/libubox/jshn.sh
. /lib/functions.sh

Replacehostname="$1"
Replacemodel=\"$2\"

uci set system.system.hostname="$Replacehostname"
uci commit system
hostnamefile="/www/luci2.html"
hostname=$(grep -w "title" /www/luci2.html | cut -d ">" -f 2 | cut -d "<" -f 1)
sed -i "s/${hostname}/${Replacehostname}/" ${hostnamefile}


modelfile="/www/luci2/view/status.overview.js"
model=$(grep -w "Model" /www/luci2/view/status.overview.js | awk '{ print $3}')
sed -i "s/${model}/${Replacemodel}/" ${modelfile}		                        		                        


exit 0
