#!/bin/sh

#~ IMEINUM=$(sudo gcom -d /dev/ttyUSB1 -s /root/atgsn_test.gcom | awk 'NR==2' | tr -d '\011\012\013\014\015\040')
#~ 
#~ if [ ${#IMEINUM} -eq 15 ]
#~ then
#~ echo 1 > /root/imeinum.txt
#~ else
#~ echo 0 > /root/imeinum.txt
#~ fi


atnetworkinfo1=$(gcom -d /dev/ttyUSB1 -s /root/Test_APP/atnetworkinfo1.gcom | awk 'NR==2')
atnetworklatchinfo=$(echo "$atnetworkinfo1" | cut -d ":" -f 2 | cut -d "," -f 4 | tr -d '\011\012\013\014\015\040')

if [ $atnetworklatchinfo -gt 0 ] && [ $atnetworklatchinfo -lt 8 ]
then
echo "$atnetworkinfo1" > /root/Test_APP/connectionstatus.txt
echo 1 > /root/Test_APP/networklatch.txt
else
echo 0 > /root/Test_APP/networklatch.txt
fi

