#!/bin/sh

ReAPMqttHost="localhost"
ReAPMqttPort="1883"
ReAPMqttQos="1"
ReAPMqttDEVICETESTSubTopic="TESTRTCRESP"

#Start of the script

#/reap/ProductionTest/scripts/ntpsync start


RTCDATE=$(hwclock -r | awk '{print $2,$3,$4,$5}')

ReAPMqttMsg="$RTCDATE"

mosquitto_pub -h "$ReAPMqttHost" -p "$ReAPMqttPort" -t "$ReAPMqttDEVICETESTSubTopic" -q "$ReAPMqttQos" -m "$ReAPMqttMsg"
