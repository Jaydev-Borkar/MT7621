#!/bin/sh

rs485=$1

if [ "$rs485" = "1" ]
then
   echo "00000" > /dev/ttyS1
   sleep 1
   echo "00000" > /dev/ttyS1
   sleep 1 
   echo "00000" > /dev/ttyS1                          
   sleep 1 
   echo "00000" > /dev/ttyS1
else
   echo "00000" > /dev/ttyS2                       
   sleep 1                                         
   echo "00000" > /dev/ttyS2                       
   sleep 1                                         
   echo "00000" > /dev/ttyS2                       
   sleep 1                                         
   echo "00000" > /dev/ttyS2 
fi
