#!/bin/sh


pingresult=$(ping -c 4 192.168.1.1 | grep -i "packet loss" | cut -d , -f 3 | cut -d % -f 1 | tr -d '\011\012\013\014\015\040')

echo "$pingresult" > /root/Test_APP/port1pingres.txt
