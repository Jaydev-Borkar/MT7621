#!/bin/sh

atqccidtest=$(gcom -d /dev/ttyUSB1 -s /root/Test_APP/atqccid_test.gcom | awk 'NR==2' | cut -d ":" -f 2 | tr -d '\011\012\013\014\015\040')

#~ if [ ${#atqccidtest} -eq 20 ]
#~ then
echo "$atqccidtest" > /root/Test_APP/qccidsim.txt
#~ else
#~ echo "0" > /root/qccidsim.txt
#~ fi
