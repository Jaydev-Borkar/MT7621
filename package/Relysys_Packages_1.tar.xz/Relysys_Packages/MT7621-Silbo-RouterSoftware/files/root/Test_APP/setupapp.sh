 #!/bin/bash
 
echo "Testapp Setup Environment:START"

dpkg -s "mosquitto" >/dev/null 2>&1 

mosquitto_lib=$?


if [ $mosquitto_lib -eq 0 ];then

	
	setterm --foreground 2
        echo "mosquitto library is installed"

else

	setterm --foreground 1
	echo "mosquitto library is not installed"
	
	setterm --foreground 7
	echo "Installing mosquitto  Library"
        
	sudo apt-get install mosquitto
	sudo apt-get install mosquitto-clients
	
	dpkg -s "mosquitto" >/dev/null 2>&1
	
	mosquitto_lib=$?
	
	if [ $mosquitto_lib -eq 0 ];then

        setterm --foreground 2

	echo "mosquitto library is installed:SUCCESS"

	else

	setterm --foreground 1

	echo "mosquitto library is not installed : FAILURE"

	fi


fi



dpkg -s "libconfig-dev" >/dev/null 2>&1 

config_lib=$?


if [ $config_lib -eq 0 ];then
	
	setterm --foreground 2
        echo "Libconfig library is installed"

else

        setterm --foreground 1
	echo "libconfig library is not installed"
        echo "Installing the libconfig Library... "
	
	setterm --foreground 7
	sudo apt-get update
	sudo apt-get install libconfig-dev
	
	dpkg -s "libconfig-dev" >/dev/null 2>&1 
	config_lib=$?
       
	 if [ $config_lib -eq 0 ];then

	setterm --foreground 2

        echo "Libconfig library is installed:SUCCESS"

        else

	setterm --foreground 1

        echo "Libconfig library is not installed : FAILURE"

        fi
      

fi


	echo " Installing the system dependencies for the legato application "

	setterm --foreground 1

	echo " Please press ENTER when required "

	
	setterm --foreground 7


	sudo add-apt-repository ppa:openjdk-r/ppa -y

	sudo apt-get update -y


	sudo apt-get install openjdk-8-jre -y


	sudo update-alternatives --config java

 
	sudo apt-get install openjdk-8-jre libwebkitgtk-1.0-0 build-essential python-jinja2 ninja-build zip autoconf automake


	sudo apt-get install lib32z1 lib32ncurses5


	setterm --foreground 2


	echo " system dependencies for the legato application installed success "


	setterm --foreground 7


	cd ~/basu/ealarmGPS/mantestapp/programmingtool

	unzip devstudio-5.3-linux64.zip -d ~/basu/ealarmGPS/mantestapp/programmingtool
	

	setterm --foreground 1


	echo " Please refer the document for the complete set up of legato application "

setterm --foreground 7

echo "Testapp Setup Environment:END"
