#!bin/sh
#
#
datetime=$(date +%Y-%m-%d/%H:%M:%S)
sed -i '/date/d' ./device_test_config.cfg
echo date=\"$datetime\" >> ./device_test_config.cfg
