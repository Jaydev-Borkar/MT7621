#!/bin/sh

attest=$(gcom -d /dev/ttyUSB1 -s /root/Test_APP/at_test.gcom | awk 'NR==2' | tr -d '\011\012\013\014\015\040')

if [ "$attest" = "OK" ]
then
echo 1 > /root/Test_APP/attest.txt
else
echo 0 > /root/Test_APP/attest.txt
fi
