#!/bin/sh

threshold=$1

count=0
for i in 0 1 2 3
do
  atpingtest=$(gcom -d /dev/ttyUSB1 -s /root/Test_APP/atpingtest.gcom | awk 'NR==4' | cut -d ":" -f 2 | cut -d "," -f 1 | tr -d '\011\012\013\014\015\040') 
  if [ $atpingtest -eq 0 ]
  then
     count=$((count+1))
  fi
  sleep 1
done

if [ $count -ge $threshold ]
then
echo 1 > /root/Test_APP/pingtest.txt
else
echo 0 > /root/Test_APP/pingtest.txt
fi
