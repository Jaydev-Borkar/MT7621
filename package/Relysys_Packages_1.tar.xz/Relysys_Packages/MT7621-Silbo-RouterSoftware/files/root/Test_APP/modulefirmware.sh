#!/bin/sh

atitest=$(gcom -d /dev/ttyUSB1 -s /root/Test_APP/ati_test.gcom | awk 'NR==4' | cut -d ":" -f 2 | tr -d '\011\012\013\014\015\040')

echo "$atitest" > /root/Test_APP/firmwareversion.txt
