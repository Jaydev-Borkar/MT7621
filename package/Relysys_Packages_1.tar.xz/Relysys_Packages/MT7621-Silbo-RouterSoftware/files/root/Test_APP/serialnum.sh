#!/bin/sh

. /lib/functions.sh

sernum="$1"
pcbdesignnum="$2"
module4gtype="$3"
MACID="$4"
MACID1="$5"
MACID2="$6"
MACID3="$7"
firmwarever="$8"
applicationver="$9"


IMEI=$(gcom -d /dev/ttyUSB1 -s /root/Test_APP/atgsn_test.gcom | awk 'NR==2' | tr -d '\011\012\013\014\015\040')

uci set boardconfig.board.serialnum="$sernum"
uci set boardconfig.board.pcbnum="$pcbdesignnum"
uci set boardconfig.board.moduletype="$module4gtype"
uci set boardconfig.board.macid="$MACID"
uci set boardconfig.board.macid1="$MACID1"
uci set boardconfig.board.macid2="$MACID2"
uci set boardconfig.board.macid3="$MACID3"
uci set boardconfig.board.firmwareVer="$firmwarever"
uci set boardconfig.board.ApplicationSwVer="$applicationver"
uci set boardconfig.board.imei="$IMEI"

SetRawIp="/root/Test_APP/setrawip.gcom"

if [ "$module4gtype" = 1 ] || [ "$module4gtype" = 2 ] || [ "$module4gtype" = 8 ] || [ "$module4gtype" = 9 ]
then
/usr/bin/gcom -d /dev/ttyUSB1 -s "$SetRawIp"
fi

uci commit boardconfig	


