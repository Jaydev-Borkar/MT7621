#!/bin/sh

. /lib/functions.sh


########################################################################
#  Description:This script basically drives GPIO498 LOW for 5 seconds
#              before turning it HIGH again. This turns OFF the mini-PCIe 
#              2G/3G/4G modem in slot J5 (USB3) OFF for 5 seconds
########################################################################
ComPort="$1"
ReadSystemGpioFile()                               
{                                                    
        config_load "$SystemGpioConfig"              
        config_get Modem1PowerGpio gpio modem1powergpio
        config_get Modem1PowerOnValue gpio modem1poweronvalue
        config_get Modem1PowerOffValue gpio modem1poweroffvalue
}

SystemGpioConfig="/etc/config/systemgpio"

ReadSystemGpioFile

TmpSim1DataFile="/tmp/sim1data"
TmpSim2DataFile="/tmp/sim2data"
TmpSimDataFile="/tmp/simdata"

echo 0 > "$TmpSim1DataFile"
echo 0 > "$TmpSim2DataFile"
echo 0 > "$TmpSimDataFile"

status=$(/bin/at-cmd $ComPort at+qpowd)

if [ -z "$status" ]                                                                                                        
then                                                                                                                           
	echo "$Modem1PowerOffValue" > /sys/class/gpio/gpio$Modem1PowerGpio/value
	sleep 5
	echo "$Modem1PowerOnValue" > /sys/class/gpio/gpio$Modem1PowerGpio/value
fi

exit 0


