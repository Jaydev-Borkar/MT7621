#!/bin/sh

. /lib/functions.sh

uci set sysconfig.sysconfig.wifi1enable='1'
uci commit sysconfig

sleep 1
/bin/UpdateWanConfig.sh
