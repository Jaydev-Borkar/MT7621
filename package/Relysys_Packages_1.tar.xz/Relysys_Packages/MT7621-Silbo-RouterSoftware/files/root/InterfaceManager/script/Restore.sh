#!/bin/sh

. /lib/functions.sh

ReadSystemGpioFile()                               
{
	    config_load "$SystemGpioConfig"
	    config_get ProgramLed1Number gpio programled1number
        config_get ProgramLed1OnValue gpio programled1onvalue
		config_get SimSelectGpio gpio simselectgpio
		config_get Sim1SelectValue gpio sim1selectvalue
		config_get Modem1PowerGpio gpio modem1powergpio      
		config_get Modem1PowerOffValue gpio modem1poweroffvalue

}

pid=$(pgrep -f "/root/InterfaceManager/script/GPIO_Polling_nvp_int_wo_Print_w_script")
kill -TERM "$pid" > /dev/null 2>&1
sleep 1
kill -KILL "$pid" > /dev/null 2>&1

SystemGpioConfig="/etc/config/systemgpio"

ReadSystemGpioFile

echo "$ProgramLed1OnValue" > /sys/class/gpio/gpio$ProgramLed1Number/value

mwan3 stop

ipsec stop

uci set modem.CWAN1_0.modemenable="1"
uci set modem.CWAN1_0.modemenable="0"

uci commit modem

echo "$Modem1PowerOffValue" > /sys/class/gpio/gpio$Modem1PowerGpio/value

sleep 2

echo "$Sim1SelectValue" > /sys/class/gpio/gpio$SimSelectGpio/value

/root/InterfaceManager/script/InterfaceInitializer.sh stop

rm /tmp/simnumfile

cp /etc/config/boardconfig /root/

#cp /etc/config/openwisp /root/InterfaceManager/config

#cp /etc/config/openwisp-monitoring /root/InterfaceManager/config

rm -r /etc/config

cp -r /root/InterfaceManager/config /etc/

#############################################################################

cp /root/InterfaceManager/mt7628/mt7628.dat /etc/wireless/mt7628/mt7628.dat

#############################################################################
#mv /root/boardconfig /etc/config/

#MACID=$(uci get boardconfig.board.macid)
#MACID1=$(uci get boardconfig.board.macid1)
#MACID2=$(uci get boardconfig.board.macid2)
#Serialnum=$(uci get boardconfig.board.serialnum)

#swlaninterface="SW_LAN"
#ethwan2interface="EWAN2"
#wifiinetrface="WIFI"

#uci set network."${swlaninterface}".macaddr="$MACID"
#uci set network."${ethwan2interface}".macaddr="$MACID1"
#uci set network."${wifiinetrface}".macaddr="$MACID2"

#uci commit network

#uci set sysconfig.sysconfig.swlanmacid="$MACID"
#uci set sysconfig.sysconfig.port5macid="$MACID1"
#uci set sysconfig.sysconfig.wifi1ssid="Penguin_G300_$Serialnum"

#uci commit sysconfig

#uci set siaserverconfig.siaserverconfig.serialnum="$Serialnum"
#uci set boardconfigfile.boardconfigfile.serialnum="$Serialnum"
#uci set system.system.hostname="$Serialnum"
#uci set wireless.ap.ssid="Penguin_G300_$Serialnum"
#uci set nmsconfig.nmsconfig.nmsenable="0"

#uci commit nmsconfig
#uci commit system
#uci commit wireless
#uci commit boardconfigfile
#uci commit siaserverconfig
			
sleep 3

/root/usrRPC/script/Board_Recycle_12V_Script.sh

exit 0
