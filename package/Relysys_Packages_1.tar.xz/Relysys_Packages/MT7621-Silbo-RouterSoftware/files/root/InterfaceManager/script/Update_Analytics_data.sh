#!/bin/sh

. /lib/functions.sh

IMEI=$(uci get boardconfig.board.imei)

swlaninterface="SW_LAN"
lan1interface="LAN1"
lan2interface="LAN2"
lan3interface="LAN3"
lan4interface="LAN4"
ethwan1interface="EWAN1"
ethwan2interface="EWAN2"
cellularwan1interface="CWAN1"
cellularwan2interface="CWAN2"
cellularwan3interface="CWAN3"
cellularwan1sim1interface="CWAN1_0"
cellularwan1sim2interface="CWAN1_1"
wifiap="WIFI"
wifista="WIFI_WAN"

ReadSystemConfigFile()
{
   	config_load "$SystemConfigFile"
   	config_get CellularOperationModelocal sysconfig CellularOperationMode
   	config_get EnableCellular sysconfig enablecellular
}

SystemConfigFile="/etc/config/sysconfig"

ReadSystemConfigFile

if [ "$EnableCellular" = "1" ]
then
	if [ "$CellularOperationModelocal" = "dualcellularsinglesim" ]
	then
	
			  ComPort1=$(cat "/tmp/InterfaceManager/status/$cellularwan1interface.ports" | grep -iw "Comport" | cut -d "=" -f 2)
			  ComPort2=$(cat "/tmp/InterfaceManager/status/$cellularwan2interface.ports" | grep -iw "Comport" | cut -d "=" -f 2)
	     		
	elif [ "$CellularOperationModelocal" = "singlecellulardualsim" ]
	then
	  simnum=$(cat /tmp/simnumfile)                                                                                         
      if [ "$simnum" = "1" ]                                                                                                
      then
    
		        ComPort=$(cat "/tmp/InterfaceManager/status/$cellularwan1sim1interface.ports" | grep -iw "Comport" | cut -d "=" -f 2)
      else 
      
		       ComPort=$(cat "/tmp/InterfaceManager/status/$cellularwan1sim2interface.ports" | grep -iw "Comport" | cut -d "=" -f 2)     
	 fi 
	else

     ComPort=$(cat "/tmp/InterfaceManager/status/$cellularwan1interface.ports" | grep -iw "Comport" | cut -d "=" -f 2)
	fi
fi

Operator_Code=$(gcom -d "$ComPort" -s /etc/gcom/getcarrier.gcom | awk NR==2)

Operator=$(echo "$Operator_Code" | cut -d "," -f 2 | tr -d '\011\012\013\014\015\040')

Operator=$(echo "$Operator" | tr -d '"')

Quality_Signal_Noise=$(gcom -d "$ComPort" -s /etc/gcom/getquality.gcom | awk NR==2)

Connected=$(echo "$Quality_Signal_Noise" | cut -d "," -f 3 | tr -d '\011\012\013\014\015\040')


if [ "$Connected" = \""LTE"\" ]
then
 Connected=$(echo "$Connected" | tr -d '"')
 MODE=$(echo "$Quality_Signal_Noise" | cut -d "," -f 4 | tr -d '\011\012\013\014\015\040')
 MODE=$(echo "$MODE" | tr -d '"')
 MCC=$(echo "$Quality_Signal_Noise" | cut -d "," -f 5 | tr -d '\011\012\013\014\015\040')
 MNC=$(echo "$Quality_Signal_Noise" | cut -d "," -f 6 | tr -d '\011\012\013\014\015\040')
 LAC="-"
 CELLID=$(echo "$Quality_Signal_Noise" | cut -d "," -f 7 | tr -d '\011\012\013\014\015\040')
 BSIC=$(echo "$Quality_Signal_Noise" | cut -d "," -f 8 | tr -d '\011\012\013\014\015\040')
 ARFCN=$(echo "$Quality_Signal_Noise" | cut -d "," -f 9 | tr -d '\011\012\013\014\015\040')
 BAND=$(echo "$Quality_Signal_Noise" | cut -d "," -f 10 | tr -d '\011\012\013\014\015\040')
 ULBAND_VAL=$(echo "$Quality_Signal_Noise" | cut -d "," -f 11 | tr -d '\011\012\013\014\015\040')
 if [ "${ULBAND_VAL}" = "1" ]
 then
    ULBAND="3 MHz"
 elif [ "${ULBAND_VAL}" = "2" ]
 then
    ULBAND="5 MHz"
 elif [ "${ULBAND_VAL}" = "3" ]                                                                                                                
 then
    ULBAND="10 MHz"
 elif [ "${ULBAND_VAL}" = "4" ]                                                                                                                
 then 
    ULBAND="15 MHz"
 else
    ULBAND="20 MHz"
 fi 
 DLBAND_VAL=$(echo "$Quality_Signal_Noise" | cut -d "," -f 12 | tr -d '\011\012\013\014\015\040')
 if [ "${DLBAND_VAL}" = "1" ]                                                                    
 then                                                                                            
    DLBAND="3 MHz"                                                                               
 elif [ "${DLBAND_VAL}" = "2" ]                                                                  
 then                                                                                            
    DLBAND="5 MHz"                                                                                                                             
 elif [ "${DLBAND_VAL}" = "3" ]                                                                                                                
 then                                                                                                                                          
    DLBAND="10 MHz"                                                                                                                            
 elif [ "${DLBAND_VAL}" = "4" ]                                                                                                                
 then                                                                                                                                          
    DLBAND="15 MHz"                                                                                                                            
 else                                                                                                                                          
    DLBAND="20 MHz"                                                                                                                            
 fi 
 TAC=$(echo "$Quality_Signal_Noise" | cut -d "," -f 13 | tr -d '\011\012\013\014\015\040')
 RSRP=$(echo "$Quality_Signal_Noise" | cut -d "," -f 14 | tr -d '\011\012\013\014\015\040')
 RSRQ=$(echo "$Quality_Signal_Noise" | cut -d "," -f 15 | tr -d '\011\012\013\014\015\040')
 RSSI=$(echo "$Quality_Signal_Noise" | cut -d "," -f 16 | tr -d '\011\012\013\014\015\040')
 SINR=$(echo "$Quality_Signal_Noise" | cut -d "," -f 17 | tr -d '\011\012\013\014\015\040')
 echo "$Operator,$Connected,$MODE,$MCC,$MNC,$LAC,$CELLID,$BSIC,$ARFCN,$BAND,$ULBAND,$DLBAND,$TAC,$RSRP,$RSRQ,$RSSI,$SINR" > /tmp/ModemAnalytics.txt
else
 Connected=$(echo "$Connected" | tr -d '"')
 MODE="-"       
 MCC=$(echo "$Quality_Signal_Noise" | cut -d "," -f 4 | tr -d '\011\012\013\014\015\040')                                                      
 MNC=$(echo "$Quality_Signal_Noise" | cut -d "," -f 5 | tr -d '\011\012\013\014\015\040')                                                      
 LAC=$(echo "$Quality_Signal_Noise" | cut -d "," -f 6 | tr -d '\011\012\013\014\015\040')                                                                                                                                       
 CELLID=$(echo "$Quality_Signal_Noise" | cut -d "," -f 7 | tr -d '\011\012\013\014\015\040')                                                   
 BSIC=$(echo "$Quality_Signal_Noise" | cut -d "," -f 8 | tr -d '\011\012\013\014\015\040')                                                     
 ARFCN=$(echo "$Quality_Signal_Noise" | cut -d "," -f 9 | tr -d '\011\012\013\014\015\040')                                                    
 BAND_VAL=$(echo "$Quality_Signal_Noise" | cut -d "," -f 10 | tr -d '\011\012\013\014\015\040')
 if [ "${BAND_VAL}" = "0" ]
 then
   BAND="DCS1800"
 elif [ "${BAND_VAL}" = "1" ]
 then
   BAND="PCS1900" 
 else
   BAND="GSM900"
 fi                                                    
 ULBAND="-"                                                                              
 DLBAND="-"                                                                                                                            
 TAC="-"                                                    
 RSRP="-"                                                    
 RSRQ="-"                                                    
 SINR="-"                         
 RSSI=$(gcom -d "$ComPort" -s /etc/gcom/getstrength.gcom | awk NR==2 | cut -d ":" -f 2 | cut -d "," -f 1 | tr -d '\011\012\013\014\015\040')
 RSSI=`expr 31 - "$RSSI"`
 RSSI=`expr "$RSSI" \* 2`
 RSSI=`expr -51 - "$RSSI"`
 echo "$Operator,$Connected,$MODE,$MCC,$MNC,$LAC,$CELLID,$BSIC,$ARFCN,$BAND,$ULBAND,$DLBAND,$TAC,$RSRP,$RSRQ,$RSSI,$SINR" > /tmp/ModemAnalytics.txt
fi
exit 0
