#!/bin/sh

if [ "$#" != "1" ]
then
    echo "Usage: $0 <Interface Name>"
    exit 1
fi

Interface="$1"

ReAPMqttHost="localhost"
ReAPMqttPort="1883"
ReAPMqttQos="1"
ReAPMqttActionManagerSubTopic="IOCard1/AI2DI4DO4_SG200/W/${Interface}/ActionManager"
InterfaceActionManagerScript="/root/InterfaceManager/script/InterfaceActionManager.sh"


mosquitto_sub -h "$ReAPMqttHost" -p "$ReAPMqttPort" -t "$ReAPMqttActionManagerSubTopic" -q "$ReAPMqttQos" | while true
do
    read PayLoad
    "$InterfaceActionManagerScript" "$Interface" "$PayLoad"
done


