#!/bin/sh

. /lib/functions.sh

rm /bin/updatevpnconfigoutput.txt
touch /bin/updatevpnconfigoutput.txt
chmod 0777 /bin/updatevpnconfigoutput.txt


ReadGreConfigFile()
{
  greread="$1"
  echo "greread value is $greread" 
  #echo "$vpnread"
  #config_get EEnablelocal "$vpnread" EEnable
  #config_get EnableIpsec "$vpnread" enableipsecgeneral
  config_get tunnelname "$greread" tunnelname
  config_get localexternalIP "$greread" localexternalIP
  config_get remoteexternalIP "$greread" remoteexternalIP
  config_get peertunnelIP "$greread" peertunnelIP
  config_get localtunnelIP "$greread" localtunnelIP
  config_get interfacetype "$greread" interfacetype
  config_get mtu "$greread" mtu
  config_get ttl "$greread" ttl

  config_get tunnelkey "$greread" tunnelkey
  config_get enablekeepalive "$greread" enablekeepalive
  #config_get keepalivehost "$greread" keepalivehost
  config_get aliveinterval    "$greread" aliveinterval
  #config_get keep_alive  "$greread" keep_alive
  #config_get keepaliveretry   "$greread" keepaliveretry
  config_get remotenetmask   "$greread"  remotenetmask
  config_get localnetmask   "$greread"  localnetmask
  config_get remoteip   "$greread"   remoteip
}

mygrestatic="mygre_static"
tunnel="tunnel"

UpdateGreConfig()
{
   vpn="$1"	
   echo "vpn is $vpn"
   ReadGreConfigFile "$vpn"
   
    if [ "$enablegre" = "1" ]
   then
   
       
       uci set network.mygre=interface
       uci set network.mygre.ipaddr="$localexternalIP"
       uci set network.mygre.peeraddr="$remoteexternalIP"
       uci set network.mygre.proto=gre 
       uci set network.mygre.keep_alive="$enablekeepalive"
       uci set network.mygre.keep_alive_interval="$aliveinterval"
      # uci set network.$tunnelname.keepalivr="$keepaliveretry"
       uci set network.mygre.tunlink="$interfacetype"
       
       
      # local_netmask=$(ipcalc.sh $localtunnelIP | grep -i "NETMASK" | cut -d'=' -f2)
      
       uci set network.$mygrestatic=interface
       uci set network.$mygrestatic.proto=static
       uci set network.$mygrestatic.ifname=@mygre
       uci set network.$mygrestatic.ipaddr="$localtunnelIP"
      #uci set network.$mygrestatic.netmask="$local_netmask"
       uci set network.$mygrestatic.netmask="$localnetmask"
       
	   remote_netmask=$(ipcalc.sh $remoteip | grep -i "NETMASK" | cut -d'=' -f2)
	   uci set network.$tunnel=route
	   uci set network.$tunnel.interface="$mygrestatic"
	   uci set network.$tunnel.target="$remoteip"
	   uci set network.$tunnel.netmask="$remote_netmask"
	   uci set network.$tunnel.gateway="$peertunnelIP"
	   uci set network.mygre.ikey="$tunnelkey"
	   
	   uci set network.mygre.okey="$tunnelkey"
	   
	   
	   #var=$(/bin/ipcalc.sh $remoteexternalIP) | grep -i "NETMASK"
	   
	  
	   #uci set network.$mygrestatic.netmask="$local_netmask"
	   
	   #uci set network.$mygrestatic.localaddr="$localtunnelIP"
       #uci set network.$mygrestatic.keepalivh="$keepalivehost"
       #uci set network.$mygrestatic.key="$tunnelkey"
       #uci set network.$mygrestatic.mt="$mtu"
	   #uci set network.$mygrestatic.tt="$ttl"
	   
	   
    fi                                                                           
    uci commit network  
}

/etc/init.d/network restart

ipconfigfile="/etc/config/tunnelconfig"
greconfigfile="/etc/config/ipsec"

#rm -rf "$ipsecconfigfile"
#touch "$ipsecconfigfile"

enablegre=$(uci get tunnelconfig.general.enablegre)

config_load "$ipconfigfile" 
config_foreach UpdateGreConfig tunnelconfig



