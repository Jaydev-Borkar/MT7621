#!/bin/sh

. /lib/functions.sh

/usr/bin/killall -9 ntpclient


WebConfigFile="/etc/config/webserverconfig"


ReadSystemConfigFile()
{
   	config_load "$WebConfigFile"
   	config_get EnableNtpSync webserverconfig enablentpsync
   	config_get NtpServer webserverconfig ntpserver
   	config_get NtpSyncInterval webserverconfig ntpsyncinterval
}


ReadSystemConfigFile


if [ "$EnableNtpSync" = "1" ]
then
syncsucces=0
   for i in $(seq 0 3)
   do
        server=$i.openwrt.pool.ntp.org
        if ping -c 3 -w 3 $server >/dev/null
                then
                ntpclient -s -h $server
                syncsucces=1
                break
        fi
   done

   if [ "$syncsucces" = "1" ]                                                                                         
    then                                                                                                           
       /sbin/hwclock -w
    else
       /sbin/hwclock -s                                                                                                 
     fi                                                                                                             
fi

exit 0
