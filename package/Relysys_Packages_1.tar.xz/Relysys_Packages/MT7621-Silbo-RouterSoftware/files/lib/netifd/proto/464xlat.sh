#!/bin/sh
# 464xlat.sh - 464xlat CLAT
#
# Copyright (c) 2015 Steven Barth <cyrus@openwrt.org>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

[ -n "$INCLUDE_ONLY" ] || {
	. /lib/functions.sh
	. /lib/functions/network.sh
	. ../netifd-proto.sh
	init_proto "$@"
}

proto_464xlat_setup() {
	local cfg="$1"
	local iface="$2"
	local link="464-$cfg"
	
	sim1apn=$(uci get sysconfig.sysconfig.apn) 
	sim2apn=$(uci get sysconfig.sysconfig.sim2apn) 
	sim1pdp=$(uci get sysconfig.sysconfig.pdp) 
	sim2pdp=$(uci get sysconfig.sysconfig.sim2pdp) 
	
	#Check which eth port is set as wan.
	port1mode=$(uci get sysconfig.sysconfig.port1mode)
	port2mode=$(uci get sysconfig.sysconfig.port2mode)
	port3mode=$(uci get sysconfig.sysconfig.port3mode)
	port4mode=$(uci get sysconfig.sysconfig.port4mode)
	port5mode=$(uci get sysconfig.sysconfig.port5mode)
	
	if ([ "$sim1apn" = "jionet" ] && [ "$cfg" = "wan6c1_4" ] && [ "$sim1pdp" = "2" ]) || ([ "$sim2apn" = "jionet" ] && [ "$cfg" = "wan6c2_4" ] && [ "$sim2pdp" = "2" ])
	then
		if echo "$port1mode" | grep -q "EWAN"; then
			ifconfig eth0.1 down
			port1="down"
		fi

		if echo "$port2mode" | grep -q "EWAN"; then
			ifconfig eth0.2 down
			port2="down"
		fi

		if echo "$port3mode" | grep -q "EWAN"; then
			ifconfig eth0.3 down
			port3="down"
		fi

		if echo "$port4mode" | grep -q "EWAN"; then
			ifconfig eth0.4 down
			port4="down"
		fi

		if echo "$port5mode" | grep -q "EWAN"; then
			ifconfig eth0.5 down
			port5="down"
		fi
		
		#Restart dnsmasq
		/etc/init.d/dnsmasq restart
    fi

	local ip6addr ip6prefix tunlink zone
	json_get_vars ip6addr ip6prefix tunlink zone

	[ "$zone" = "-" ] && zone=""

	( proto_add_host_dependency "$cfg" "::" "$tunlink" )

	if [ -z "$tunlink" ] && ! network_find_wan6 tunlink; then
		proto_notify_error "$cfg" "NO_WAN_LINK"
		return
	fi
	network_get_device tundev "$tunlink"

	ip6addr=$(464xlatcfg "$link" "$tundev" "$ip6prefix" 192.0.0.1 $ip6addr)
	if [ -z "$ip6addr" ]; then
		proto_notify_error "$cfg" "CLAT_CONFIG_FAILED"
		return
	fi

	ip -6 rule del from all lookup local
	ip -6 rule add from all lookup local pref 1
	ip -6 rule add to $ip6addr lookup prelocal pref 0
	echo "$ip6addr" > /tmp/464-$cfg-anycast
         if [ $cfg = "wan6c1_4" ]
         then
             metric=$(uci get mwan3.cwan6_1_m10_w1.metric) 
         elif [ $cfg = "wan6c2_4" ]
         then 
             metric=$(uci get mwan3.cwan6_2_m10_w1.metric)
         fi
	proto_init_update "$link" 1
	proto_add_ipv4_route "0.0.0.0" 0 "" "" $metric
	proto_add_ipv6_route $ip6addr 128 "" "" "" "" 128

	proto_add_data
	[ -n "$zone" ] && json_add_string zone "$zone"

	json_add_array firewall
		[ -z "$zone" ] && zone=$(fw3 -q network $iface 2>/dev/null)

		json_add_object ""
			json_add_string type nat
			json_add_string target SNAT
			json_add_string family inet
			json_add_string snat_ip 192.0.0.1
		json_close_object
		[ -n "$zone" ] && {
			json_add_object ""
				json_add_string type rule
				json_add_string family inet6
				json_add_string proto all
				json_add_string direction in
				json_add_string dest "$zone"
				json_add_string src "$zone"
				json_add_string src_ip $ip6addr
				json_add_string target ACCEPT
			json_close_object
		}
	if ([ "$sim1apn" = "jionet" ] && [ "$cfg" = "wan6c1_4" ] && [ "$sim1pdp" = "2" ]) || ([ "$sim2apn" = "jionet" ] && [ "$cfg" = "wan6c2_4" ] && [ "$sim2pdp" = "2" ])
	then
		if [ "$port1" = "down" ]
		then
			ifconfig eth0.1 up
		fi
		if [ "$port2" = "down" ]
		then
			ifconfig eth0.2 up
		fi
		if [ "$port3" = "down" ]
		then
			ifconfig eth0.3 up
		fi
		if [ "$port4" = "down" ]
		then
			ifconfig eth0.4 up
		fi
		if [ "$port5" = "down" ]
		then
			ifconfig eth0.5 up
		fi
	fi
	json_close_array
	proto_close_data

	proto_send_update "$cfg"
}

proto_464xlat_teardown() {
	local cfg="$1"
	local link="464-$cfg"

	[ -f /tmp/464-$cfg-anycast ] || return
	local ip6addr=$(cat /tmp/464-$cfg-anycast)

	464xlatcfg "$link"

	rm -rf /tmp/464-$cfg-anycast
	[ -n "$ip6addr" ] && ip -6 rule del to $ip6addr lookup prelocal

	if [ -z "$(ls /tmp/464-*-anycast 2>&-)" ]; then
		ip -6 rule del from all lookup local
		ip -6 rule add from all lookup local pref 0
	fi
}

proto_464xlat_init_config() {
	no_device=1
	available=1

	proto_config_add_string "ip6prefix"
	proto_config_add_string "ip6addr"
	proto_config_add_string "tunlink"
	proto_config_add_string "zone"
}

[ -n "$INCLUDE_ONLY" ] || {
        add_protocol 464xlat
}
