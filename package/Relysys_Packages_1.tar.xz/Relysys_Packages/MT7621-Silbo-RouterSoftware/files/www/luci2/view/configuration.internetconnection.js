L.ui.view.extend({
	
	title: L.tr('Internet Connection Configuration'),
	description: L.tr('Please update after editing any changes.'),	
	
	fGetUCISections: L.rpc.declare({
		object: 'uci',
		method: 'get',
		params: [ 'config', 'type' ],
		expect: { values: {} }
	}),
	fDeleteUCISection:  L.rpc.declare({
		object: 'uci',
		method: 'delete',
		params: [ 'config','type','section' ]
	}),
	
	fCommitUCISection:  L.rpc.declare({
		object: 'uci',
		method: 'commit',
		params: [ 'config' ]
	}),

	updatefirewallconfig: L.rpc.declare({
        object: 'rpc-validatepriority',
        method: 'configure',
        expect: { output: '' }
    }),
    
	
	fCreateForm: function(mapwidget, fSectionID, fSectionType)
	{
		var self = this;
		
		if (!mapwidget)
			mapwidget = L.cbi.Map;
		
		if(fSectionType == "Dredirect") {
			var FormContent = self.pfCreateFormCallback;
		}
		
		var map = new mapwidget('mwan3config', {
			prepare:    FormContent,
			fSection:   fSectionID
		});
		return map;
	},
	
	fSectionEdit: function(ev) {
		var self = ev.data.self;
		var fSectionID = ev.data.fSectionID;
		var fSectionType = ev.data.fSectionType;

		return self.fCreateForm(L.cbi.Modal, fSectionID, fSectionType).show();
					location.reload();

	},
	
	pfCreateFormCallback: function()
	{
		var map = this;
		var pfSectionID = map.options.fSection;
		
		map.options.caption = L.tr('Configuration');
		
		var s = map.section(L.cbi.NamedSection, pfSectionID, {
			collabsible: true,
			anonymous:   true,
			 tabbed:      true
		});
		
		s.option(L.cbi.DummyValue, 'name', {
				caption:     L.tr('Name')
		});
		
		s.option(L.cbi.ComboBox, 'wanpriority', {
			caption:     L.tr('Priority'),
			optional:      'true'
		}).value("1", L.tr('1'))
		  .value("2", L.tr('2'))
		  .value("3", L.tr('3'));   
		  
	   s.option(L.cbi.ListValue, 'validtrackip', {
                        caption: L.tr('Select Track IP Numbers')
                }).value("0",L.tr("none"))
	              .value("1",L.tr("1"))
	              .value("2",L.tr("2"))
			      .value("3",L.tr("3"))
	              .value("4",L.tr("4"));
	                
	     s.option(L.cbi.InputValue, 'trackIp1', {                                       
                caption: L.tr('TrackIP1'), 
                placeholder:     '8.8.8.8',                                                           
                        optional: true,                                                                             
                }).depends({'validtrackip':'1'})
                .depends({'validtrackip':'2'})
                .depends({'validtrackip':'3'})
                .depends({'validtrackip':'4'});           
                 
	     s.option(L.cbi.InputValue, 'trackIp2', {                                       
                caption: L.tr('TrackIP2'), 
                placeholder:     '8.8.8.8',                                                           
                        optional: true,                                                                             
                }).depends({'validtrackip':'2'})
                .depends({'validtrackip':'3'})
                .depends({'validtrackip':'4'}); 
                                            
	     s.option(L.cbi.InputValue, 'trackIp3', {                                       
                caption: L.tr('TrackIP3'), 
                placeholder:     '8.8.8.8',                                                           
                        optional: true,                                                                             
                }).depends({'validtrackip':'3'})
                .depends({'validtrackip':'4'});          
                       
	     s.option(L.cbi.InputValue, 'trackIp4', {                                       
                caption: L.tr('TrackIP4'), 
                placeholder:     '8.8.8.8',                                                           
                        optional: true,                                                                             
                }).depends({'validtrackip':'4'});     
                
           
         s.option(L.cbi.InputValue, 'reliability', {
		caption:	L.tr('Reliability'),
		datatype: 'integer',
		}); 
		
		    
         s.option(L.cbi.InputValue, 'count', {
		caption:	L.tr('Count'),
		datatype: 'integer',
		});                          
	          
	         
         s.option(L.cbi.InputValue, 'up', {
		caption:	L.tr('Up'),
		datatype: 'integer',
		});                          
	          
	         
         s.option(L.cbi.InputValue, 'down', {
		caption:	L.tr('Down'),
		datatype: 'integer',
		});                          
	                                                     
	},
		
	pfRenderContents: function(rv)
	{
		var self = this;

		var list = new L.ui.table({
			columns: [ { 
				caption: L.tr('Name'),
				format:  function(v,n) {
					var div = $('<p />').attr('id', 'pfName_%s'.format(n));
					return div.append('<strong>'+v+'</strong>');
				}
			},
			{ 
				caption: L.tr('Priority'),
				format:  function(v,n) {
					var div = $('<p />').attr('id', 'pfMatch_%s'.format(n));
					return div.append(v);
				}
			},
			{ 
				caption: L.tr('TrackIP1'),
				format:  function(v,n) {
					var div = $('<p />').attr('id', 'pfForwardTo_%s'.format(n));
					return div.append(v);
				}
			},
			
			{ 
				caption: L.tr('TrackIP2'),
				format:  function(v,n) {
					var div = $('<p />').attr('id', 'pfForwardTo_%s'.format(n));
					return div.append(v);
				}
			},
			
			{ 
				caption: L.tr('TrackIP3'),
				format:  function(v,n) {
					var div = $('<p />').attr('id', 'pfForwardTo_%s'.format(n));
					return div.append(v);
				}
			},
			
			{ 
				caption: L.tr('TrackIP4'),
				format:  function(v,n) {
					var div = $('<p />').attr('id', 'pfForwardTo_%s'.format(n));
					return div.append(v);
				}
			},
			
			{
				caption: L.tr('Actions'),
				format:  function(v, n) {
					return $('<div />')
						.addClass('btn-group btn-group-sm')
						.append(L.ui.button(L.tr('Edit'), 'primary', L.tr('Edit Port Forward'))
							.click({ self: self, fSectionID: v, fSectionType: "Dredirect" }, self.fSectionEdit))
				}
			}]
		});
		
		for (var key in rv) {                                                                           
			if (rv.hasOwnProperty(key)) {            
				var obj = rv[key];                                                               
				var WanPriority = obj.wanpriority;
				var srctxt = WanPriority;
				var Priority =srctxt;
				
				var validtrackip=obj.validtrackip
				
				if ( validtrackip == "1" ) {
				var TrackIP1=obj.trackIp1;
				var TrackIP2="-";
				var TrackIP3="-";
				var TrackIP4="-";
			    }
			   
			   if ( validtrackip == "2" ) {
				var TrackIP1=obj.trackIp1;
				var TrackIP2=obj.trackIp2;
				var TrackIP3="-";
				var TrackIP4="-";
			    }
			   
			    
			    if ( validtrackip == "3" ) {
				var TrackIP1=obj.trackIp1;
				var TrackIP2=obj.trackIp2;
				var TrackIP3=obj.trackIp3;
				var TrackIP4="-";
			    }
			    
			    if ( validtrackip == "4" ) {
				var TrackIP1=obj.trackIp1;
				var TrackIP2=obj.trackIp2;
				var TrackIP3=obj.trackIp3;
				var TrackIP4=obj.trackIp4;
		     	}
				
				list.row([ obj.name,Priority,TrackIP1,TrackIP2,TrackIP3,TrackIP4,key ]);
				
				
			}                                                                   
		}   	
		
		$('#section_firewall_port').
			append(list.render());		
	},


    pfSectionUpdate: function(ev) {
		var self = ev.data.self;
		var pfSectionID = ev.data.pfSectionID;
		L.ui.loading(true);
		self.updatefirewallconfig(pfSectionID).then(function(rv) {
			if(rv == 0){
				alert("Error: Configuration Not Updated");
			}
			else {
				alert("configuration is updated");
				location.reload();
			}
			
		});
	},
    

	pfSectionRemove: function(ev) {
		var self = ev.data.self;
		var pfSectionID = ev.data.pfSectionID;
		
		self.fDeleteUCISection("mwan3config","redirect",pfSectionID).then(function(rv){
			if(rv == 0){
				self.fCommitUCISection("mwan3config").then(function(res){
					self.updatefirewallconfig(pfSectionID).then(function(rv) {
						if (res != 0){
							alert("Error: Delete Port Forward Configuration");
						}
						else {
							location.reload();
						}
					});
				});
			};
		});
	},
	
	pfSectionAdd: function () 
	{
		var self = this;
		var pfName = $('#field_firewall_redirect_newRedirect_name').val();		
          var SectionOptions = {name:pfName};
		self.fCreateUCISection("mwan3config","redirect",pfName).then(function(rv){
			if(rv){
				if (rv.section){
					self.fCommitUCISection("mwan3config").then(function(res){
						location.reload();
						if (res != 0) {
							alert("Error: New Port Forward Configuration");
						}
						else {
							location.reload();
						}
					});
					
				};
			};
		});
		
	},
	
	execute: function() {		
		var self = this;
                
		this.fGetUCISections("mwan3config","redirect").then(function(rv) {
			
			self.pfRenderContents(rv);   
		});
		
		 $('#AddNewPortForward').click(function() {
            L.ui.loading(true);
            self.updatefirewallconfig('configure').then(function(rv) {
                L.ui.loading(false);
                    L.ui.dialog(
                        L.tr('update configuration'),[
                            $('<pre />')
                            .addClass('alert alert-success')
                            .text(rv)
                        ],
                        { style: 'close'}
                    );
                    
                   });
            });
	}
});
