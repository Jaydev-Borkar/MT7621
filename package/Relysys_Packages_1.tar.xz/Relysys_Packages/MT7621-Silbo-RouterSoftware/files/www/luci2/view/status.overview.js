L.ui.view.extend({
	title: L.tr('Status'),

	fGetUCISections: L.rpc.declare({
		object: 'uci',
		method: 'get',
		params: [ 'config', 'section' ],
		expect: { values: {} }
	}),

	getConntrackCount: L.rpc.declare({
		object: 'luci2.network',
		method: 'conntrack_count',
		expect: { '': { count: 0, limit: 0 } }
	}),

	getDHCPLeases: L.rpc.declare({
		object: 'luci2.network',
		method: 'dhcp_leases',
		expect: { leases: [ ] }
	}),

	getDHCPv6Leases: L.rpc.declare({
		object: 'luci2.network',
		method: 'dhcp6_leases',
		expect: { leases: [ ] }
	}),
	
   gettimezone: L.rpc.declare({
        object: 'rpc-gettimezone',
        method: 'get',
        params: ['application','action'],
        expect: { output: '' }
        }),
	
	renderContents: function() {
		var self = this;
		
		window.$tmzone;
	    self.gettimezone('get').then(function(tz) 
		 {
			$tmzone=tz;	
					   																	
		});  
	
		 		
	    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' , timeZone: window.$tmzone ,hour: '2-digit', minute: '2-digit' ,second: '2-digit'};

		return $.when(
			L.network.refreshStatus().then(function() {
				var wan = L.network.findActiveWAN('0.0.0.0');
				var wan6 = L.network.findActiveWAN('::');
								
				if (!wan && !wan6)
				{
					$('#network_status_table').empty();
					return;
				}
				
				for(var i=0; i < wan.length; i++)
				{
					var iface=wan[i];
					var networkTable = new L.ui.grid({
						caption: L.tr('Network'),
						columns: [ {
							width:    2,
							width_sm: 12,
							format:   '%s'
						}, {
							width:    2,
							width_sm: 3,
							align:  'right',
							format: function(v) {
								var dev = L.network.resolveAlias(v.getDevice());
								if (dev)
									return $('<span />')
										.addClass('badge')
										.attr('title', dev.description())
										.append($('<img />').attr('src', dev.icon()))
										.append(' %s'.format(dev.name()));

								return '';
							}
						}, {
							width:  6,
							width_sm: 9,
							format: function(v, n) {
								return new L.ui.hlist({ items: [
									L.tr('Type'), v.getProtocol().description,
									L.tr('Connected'), '%t'.format(v.getUptime()),
									L.tr('Address'), v.getIPv4Addrs().join(', '),
									L.tr('Gateway'), v.getIPv4Gateway(),
									L.tr('DNS'), v.getIPv4DNS().join(', ')
								] }).render();
							}
						} ]
					});
					
					
					/*if (wan6)
						networkTable.row([ L.tr('IPv6 WAN Status'), wan6, wan6 ]);*/
					}
					for(var i=0; i<wan.length; i++){
						if (wan[i]){
							networkTable.row([ L.tr('IPv4 WAN Status'), wan[i], wan[i] ]);
						}
					}
					networkTable.insertInto('#network_status_table');
				
			}),
								
			self.getConntrackCount().then(function(count) {
				var conntrackTable = new L.ui.grid({
					caption: L.tr('Connection Tracking'),
					columns: [ {
						width:    4
					}, {
						format: function(v) {
							return new L.ui.progress({
								value:  v.count,
								max:    v.limit,
								format: '%d / %d (%d%%)'
							}).render();
						}
					} ]
				});

				conntrackTable.row([ L.tr('Active Connections'), count ]);
				conntrackTable.insertInto('#conntrack_status_table');
			}),
			L.system.getInfo().then(function(info) {
				var sysinfoTable = new L.ui.grid({
					caption: L.tr('System'),
					columns: [ {
						width:    4
					}, {
						width:    8,
						nowrap:   true
					} ]
				});

				sysinfoTable.rows([
					[ L.tr('Hostname'),         info.hostname                         ],
					[ L.tr('Model'),            "SILBO"                            ],
					[ L.tr('Firmware Version'), "1.08"		            ],
					[ L.tr('Kernel Version'),   info.kernel                           ],
					//[ L.tr('Local Time'),       (new Date(info.localtime * 1000)).toString() ],
					[ L.tr('Local Time'),       (new Date().toLocaleString(undefined, options)) ],
			       // [ L.tr('Local Time (IST)'),       (new Date().toLocaleString()) ],

					[ L.tr('Uptime'),           '%t'.format(info.uptime)              ],
					[ L.tr('Load Average'),
					  '%.2f %.2f %.2f'.format(
						  info.load[0] / 65535.0,
						  info.load[1] / 65535.0,
						  info.load[2] / 65535.0
					  ) ]
				]);

				sysinfoTable.insertInto('#system_status_table');

				var memoryTable = new L.ui.grid({
					caption: L.tr('Memory'),
					columns: [ {
						format:   '%s',
						width:    4
					}, {
						format: function(v) {
							return new L.ui.progress({
								value:  v,
								max:    info.memory.total,
								format: function(pc) {
									return ('%d ' + L.tr('kB') + ' / %d ' + L.tr('kB') + ' (%d%%)').format(
										v / 1024, info.memory.total / 1024, pc
									);
								}
							}).toString();
						}
					} ]
				});

				memoryTable.rows([
					[ L.tr('Total Available'), info.memory.free + info.memory.buffered ],
					[ L.tr('Free'),            info.memory.free                        ],
					[ L.tr('Cached'),          info.memory.shared                      ],
					[ L.tr('Buffered'),        info.memory.buffered                    ],
				]);

				memoryTable.insertInto('#memory_status_table');

				if (info.swap.total > 0)
				{
					var swapTable = new L.ui.grid({
						caption: L.tr('Swap'),
						columns: [ {
							format:   '%s',
							width:    4
						}, {
							format: function(v) {
								return new L.ui.progress({
									value:  v,
									max:    info.swap.total,
									format: function(pc) {
										return ('%d ' + L.tr('kB') + ' / %d ' + L.tr('kB') + ' (%d%%)').format(
											v / 1024, info.swap.total / 1024, pc
										);
									}
								}).toString();
							}
						} ]
					});

					swapTable.row([ L.tr('Free'), info.swap.free ]);
					swapTable.insertInto('#swap_status_table');
				}

				var diskTable = new L.ui.grid({
					caption: L.tr('Storage'),
					columns: [ {
						format:   '%s',
						width:    4
					}, {
						format: function(v) {
							return new L.ui.progress({
								value:  v[0],
								max:    v[1],
								format: function(pc) {
									return ('%d ' + L.tr('kB') + ' / %d ' + L.tr('kB') + ' (%d%%)').format(
										v[0] / 1024, v[1] / 1024, pc
									);
								}
							}).toString();
						}
					} ]
				});

				diskTable.row([ '' + L.tr('Root Usage') + ' (/)', [ info.root.used, info.root.total ] ]);
				diskTable.row([ '' + L.tr('Temporary Usage') + ' (/tmp)', [ info.tmp.used, info.tmp.total ] ]);
				diskTable.insertInto('#disk_status_table');
			}),
			self.getDHCPLeases().then(function(leases) {
				var leaseTable = new L.ui.grid({
					caption:     L.tr('DHCP Leases'),
					placeholder: L.tr('There are no active leases.'),
					columns: [ {
						caption:     L.tr('Hostname'),
						placeholder: '?',
						key:         'hostname',
						nowrap:      true,
						width_sm:    5
					}, {
						caption:     L.tr('IPv4-Address'),
						key:         'ipaddr',
						width_sm:    4,
						//format: '255.255.255.255'
					}, {
						caption:     L.tr('MAC-Address'),
						key:         'macaddr',
						width_sm:    0
					}, {
						caption:     L.tr('Leasetime remaining'),
						key:         'expires',
						width_sm:    3,
						nowrap:      true,
						format:      function(v) {
							return (v <= 0) ? L.tr('expired') : '%t'.format(v);
						}
					} ]
				});

				leaseTable.rows(leases);
				leaseTable.insertInto('#lease_status_table');
			}),
			self.getDHCPv6Leases().then(function(leases) {
				if (!leases.length)
					return;

				var leaseTable = new L.ui.grid({
					caption:     L.tr('DHCPv6 Leases'),
					columns: [ {
						caption:     L.tr('Hostname'),
						placeholder: '?',
						key:         'hostname',
						width_sm:    0
					}, {
						caption:     L.tr('IPv6-Address'),
						key:         'ip6addr',
						width_sm:    6
					}, {
						caption:     L.tr('DUID'),
						key:         'duid',
						width_sm:    0
					}, {
						caption:     L.tr('Leasetime remaining'),
						key:         'expires',
						width_sm:    6,
						format:      function(v) {
							return (v <= 0) ? L.tr('expired') : '%t'.format(v);
						}
					} ]
				});

				leaseTable.rows(leases);
				leaseTable.insertInto('#lease6_status_table');
			}),

			this.fGetUCISections("system","system").then(function(val) {
				var simInfoTable = new L.ui.grid({
					caption:	L.tr('Active Sim Information'),
					columns: [ {
						width:    4
					}, {
						width:    8,
						nowrap:   true
					} ]
				});

				simInfoTable.rows([
					[L.tr('Active SIM Number'),		val.simNum],
					[L.tr('SIM QCCID'),				val.qccid]
				]);

				simInfoTable.insertInto('#sim_status_table');
			})
		)
	},

	execute: function()
	{
		var self = this;
        return L.network.load().then(function() {
			self.repeat(self.renderContents, 5000);
        });
	}
});
