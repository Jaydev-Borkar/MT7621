L.ui.view.extend({

    title: L.tr('SIM Switch Configuration'),
      RunUdev:L.rpc.declare({
        object:'command',
        method:'exec',
        params : ['command','args'],
    }),
    
    
     fGetUCISections: L.rpc.declare({
        object: 'uci',
        method: 'get',
       // params: [ 'config', 'type', 'section']  
              params: [ 'config', 'type']  
       
    }),
    
      updatesimswitchconfig: L.rpc.declare({
        object: 'rpc-simswitchconfig',
        method: 'configure',
        params: ['application','action'],
        expect: { output: '' }
        }),
  
    execute:function() {
        var self = this;
        var m = new L.cbi.Map('simswitchconfig', {
        });
        
        var s = m.section(L.cbi.NamedSection, 'simswitchconfig', {
            caption:L.tr('SIM Switch')
        }); 
        
               
 //#################################################################################################################
 // 
 //					SIM Switch Settings
 //
 // ##################################################################################################################                        

       s.tab({
            id: 'cellularconfig',
            caption: L.tr('Cellular Settings')
        });
        
      s.taboption('cellularconfig',L.cbi.CheckboxValue, 'cellulardataswitchlimitenable', {
                        caption: L.tr('Cellular Data switch Limit Enable'),
                        optional: true
                }) .depends({'cellularconfig':'1'})
                   .depends({'CellularOperationMode' : 'singlecellulardualsim','modemenable':'1','dataenable':'1','enablecellular':'1'});   

                s.taboption('cellularconfig',L.cbi.InputValue, 'sim1datausagelimit', {
                        caption: L.tr('SIM 1 Data Usage Limit (In MB)'),
                        optional: true 
                })
                .depends({'cellularconfig' : '1'})
				.depends({'CellularOperationMode' : 'singlecellulardualsim','modemenable':'1','dataenable':'1','enablecellular':'1','cellulardataswitchlimitenable':'1'});   
                
                 s.taboption('cellularconfig',L.cbi.InputValue, 'sim2datausagelimit', {
                        caption: L.tr('SIM 2 Data Usage Limit (In MB)'),
                        optional: true 
                })
                .depends({'cellularconfig' : '1'})
                .depends({'CellularOperationMode' : 'singlecellulardualsim','modemenable':'1','dataenable':'1','enablecellular':'1','cellulardataswitchlimitenable':'1'});   
                
               
                s.taboption('cellularconfig',L.cbi.ListValue, 'cellulardatausagemanagerperiodicity', {
                        caption: L.tr('Periodicity'),
                })
                //.depends({'cellularconfig' : '1','CellularOperationMode' : 'singlecellulardualsim','CellularOperationMode' : 'dualcellularsinglesim','modemenable':'1','dataenable':'1'})
                 .depends({'cellularconfig' : '1'})
                .depends({'CellularOperationMode' : 'singlecellulardualsim','modemenable':'1','dataenable':'1','enablecellular':'1','cellulardataswitchlimitenable':'1'})
                 .value('none', L.tr('Select'))
                .value('monthly', L.tr('Monthly'))
                .value('daily', L.tr('Daily'));  
                
                
            var DaysVal = s.taboption('cellularconfig', L.cbi.ListValue, 'dayofmonth', {
            caption: L.tr('Day Of Month'),
            optional: true,
            listlimit: 28,
            listcustom:false
        }).depends({'CellularOperationMode' : 'singlecellulardualsim','modemenable':'1','dataenable':'1','enablecellular':'1','cellulardatausagemanagerenable':'1','cellulardatausagemanagerperiodicity':'monthly'})
        .value('',L.tr('-- Please choose --'))
        DaysVal.load = function(sid) {
            var days = [ ];
            for (var i = 1; i <= 28; i++)
                days.push(i);
            days.sort();
            for (var i = 1; i <= days.length; i++)
                DaysVal.value(i);
        };

          
              //s.taboption('cellularconfig',L.cbi.CheckboxValue, 'cellulardataswitchonspeedenable', {
                        //caption: L.tr('On Speed Cellular Data switch Enable'),
                        //optional: true
                //}) .depends({'cellularconfig':'1'})
                   //.depends({'CellularOperationMode' : 'singlecellulardualsim','modemenable':'1','dataenable':'1','enablecellular':'1'});   
                   
                   
                   /*s.taboption('cellularconfig',L.cbi.DummyValue, 'dummytext', {
		  caption: L.tr(''),
		//  caption: L.tr(a),
        }).depends({'cellulardataswitchonspeedenable':'1'})
        .ucivalue=function()
          {
            var id="<h5><b>Caution: Enabling speed check will consume SIM data !!</b> </h5>";
            return id;
          }; 

				s.taboption('cellularconfig',L.cbi.InputValue, 'speedtestserverurl', {
                        caption: L.tr('Speed Test Server IP'),
                        placeholder: '8.8.8.8',
                        optional: true 
                })
                .depends({'cellularconfig' : '1'})
                .depends({'CellularOperationMode' : 'singlecellulardualsim','modemenable':'1','dataenable':'1','enablecellular':'1','cellulardataswitchonspeedenable':'1'});   
                
                
			  s.taboption('cellularconfig',L.cbi.ListValue, 'speedtestinterval', {
                        caption: L.tr('Speed Test Interval (In Seconds)'),
                })
                //.depends({'cellularconfig' : '1','CellularOperationMode' : 'singlecellulardualsim','CellularOperationMode' : 'dualcellularsinglesim','modemenable':'1','dataenable':'1'})
                 .depends({'cellularconfig' : '1'})
                .depends({'CellularOperationMode' : 'singlecellulardualsim','modemenable':'1','dataenable':'1','enablecellular':'1','cellulardataswitchonspeedenable':'1'})
                 .value('none', L.tr('Select'))
                .value('2', L.tr('2'))
                .value('5', L.tr('5'))
                .value('10', L.tr('10'));
                
               s.taboption('cellularconfig',L.cbi.ListValue, 'periodicspeedtestinterval', {
                        caption: L.tr('Periodic Speed Test Interval (In Hours)'),
                })
                //.depends({'cellularconfig' : '1','CellularOperationMode' : 'singlecellulardualsim','CellularOperationMode' : 'dualcellularsinglesim','modemenable':'1','dataenable':'1'})
                 .depends({'cellularconfig' : '1'})
                .depends({'CellularOperationMode' : 'singlecellulardualsim','modemenable':'1','dataenable':'1','enablecellular':'1','cellulardataswitchonspeedenable':'1'})
                .value('none', L.tr('Select'))
                .value('3', L.tr('3'))
                .value('4', L.tr('4'))
                .value('6', L.tr('6'))
                .value('8', L.tr('8'));
                
                 s.taboption('cellularconfig',L.cbi.InputValue, 'uploadspeedthreshold', {
                        caption: L.tr('Upload Speed Threshold (In kbps)'),
                        optional: true 
                })
                .depends({'cellularconfig' : '1'})
                .depends({'CellularOperationMode' : 'singlecellulardualsim','modemenable':'1','dataenable':'1','enablecellular':'1','cellulardataswitchonspeedenable':'1'});   
                
                 s.taboption('cellularconfig',L.cbi.InputValue, 'downloadspeedthreshold', {
                        caption: L.tr('Download Speed Threshold (In kbps)'),
                        optional: true 
                })
                .depends({'cellularconfig' : '1'})
                .depends({'CellularOperationMode' : 'singlecellulardualsim','modemenable':'1','dataenable':'1','enablecellular':'1','cellulardataswitchonspeedenable':'1'}); */  
       s.commit=function(){
			
                 self.updatesimswitchconfig('configure').then(function(rv) {
				               
                });
           }
                   
		                        
        return m.insertInto('#map');
    }
});
