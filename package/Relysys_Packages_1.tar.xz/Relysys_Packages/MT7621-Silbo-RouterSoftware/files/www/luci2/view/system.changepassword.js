L.ui.view.extend({

 updateadminpassword: L.rpc.declare({
        object: 'rpc-updateadminpassword',
        method: 'configure',
        params: ['application','action'],
        expect: { output: '' }
        }),       

execute: function() {

var self = this;	 
                                        
//return L.ui.getAvailableACLs().then(function(acls) {
var m = new L.cbi.Map('rpcdtemp', {
caption:     L.tr('System Admin'),
description: L.tr('Manage user accounts and permissions for accessing the LuCI ui.'),
//readonly:    !self.options.acls.users
});

var s = m.section(L.cbi.NamedSection, 'rpcdtemp', {
caption:      L.tr('Change Admin Password'),
//collabsible:  true,
//addremove:    false,
//add_caption:  L.tr('Add account …'),
//teasers:      [ 'username', '__shadow', '__acls' ]
});

//alert(password);

// password.depends('__shadow', false);
 

   var password = s.option(L.cbi.PasswordValue, 'password', {
	caption:     L.tr('Password'),
	description: L.tr('Specifies the password for the guest account. If you enter a plaintext password here, it will get replaced with a crypted password hash on save.  Please Logout and login again for new passoword to take effect'),
	optional:    false
	}).depends({'username':'admin'});
	
	password.save = function(sid) {
// var sh = this.ownerSection.fields.__shadow.formvalue(sid);
var pw = this.ownerSection.fields.password.formvalue(sid);
// alert(pw);
//if (!sh && !pw)
// return;

if (!pw)
return;


// if (sh)
// pw = '$p$' + this.ownerSection.fields.username.formvalue(sid);

if (pw.match(/^\$[0-9p][a-z]?\$/))
{
	if (pw != this.ownerMap.get('rpcdtemp', sid, 'password'))
	this.ownerMap.set('rpcdtemp', sid, 'password', pw);
}
else
{
	var map = this.ownerMap;
	return L.ui.cryptPassword(pw).then(function(crypt) {
	map.set('rpcdtemp', sid, 'password', crypt);
});
}
};


	/*s.commit=function(){
			var map = this.ownerMap;
		//	alert(password);			
           L.ui.cryptPassword(password).then(function(crypt) {
			   
			   map.set('rpcd', sid, 'password', crypt);
        });
      
	} */
	
	
	
	s.commit=function(){
			
                self.updateadminpassword('configure').then(function(rv) {
				               
                });
           }
  return m.insertInto('#map');
}
   			
 

});
