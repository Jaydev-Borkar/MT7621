L.ui.view.extend({
    title: L.tr('Tunnel Configuration'),
    description: L.tr(''),
    
    RS485GetUCISections: L.rpc.declare({
            object: 'uci',
            method: 'get',
            params: [ 'config', 'type'],
            expect: { values: {} }
    }),
    
    RS485CreateUCISection:  L.rpc.declare({
            object: 'uci',
            method: 'add',
            params: [ 'config', 'type', 'name', 'values' ]
    }),
    
    RS485CommitUCISection:  L.rpc.declare({
            object: 'uci',
            method: 'commit',
            params: [ 'config' ]
    }),
    
    RS485DeleteUCISection:  L.rpc.declare({
    object: 'uci',
    method: 'delete',
    params: [ 'config','type','section' ]
}),

    updategreconfig: L.rpc.declare({
    object: 'rpc-updateGREConfig',
    method: 'configure',
    expect: { output: '' }
}),

   updateipipconfig: L.rpc.declare({
    object: 'rpc-updateIPIPConfig',
    method: 'configure',
    expect: { output: '' }
}),
  

  updateeoipconfig: L.rpc.declare({
    object: 'rpc-updateEOIPConfig',
    method: 'configure',
    expect: { output: '' }
 }),

    startopenvpnservice: L.rpc.declare({
    object: 'rpc-updateVPNConfig',
    method: 'startopenvpn',
    expect: { output: '' }
}),  

 stopopenvpnservice: L.rpc.declare({
    object: 'rpc-updateVPNConfig',
    method: 'stopopenvpn',
    expect: { output: '' }
}),



  TestArchive: L.rpc.declare({
        object: 'rpc-updateVPNConfig',
        method: 'testarchive',
        params: ['archive'],
}),


 handleArchiveUpload : function() {
    var self = this;  
    L.ui.archiveUploadcerts(
        L.tr('Archive Upload'),
        L.tr('Select the archive and click on "%s" button to proceed.').format(L.tr('Apply')), {
            success: function(info) {
              self.handleArchiveVerify(info);
            }
        }
    );
},

handleArchiveVerify : function(info)
{
    var self = this;
          var archive=$('[name=filename]').val();
    
   // if((checksumval == info.checksum) &&(sizeval == info.size)) {
        L.ui.loading(true);
        self.TestArchive(archive).then(function(TestArchiveOutput) {
            
            L.ui.dialog(
                    L.tr('TestArchive'), [
                    $('<p />').text(L.tr('Success')),
                    $('<pre />')
                    .addClass('alert-success')
                    .text("file uploaded successfully")	
                ],{
                        style: 'close',
                        
                    }
            );
            L.ui.loading(false);   
        });
    //}
           
},
        
    RS485FormCallback: function() 
    {
            var map = this;
            var RS485ConfigSectionName = map.options.RS485ConfigSection;
            var numericExpression = /^[0-9]+$/;
            
            map.options.caption = L.tr(RS485ConfigSectionName+' Configuration');
            
            var s = map.section(L.cbi.NamedSection, RS485ConfigSectionName, {
                    collabsible: true
            });
                         
           
           
          
                      
s.option(L.cbi.DummyValue, 'typesettings', {
      caption: L.tr(''),
    //  caption: L.tr(a),
    }).depends({'ipsecconfig':'1','enableipsec' : '1'})
    .ucivalue=function()
      {
        var id="<h5><b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbspGRE Tunnel Configuration </b> </h3>";
        return id;
      };
      
       s.option(L.cbi.InputValue, 'tunnelname', {
       caption: L.tr('Tunnel name'),
       datatype: 'rt_alphanumeric',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});
     
       
       s.option(L.cbi.InputValue, 'localexternalIP', {
       caption: L.tr('Local external IP'),
        placeholder: '192.168.6.1',
       datatype: 'ip4addr',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});
     
     
      s.option(L.cbi.InputValue, 'remoteexternalIP', {
       caption: L.tr('Remote external IP'),
       placeholder: '192.168.0.1',
       datatype: 'ip4addr',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});
     
     
     /* s.option(L.cbi.InputValue, 'remotenetmask', {
       caption: L.tr('Remote net mask'),
       placeholder: '255.255.255.252',
       datatype: 'ip4addr',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});*/
       
      s.option(L.cbi.InputValue, 'peertunnelIP', {
       caption: L.tr('Peer tunnel IP'),
       placeholder: '10.1.1.2',
       datatype: 'ip4addr',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});
     
     s.option(L.cbi.InputValue, 'localtunnelIP', {
       caption: L.tr('Local tunnel IP'),
       placeholder: '10.1.1.12',
       datatype: 'ip4addr',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});
     
     s.option(L.cbi.InputValue, 'localnetmask', {
       caption: L.tr('Local tunnel net mask'),
       placeholder: '255.255.255.0',
       datatype: 'ip4addr',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});
     
     
       s.option(L.cbi.InputValue, 'remoteip', {
       caption: L.tr('Remote IP'),
       placeholder: '192.168.10.0/24',
       datatype: 'cidr4',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});
       
       s.option(L.cbi.ListValue,'interfacetype',{          
                    caption:L.tr('Interface type'),                    
            }).depends({'ipsecconfig':'1','enableipsec' : '1'})
            .value("EWAN1", L.tr('EWAN1')) 
            .value("EWAN2", L.tr('EWAN2')) 
            .value("EWAN3", L.tr('EWAN3')) 
            .value("EWAN4", L.tr('EWAN4')) 
            .value("EWAN5", L.tr('EWAN5')) 
            .value("CWAN1_0", L.tr('CWAN1_0'))
            .value("CWAN1_1", L.tr('CWAN1_1'))
            .value("CWAN1", L.tr('CWAN1')) 
            .value("CWAN2", L.tr('CWAN2')); 
            
            
      s.option(L.cbi.InputValue, 'mtu', {
       caption: L.tr('MTU'),
       placeholder: '1476',
       datatype:    'max(1476)',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});
     
     s.option(L.cbi.InputValue, 'ttl', {
       caption: L.tr('TTL'),
       placeholder: '64',
       datatype:    'range(1,255)',
       //datatype: 'ip4addr',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});
            
    
    s.option(L.cbi.InputValue, 'tunnelkey', {
       caption: L.tr('Tunnel key'),
       placeholder: '0-4245967295',
       datatype: 'uinteger',
       optional: true
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});
    
    
    
    s.option(L.cbi.CheckboxValue, 'enablekeepalive', {
    caption: L.tr('Enable keep alive'),
    optional: true
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});
    
      /* s.option(L.cbi.InputValue, 'keepalivehost', {
       caption: L.tr('Keep alive host'),
       placeholder: '192.168.1.1',
       datatype: 'ip4addr',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});*/
     
       s.option(L.cbi.InputValue, 'aliveinterval', {
       caption: L.tr('Keep alive interval'),
       placeholder: '10',
     // datatype:    'range(0,10)',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});
     
       /* s.option(L.cbi.InputValue, 'keepaliveretry', {
       caption: L.tr('Keep alive retry'),
       placeholder: '1-5',
      datatype:    'range(1,5)',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});*/
                            
 },

                       
    ipipFormCallback: function() 
    {
            var map = this;
            var ipipConfigSectionName = map.options.ipipConfigSection;
            var numericExpression = /^[0-9]+$/;
          
            map.options.caption = L.tr(ipipConfigSectionName+' Configuration');
            
            var s1 = map.section(L.cbi.NamedSection, ipipConfigSectionName, {
                    collabsible: true
            });
            
            s1.option(L.cbi.DummyValue, 'typesettings', {
      caption: L.tr(''),
    //  caption: L.tr(a),
    })
    .ucivalue=function()
      {
        var id="<h5><b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbspIPIPTunnel Configuration </b> </h3>";
        return id;
      };
      
       s1.option(L.cbi.InputValue, 'tunnelname', {
       caption: L.tr('Tunnel name'),
       datatype: 'rt_alphanumeric',
    });
     
       
       s1.option(L.cbi.InputValue, 'localexternalIP', {
       caption: L.tr('Local external IP'),
        placeholder: '192.168.6.1',
       datatype: 'ip4addr',
    }).depends({'tempenableipip' : '1'});
    
     s1.option(L.cbi.InputValue, 'remoteexternalIP', {
       caption: L.tr('Remote external IP'),
       placeholder: '192.168.0.1',
       datatype: 'ip4addr',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});
     
   
       
      s1.option(L.cbi.InputValue, 'peertunnelIP', {
       caption: L.tr('Peer tunnel IP'),
       placeholder: '10.1.1.2',
       datatype: 'ip4addr',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});
     
     s1.option(L.cbi.InputValue, 'localtunnelIP', {
       caption: L.tr('Local tunnel IP'),
       placeholder: '10.1.1.12',
       datatype: 'ip4addr',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});
     
     s1.option(L.cbi.InputValue, 'localnetmask', {
       caption: L.tr('Local tunnel net mask'),
       placeholder: '255.255.255.0',
       datatype: 'ip4addr',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});
     
     
       s1.option(L.cbi.InputValue, 'remoteip', {
       caption: L.tr('Remote IP'),
       placeholder: '192.168.10.0/24',
       datatype: 'cidr4',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});
       
 
         
       
                            
     
     
   
},
                       
eoipFormCallback: function() 
{
        var map = this;
        var eoipConfigSectionName = map.options.eoipConfigSection;
        var numericExpression = /^[0-9]+$/;
      
        map.options.caption = L.tr(eoipConfigSectionName+' Configuration');
        
        var s1 = map.section(L.cbi.NamedSection, eoipConfigSectionName, {
                collabsible: true
        });
        
        s1.option(L.cbi.DummyValue, 'typesettings', {
  caption: L.tr(''),
//  caption: L.tr(a),
})
.ucivalue=function()
  {
    var id="<h5><b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbspEOIP Tunnel Configuration </b> </h3>";
    return id;
  };
  
   s1.option(L.cbi.InputValue, 'tunnelname', {
   caption: L.tr('Tunnel name'),
   datatype: 'rt_alphanumeric',
});
 
   
   s1.option(L.cbi.InputValue, 'localexternalIP', {
   caption: L.tr('Local external IP'),
    placeholder: '192.168.6.1',
   datatype: 'ip4addr',
}).depends({'tempenableeoip' : '1'});

s1.option(L.cbi.InputValue, 'remoteexternalIP', {
       caption: L.tr('Remote external IP'),
       placeholder: '192.168.0.1',
       datatype: 'ip4addr',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});
     
   
       
      s1.option(L.cbi.InputValue, 'peertunnelIP', {
       caption: L.tr('Peer tunnel IP'),
       placeholder: '10.1.1.2',
       datatype: 'ip4addr',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});
     
     s1.option(L.cbi.InputValue, 'localtunnelIP', {
       caption: L.tr('Local tunnel IP'),
       placeholder: '10.1.1.12',
       datatype: 'ip4addr',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});
     
     s1.option(L.cbi.InputValue, 'localnetmask', {
       caption: L.tr('Local tunnel net mask'),
       placeholder: '255.255.255.0',
       datatype: 'ip4addr',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});
     
     
       s1.option(L.cbi.InputValue, 'remoteip', {
       caption: L.tr('Remote IP'),
       placeholder: '192.168.10.0/24',
       datatype: 'cidr4',
    }).depends({'ipsecconfig':'1','enableipsec' : '1'});
       
 
 

},


    
    RS485ConfigCreateForm: function(mapwidget,RS485ConfigSectionName) 
    {
            var self = this;
            
            if (!mapwidget)
                    mapwidget = L.cbi.Map;
            
            var map = new mapwidget('tunnelconfig', {
                    prepare: self.RS485FormCallback,
                    RS485ConfigSection: RS485ConfigSectionName
            });
            return map;
    },
  
    ipipConfigCreateForm: function(mapwidget,ipipConfigSectionName) 
    {
            var self = this;
            
            if (!mapwidget)
                    mapwidget = L.cbi.Map;
            
            var map = new mapwidget('ipipconfig', {
                    prepare: self.ipipFormCallback,
                    ipipConfigSection: ipipConfigSectionName
            });
            return map;
    },
    eoipConfigCreateForm: function(mapwidget,eoipConfigSectionName) 
    {
            var self = this;
            
            if (!mapwidget)
                    mapwidget = L.cbi.Map;
            
            var map = new mapwidget('eoipconfig', {
                    prepare: self.eoipFormCallback,
                    eoipConfigSection: eoipConfigSectionName
            });
            return map;
    },
    RS485RenderContents: function(rv) 
    {
        /*var m = new L.cbi.Map('tunnelconfig', {
        //caption:     L.tr('vpnfig1'),
        //description: L.tr('vpnfig1'),
    });*/
        /*var s = m.section(L.cbi.TypedSection, 'defaults', {
        caption:     L.tr('General Setting'),
                    //collabsible:    true
            });*/
                     
            var self = this;

            var list = new L.ui.table({
                    columns: [{
                            caption: L.tr('Sl No'),
                            align: 'left',
                            format: function(v, n) {
                                    var div = $('<p />').attr('id', 'RS485DeviceSerialNo_%s'.format(n));
                                    var serialNo=n+1;
                            return div.append(serialNo);
                            }
                    },
                    {
                            caption: L.tr('Name'),
                                    width:'30%',
                            align: 'left',
                            format: function(v,n) {
                                    var div = $('<p />').attr('id', 'RS485DeviceEventName_%s'.format(n));
                                    return div.append('<strong>'+v+'</strong>');
                            }
                    },
                    {
                            caption: L.tr('Update'),
                            align: 'left',
                            format: function(v, n) {
                                    return $('<div />')
                                            .addClass('btn-group btn-group-sm')
                                            .append(L.ui.button(L.tr('Edit'),'primary', L.tr('Configure'))
                                            .click({ self: self, RS485ConfigSectionName: v }, self.RS485ConfigSectionEdit))
                                            .append(L.ui.button(L.tr('Delete'), 'danger', L.tr('Delete Event'))
                                            .click({ self: self, RS485ConfigSectionName: v }, self.RS485ConfigSectionRemove));
                                           //  list.appendTo('#section_firewall_general');
                            }
                    }]
            });
           //  list.appendTo('#section_firewall_general');
           //  m.insertInto('#section_firewall_general');
            //for (var key in rv) 

            //{
//console.log(rv);
                    //if (rv.hasOwnProperty(key)) 
                    //{
//var obj = rv[key];
                    //let tabtype = obj.uniqueid
//console.log(tabtype);
//if(tabtype=="gretunnel"){
   
//list2.row([key,key,key]);

//}
//else{
//list.row([key,key,key]);
//}
                          
                    //}
            //}
            
            
         for (var key in rv) 
                {
                        if (rv.hasOwnProperty(key)) 
                        {
                                var obj = rv[key];
                                list.row([key,key,key]); 
                        }
                }
                  
              
           // $('#map').append(list.render());
                     
           
          $('#section_vpn_ipsec').append(list.render());	
 //$('#section_vpn_ipip').append(list2.render());
            
        // m.insertInto('#section_vpn_ipsec'); 	
        
        //$('#map').append(list.render());
          
    },
  
    RS485RenderContentsipip: function(rv) 
    {
        /*var m = new L.cbi.Map('tunnelconfig', {
        //caption:     L.tr('vpnfig1'),
        //description: L.tr('vpnfig1'),
    });*/
        /*var s = m.section(L.cbi.TypedSection, 'defaults', {
        caption:     L.tr('General Setting'),
                    //collabsible:    true
            });*/
                     
            var self = this;

              var list2 = new L.ui.table({
                    columns: [{
                            caption: L.tr('Sl No'),
                            align: 'left',
                            format: function(v, n) {
                                    var div = $('<p />').attr('id', 'RS485DeviceSerialNo_%s'.format(n));
                                    var serialNo=n+1;
                            return div.append(serialNo);
                            }
                    },
                    {
                            caption: L.tr('Name'),
                                    width:'30%',
                            align: 'left',
                            format: function(v,n) {
                                    var div = $('<p />').attr('id', 'RS485DeviceEventName_%s'.format(n));
                                    return div.append('<strong>'+v+'</strong>');
                            }
                    },
                    {
                            caption: L.tr('Update'),
                            align: 'left',
                            format: function(v, n) {
                                    return $('<div />')
                                            .addClass('btn-group btn-group-sm')
                                            .append(L.ui.button(L.tr('Edit'),'primary', L.tr('Configure'))
                                            .click({ self: self, ipipConfigSectionName: v }, self.ipipConfigSectionEdit))
                                            .append(L.ui.button(L.tr('Delete'), 'danger', L.tr('Delete Event'))
                                            .click({ self: self, ipipConfigSectionName: v }, self.ipipConfigSectionRemove));
                                           //  list.appendTo('#section_firewall_general');
                            }
                    }]
            });

           //  list.appendTo('#section_firewall_general');
           //  m.insertInto('#section_firewall_general');
  for (var key in rv) 
                {
                        if (rv.hasOwnProperty(key)) 
                        {
                                var obj = rv[key];
                                list2.row([key,key,key]); 
                        }
                }
                  
              
              
           // $('#map').append(list.render());
                     
           
         // $('#section_vpn_ipsec').append(list.render());	
 $('#section_vpn_ipip').append(list2.render());
            
        // m.insertInto('#section_vpn_ipsec'); 	
        
        //$('#map').append(list.render());
          
    },
  
    
    RS485RenderContentseoip: function(rv) 
    {
        /*var m = new L.cbi.Map('tunnelconfig', {
        //caption:     L.tr('vpnfig1'),
        //description: L.tr('vpnfig1'),
    });*/
        /*var s = m.section(L.cbi.TypedSection, 'defaults', {
        caption:     L.tr('General Setting'),
                    //collabsible:    true
            });*/
                     
            var self = this;

              var list3 = new L.ui.table({
                    columns: [{
                            caption: L.tr('Sl No'),
                            align: 'left',
                            format: function(v, n) {
                                    var div = $('<p />').attr('id', 'RS485DeviceSerialNo_%s'.format(n));
                                    var serialNo=n+1;
                            return div.append(serialNo);
                            }
                    },
                    {
                            caption: L.tr('Name'),
                                    width:'30%',
                            align: 'left',
                            format: function(v,n) {
                                    var div = $('<p />').attr('id', 'RS485DeviceEventName_%s'.format(n));
                                    return div.append('<strong>'+v+'</strong>');
                            }
                    },
                    {
                            caption: L.tr('Update'),
                            align: 'left',
                            format: function(v, n) {
                                    return $('<div />')
                                            .addClass('btn-group btn-group-sm')
                                            .append(L.ui.button(L.tr('Edit'),'primary', L.tr('Configure'))
                                            .click({ self: self, eoipConfigSectionName: v }, self.eoipConfigSectionEdit))
                                            .append(L.ui.button(L.tr('Delete'), 'danger', L.tr('Delete Event'))
                                            .click({ self: self, eoipConfigSectionName: v }, self.eoipConfigSectionRemove));
                                           //  list.appendTo('#section_firewall_general');
                            }
                    }]
            });

           //  list.appendTo('#section_firewall_general');
           //  m.insertInto('#section_firewall_general');
  for (var key in rv) 
                {
                        if (rv.hasOwnProperty(key)) 
                        {
                                var obj = rv[key];
                                list3.row([key,key,key]); 
                        }
                }
                  
              
              
           // $('#map').append(list.render());
                     
           
         // $('#section_vpn_ipsec').append(list.render());	
 $('#section_vpn_eoip').append(list3.render());
            
        // m.insertInto('#section_vpn_ipsec'); 	
        
        //$('#map').append(list.render());
          
    },
  
    RS485ConfigSectionAdd: function () 
    {
debugger
            var self = this;
 var sensorSectionOptions={}
 var RS485ConfigSectionName = $('#field_NewEvent_name').val();

 //if(RS485ConfigSectionName ==""){
//RS485ConfigSectionName = $('#field_NewEvent_name').val();

//uniqueid="gretunnel"
//sensorSectionOptions={EEnable:0,uniqueid};  
//RS485ConfigSectionName = $('#field_NewEvent_name_ipip').val();
 //sensorSectionOptions={EEnable:0,uniqueid};  
//}
//else{
//uniqueid="ipiptunnel"
//sensorSectionOptions = {EEnable:0,uniqueid};


         
           
          
           
           // this.RS485GetUCISections("vpnconfog1","RS485Config").then(function(rv) {
           this.RS485GetUCISections("tunnelconfig","tunnelconfig").then(function(rv) {
                    var keys = Object.keys(rv);
                    var keysLength=keys.length;
                   // alert(keysLength);
                    if(keysLength>=5)
                    {
                            alert("Only 5 connections can be configured");
                    }
                    else
                    {
                         //   self.RS485CreateUCISection("tunnelconfig","RS485Config",RS485ConfigSectionName,sensorSectionOptions).then(function(rv){
                              self.RS485CreateUCISection("tunnelconfig","tunnelconfig",RS485ConfigSectionName,sensorSectionOptions).then(function(rv){
                                    if(rv)
                                    {
                                            if (rv.section)
                                            {
                                                    self.RS485CommitUCISection("tunnelconfig").then(function(res){
                                                              
                            if (res != 0) 
                                                            {
                                alert("Error:New Event Configuration");
                                                            }
                                                            else 
                                                            {
                                                                    location.reload();
                                                            }
                                                    });
                                            };
                                    };
                            }); 
                    }
            });
    },
    
    
          ipipConfigSectionAdd: function () 
        {
                var self = this;
                var ipipConfigSectionName = $('#field_NewEvent_name_ipip').val();
                var sensorSectionOptions = {EEnable:0};
               
               // this.RS485GetUCISections("vpnconfog1","RS485Config").then(function(rv) {
               this.RS485GetUCISections("ipipconfig","ipipconfig").then(function(rv) {
                        var keys = Object.keys(rv);
                        var keysLength=keys.length;
                       // alert(keysLength);
                        if(keysLength>=5)
                        {
                                alert("Only 5 connections can be configured");
                        }
                        else
                        {
                             //   self.RS485CreateUCISection("vpnconfig1","RS485Config",RS485ConfigSectionName,sensorSectionOptions).then(function(rv){
                                  self.RS485CreateUCISection("ipipconfig","ipipconfig",ipipConfigSectionName,sensorSectionOptions).then(function(rv){
                                        if(rv)
                                        {
                                                if (rv.section)
                                                {
                                                        self.RS485CommitUCISection("ipipconfig").then(function(res){
                                                              	
								if (res != 0) 
                                                                {
									alert("Error:New Event Configuration");
                                                                }
                                                                else 
                                                                {
                                                                        location.reload();
                                                                }
                                                        });
                                                };
                                        };
                                }); 
                        }
                });
        },
    
        eoipConfigSectionAdd: function () 
        {
                var self = this;
                var eoipConfigSectionName = $('#field_NewEvent_name_eoip').val();
                var sensorSectionOptions = {EEnable:0};
               
               // this.RS485GetUCISections("vpnconfog1","RS485Config").then(function(rv) {
               this.RS485GetUCISections("eoipconfig","eoipconfig").then(function(rv) {
                        var keys = Object.keys(rv);
                        var keysLength=keys.length;
                       // alert(keysLength);
                        if(keysLength>=5)
                        {
                                alert("Only 5 connections can be configured");
                        }
                        else
                        {
                             //   self.RS485CreateUCISection("vpnconfig1","RS485Config",RS485ConfigSectionName,sensorSectionOptions).then(function(rv){
                                  self.RS485CreateUCISection("eoipconfig","eoipconfig",eoipConfigSectionName,sensorSectionOptions).then(function(rv){
                                        if(rv)
                                        {
                                                if (rv.section)
                                                {
                                                        self.RS485CommitUCISection("eoipconfig").then(function(res){
                                                              	
								if (res != 0) 
                                                                {
									alert("Error:New Event Configuration");
                                                                }
                                                                else 
                                                                {
                                                                        location.reload();
                                                                }
                                                        });
                                                };
                                        };
                                }); 
                        }
                });
        },
    
    RS485ConfigSectionRemove: function(ev) 
    {
    var self = ev.data.self;
    var RS485ConfigSectionName = ev.data.RS485ConfigSectionName;
    //self.RS485DeleteUCISection("tunnelconfig","RS485Config",RS485ConfigSectionName).then(function(rv){
    self.RS485DeleteUCISection("tunnelconfig","tunnelconfig",RS485ConfigSectionName).then(function(rv){
        if(rv == 0){
            self.RS485CommitUCISection("tunnelconfig").then(function(res){
                if (res != 0)
                {
                    alert("Error: Delete Configuration");
                }
                else 
                                    {
                    location.reload();
                }
            });
        };
    });
},
    
     ipipConfigSectionRemove: function(ev) 
    {
    var self = ev.data.self;
    var ipipConfigSectionName = ev.data.ipipConfigSectionName;
    //self.RS485DeleteUCISection("tunnelconfig","RS485Config",RS485ConfigSectionName).then(function(rv){
    self.RS485DeleteUCISection("ipipconfig","ipipconfig",ipipConfigSectionName).then(function(rv){
        if(rv == 0){
            self.RS485CommitUCISection("ipipconfig").then(function(res){
                if (res != 0)
                {
                    alert("Error: Delete Configuration");
                }
                else 
                                    {
                    location.reload();
                }
            });
        };
    });
},
    
eoipConfigSectionRemove: function(ev) 
{
var self = ev.data.self;
var eoipConfigSectionName = ev.data.eoipConfigSectionName;
//self.RS485DeleteUCISection("tunnelconfig","RS485Config",RS485ConfigSectionName).then(function(rv){
self.RS485DeleteUCISection("eoipconfig","eoipconfig",eoipConfigSectionName).then(function(rv){
    if(rv == 0){
        self.RS485CommitUCISection("eoipconfig").then(function(res){
            if (res != 0)
            {
                alert("Error: Delete Configuration");
            }
            else 
                                {
                location.reload();
            }
        });
    };
});
},
    RS485ConfigSectionEdit: function(ev) 
    {
            var self = ev.data.self;
            var RS485ConfigSectionName = ev.data.RS485ConfigSectionName;
            return self.RS485ConfigCreateForm(L.cbi.Modal,RS485ConfigSectionName).show();
    },
 
          
        ipipConfigSectionEdit: function(ev) 
    {
            var self = ev.data.self;
            var ipipConfigSectionName = ev.data.ipipConfigSectionName;
            return self.ipipConfigCreateForm(L.cbi.Modal,ipipConfigSectionName).show();
    },       
           
           
    eoipConfigSectionEdit: function(ev) 
    {
            var self = ev.data.self;
            var eoipConfigSectionName = ev.data.eoipConfigSectionName;
            return self.eoipConfigCreateForm(L.cbi.Modal,eoipConfigSectionName).show();
    },       
         

    execute:function()
    {
    /*		var self = this;
        var activeTab = self.getCookie("LastActiveTab");
    var action = self.getCookie("LastAction");
    if (action) {
        $('.TabC').removeClass('active');
        $('.'+activeTab).addClass('active');
        document.cookie="LastAction=";
    }
    else {
        $('.TabC').removeClass('active');
        $('.TabGn').addClass('active');
    }*/
    
    var self = this;
          
    var m = new L.cbi.Map('tunnelconfig', {
                });
        
    var s = m.section(L.cbi.NamedSection, 'general', {
        caption:L.tr('General Configurations')
    });
    
    
    s.option(L.cbi.CheckboxValue, 'enablegre', {
              caption:        L.tr('Enable GRE Tunnel'),         
              optional:    true
            });
            
   s.option(L.cbi.CheckboxValue, 'enableipip', {
              caption:        L.tr('Enable IPIP Tunnel'),         
              optional:    true
            }); 
            
  s.option(L.cbi.CheckboxValue, 'enableeoip', {
              caption:        L.tr('Enable EoIP Tunnel'),         
              optional:    true
            });                
                   
      
   m.insertInto('#section_vpn_general');  
   
   //var m1 = new L.cbi.Map('ipipconfig', {
                //});

    
   ////PPTP
   
   
         
   //m1.insertInto('#section_vpn_ipip');
   
     
      
             var self = this;
             //gre
            $('#AddNewconnectionipsec').click(function() { 
                    self.RS485ConfigSectionAdd();
            });
          //  self.RS485GetUCISections("tunnelconfig","RS485Config").then(function(rv) {
          self.RS485GetUCISections("tunnelconfig","tunnelconfig").then(function(rv) {
                    self.RS485RenderContents(rv);
            });           
           

           //ipip
            $('#AddNewconnectionipip').click(function() { 
                self.ipipConfigSectionAdd();
          });
            self.RS485GetUCISections("ipipconfig","ipipconfig").then(function(rv) {
                self.RS485RenderContentsipip(rv);
          }); 


//eoip 
        $('#AddNewconnectioneoip').click(function() { 
            self.eoipConfigSectionAdd();
          });
    self.RS485GetUCISections("eoipconfig","eoipconfig").then(function(rv) {
        self.RS485RenderContentseoip(rv);
         }); 


    
          $('#update_tunnel').click(function() {
        L.ui.loading(true);
        self.updategreconfig('configure').then(function(rv) {
            //alert(rv);
           // L.ui.loading(false);
                L.ui.dialog(
                    L.tr('update configuration'),[
                        $('<pre />')
                        .addClass('alert alert-success')
                        .text(rv)
                    ],
                   
                    { style: 'close'}
                );
                
               });
               L.ui.loading(false);
        });
        
            $('#update_tunnel_ipip').click(function() {
        L.ui.loading(true);
        self.updateipipconfig('configure').then(function(rv) {
            //alert(rv);
           // L.ui.loading(false);
                L.ui.dialog(
                    L.tr('update configuration'),[
                        $('<pre />')
                        .addClass('alert alert-success')
                        .text(rv)
                    ],
                   
                    { style: 'close'}
                );
                
               });
               L.ui.loading(false);
        });

        $('#update_tunnel_eoip').click(function() {
            L.ui.loading(true);
            self.updateeoipconfig('configure').then(function(rv) {
                //alert(rv);
               // L.ui.loading(false);
                    L.ui.dialog(
                        L.tr('update configuration'),[
                            $('<pre />')
                            .addClass('alert alert-success')
                            .text(rv)
                        ],
                       
                        { style: 'close'}
                    );
                    
                   });
                   L.ui.loading(false);
            });
        self.RS485GetUCISections("tunnelconfig","genericconfig").then(function(rv) {
        self.RS485GetUCISections("ipipconfig","genericconfig").then(function(rv) {
		self.RS485GetUCISections("eoipconfig","genericconfig").then(function(rv) {
            for (var key in rv) 
            {
                    if (rv.hasOwnProperty(key)) 
                    {
                            var obj = rv[key];
                            var running = obj.openvpnrunning;
                            if(running=='0')
                            {
                                    var AppstartCreateButton=$('<button/>', {
                                            class: 'btn btn-primary',
                                            text: 'Start',
                                            id: 'start',
                                            title: 'Start the Apps',
                                            style: 'width:110px',
                                            on : {
                                                    click: function(e) {
                                                            L.ui.loading(true);
                                                            self.startopenvpnservice().then(function(rv) {
                                                                    L.ui.loading(false);
                                                                    L.ui.dialog(
                                                                    
                                                                            L.tr('Started the openvpn service'),[
                                                                                   $('<p />').text(L.tr('Output')),
                                                                                    $('<pre />')
                                                                                            .addClass('alert alert-info')
                                                                                            .text(rv),
                                                                            ],
                                                                            { style: 'close',
                                                                                    close:function()
                                                                                    {
                                                                                            location.reload();
                                                                                    }
                                                                            }
                                                                    );
                                                         });
                                                    }
                                            }
                                    });
                                    $("#btn-group").append(AppstartCreateButton);
                            }
                            
                            if(running=='1')
                            {
                                    var AppStopCreateButton=$('<button/>', {
                                            class: 'btn btn-danger',
                                            text: 'Stop',
                                            title: 'Stop the Apps',
                                            style: 'width:110px',
                                            on : {
                                                    click: function(e) {
                                                             L.ui.loading(true);
                                                            self.stopopenvpnservice().then(function(rv) {
                                                                    L.ui.loading(false);
                                                                    L.ui.dialog(
                                                                            L.tr('Stopped the openvpn service'),[
                                                                                    $('<pre />')
                                                                                            .addClass('alert alert-danger')
                                                                                            .text(rv),
                                                                            ],
                                                                            { style: 'close',
                                                                                    close:function()
                                                                                    {
                                                                                        
                                                                                            location.reload();
                                                                                    }
                                                                            }
                                                                    );
                                                        });
                                                    }
                                            }
                                    });
                                    $("#btn-group").append(AppStopCreateButton);
                            }
                    }
            }
      });
  });
});

       
     
            
        //m.insertInto('#map');
      //  m.appendTo('#sectiontab_vpn_general');
      
      s.commit=function(){
        
             self.updateopenvpnconfig('enableopenvpn').then(function(rv) {
                 //alert("Enabling openvpn");
                           
            });
       }
                        
    }
  
   
        
    
});


