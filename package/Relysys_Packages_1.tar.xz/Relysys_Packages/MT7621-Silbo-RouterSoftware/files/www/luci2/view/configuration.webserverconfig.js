L.ui.view.extend({

    title: L.tr('WebServer Configuration'),
      RunUdev:L.rpc.declare({
        object:'command',
        method:'exec',
        params : ['command','args'],
    }),
    
    
     fGetUCISections: L.rpc.declare({
        object: 'uci',
        method: 'get',
       // params: [ 'config', 'type', 'section']  
              params: [ 'config', 'type']  
       
    }),
    
      updatewebserverconfig: L.rpc.declare({
        object: 'rpc-webserverConfig',
        method: 'configure',
        params: ['application','action'],
        expect: { output: '' }
        }),
  
    execute:function() {
        var self = this;
        var m = new L.cbi.Map('webserverconfig', {
        });
        
        var s = m.section(L.cbi.NamedSection, 'webserverconfig', {
            caption:L.tr('WebServer Configuration')
        }); 
    
			
		/* s.option('L.cbi.InputValue, 'port', {
				caption: L.tr('Port'),
		});*/
           
         s.option( L.cbi.InputValue, 'port', {
            caption: L.tr('Port'),
            datatype: 'port'
        });  
        
		s.option( L.cbi.CheckboxValue, 'enablentpsync', {
		caption: L.tr('Enable NTP Sync'),
		});
		
		 s.option( L.cbi.InputValue, 'ntpserver', {
		caption: L.tr('NTP Server'),
		datatype: 'host'
		}).depends({'enablentpsync':'1'});                                      
		  
		 s.option( L.cbi.InputValue, 'ntpsyncinterval', {
		caption: L.tr('NTP Sync Interval(In Minutes)'),
		}).depends({'enablentpsync':'1'});                                      
     		
       s.commit=function(){
			
                self.updatewebserverconfig('configure').then(function(rv) {
				               
                });
           }
                   
		                        
        return m.insertInto('#map');
    }
});
