L.ui.view.extend({

    title: L.tr('Mac Address Binding Configuration'),
      RunUdev:L.rpc.declare({
        object:'command',
        method:'exec',
        params : ['command','args'],
    }),
    
    
     fGetUCISections: L.rpc.declare({
        object: 'uci',
        method: 'get',
       // params: [ 'config', 'type', 'section']  
              params: [ 'config', 'type']  
       
    }),
    
      updateinterfaceconfig: L.rpc.declare({
        object: 'rpc-updatemacconfig',
        method: 'configure',
        params: ['application','action'],
        expect: { output: '' }
        }),
  
    execute:function() {
        var self = this;
        var m = new L.cbi.Map('macconfig', {
        });
        
        var s = m.section(L.cbi.NamedSection, 'macconfig', {
            caption:L.tr('Mac Address Binding')
        });
        
         
        s.option(L.cbi.InputValue, 'name', {
                        caption: L.tr('Device Name'),
                        optional: true 
                }).depends({'macbindconfig':'1'});
                
        
        s.option(L.cbi.InputValue, 'macaddress', {
                        caption: L.tr('MAC Address'),
                         datatype: 'macaddr',
                        optional: true 
                }).depends({'macbindconfig':'1'});
                
        
        s.option(L.cbi.InputValue, 'ipaddress', {
                        caption: L.tr('IP Address'),
                        datatype: 'ip4addr',
                        optional: true 
                }).depends({'macbindconfig':'1'});
        
        
        
  s.commit=function(){
        self.updateinterfaceconfig('Update','updateinterface').then(function(rv) {
               
                });
        }
		                        
        return m.insertInto('#map');
        
   }     

});
