
#!/bin/bash


# Specify output file
output_file="/etc/snmp/wireless_info.txt"

# Clear existing content in the output file
> "$output_file"

# Function to get Remaining value from uci and write to file
get_and_write() {
    local uci_key="$1"
    local parameter_name="$2"
    local output_file="$3"
    local value=$(uci get "$uci_key")
    
    echo "$parameter_name : $value" >> "$output_file"
}

# Function to get Bandwidth from uci and write to file
get_and_write_bandwidth() {
    local uci_key="$1"
    local parameter_name="$2"
    local output_file="$3"
    local value=$(uci get "$uci_key")
    
    #WIFI 2.4GHz
    if [ "$uci_key" = "wireless.ra0.htmode" ]
    then
		if [ "$value" = "0" ];then
			value="20 MHz"
		else
			value="20/40 MHz"
		fi		
	else
	#WIFI 5GHz
		if [ "$value" = "VHT20" ];then
			value="20 MHz"
		elif [ "$value" = "VHT40" ];then
			value="20/40 MHz"
		elif [ "$value" = "VHT80" ];then
			value="80 MHz"
		else
			#Input value is disable from GUI
			value=0
		fi	
    fi
    
    echo "$parameter_name : $value" >> "$output_file"
}

# Function to get Country Region from dat file for 2.4 GHz and write to file
get_and_write_country_region()
{
	local uci_key="$1"
    local parameter_name="$2"
    local output_file="$3"
    
    #WIFI 2.4
	if [ "$uci_key" = "CountryRegion_wifi2" ];then
		value=$(cat /etc/wireless/mt7615/mt7615.1.dat | grep -w CountryRegion | cut -d "=" -f 2)
	#WIFI 5
	else
		value="auto"
	fi
	
	echo "$parameter_name : $value" >> "$output_file"
}


# 2.4GHz Information
echo "2.4GHz Configuration:" >> "$output_file"
get_and_write "wireless.ra0_ap.mode" "Radio_Mode_2.4GHz" "$output_file"
get_and_write "wireless.ra0.band" "WirelessMode_2.4GHz" "$output_file"
get_and_write "wireless.ra0.country" "Country_Code_2.4GHz" "$output_file"
get_and_write_country_region "CountryRegion_wifi2" "Country_Region_2.4GHz" "$output_file"
get_and_write "wireless.ra0.channel" "Channel_2.4GHz" "$output_file"
get_and_write_bandwidth "wireless.ra0.htmode" "Channel_Bandwidth_2.4GHz" "$output_file"
get_and_write "wireless.ra0.txpower" "TXpower_2.4GHz" "$output_file"
get_and_write "wireless.ra0_ap.ssid" "Radio_2.4GHz_SSID" "$output_file"

# Add a separator between 2.4GHz and 5.0GHz sections
echo -e "\n5.0GHz Configuration:" >> "$output_file"

# 5.0GHz Information
get_and_write "wireless.rai0_ap.mode" "Radio_Mode_5.0GHz" "$output_file"
get_and_write "wireless.rai0.band" "WirelessMode_5.0GHz" "$output_file"
get_and_write "wireless.rai0.country" "Country_Code_5.0GHz" "$output_file"
get_and_write_country_region "CountryRegion_wifi5" "Country_Region_5.0GHz" "$output_file"
get_and_write "wireless.rai0.channel" "Channel_5.0GHz" "$output_file"
get_and_write_bandwidth "wireless.rai0.htmode" "Channel_Bandwidth_5.0GHz" "$output_file"
get_and_write "wireless.rai0.txpower" "TXpower_5.0GHz" "$output_file"
get_and_write "wireless.rai0_ap.ssid" "Radio_SSID_5.0GHz" "$output_file"

echo "Wireless information has been collected and stored in $output_file."
