#!/bin/sh 

# File containing the HTML form
HTML_FILE="/etc/nodogsplash/htdocs/splash.html"

enable_nodogsplash=$(uci get nodogsplash.nodogsplash.enabled)

if [ "$enable_nodogsplash" = "1" ]
then
	redirect_enabled=$(uci get nodogsplash.nodogsplash.redirect_enabled)
	redirect_url=$(uci get nodogsplash.nodogsplash.redirect_url)
	
	if [ "$redirect_enabled" = "1" ]
	then
		
		#Copy redirect splash to original splash dir.
		cp /root/InterfaceManager/script/nodogsplash/splash.html /etc/nodogsplash/htdocs/splash.html
		
		# Replace the current redir value with the new URL (simple string matching)
		sed -i '/name="redir"/ s|value="[^"]*"|value="'"$redirect_url"'"|' $HTML_FILE
		
		sed -i '/http-equiv="refresh"/ s|url=[^"]*|url='"$redirect_url"'|' $HTML_FILE

		
	fi
	
	/etc/init.d/nodogsplash restart
else
	/etc/init.d/nodogsplash stop
fi
