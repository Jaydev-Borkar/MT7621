#!/bin/sh

#Check if captive portal is enabled.
cp_check=$(uci get nodogsplash.nodogsplash.enabled)

if [ "$cp_check" = "1" ]
then
	
	check_relay=$(uci get networkinterfaces.SW_LAN.enable_relay)
	
	if [ "$check_relay" = "1" ]
	then
	
		#Get the dhcp-relay server ip address.
		relay_server_ip=$(uci get networkinterfaces.SW_LAN.relay_serverip)
		
		# Modify the last digit(host portion) in the ip address, since that is fixed.
		wanIP="${relay_server_ip%.*}.4"
		bridgeIP="${relay_server_ip%.*}.130"
		
		uci set networkinterfaces.SW_LAN.enable_dhcpserver="0"
		uci set networkinterfaces.SW_LAN.enable_dns="0"
		uci set networkinterfaces.SW_LAN.staticIP="$bridgeIP"
		uci set networkinterfaces.SW_LAN.staticnetmask='255.255.255.128'
		uci set networkinterfaces.SW_LAN.enable_relay='1'
		uci set networkinterfaces.SW_LAN.relay_serverip="$relay_server_ip"
		
		uci set networkinterfaces.EWAN1.staticIP="$wanIP"
		uci set networkinterfaces.EWAN1.staticgateway='192.168.190.1'
		uci set networkinterfaces.EWAN1.staticnetmask='255.255.255.248'
		
		uci commit networkinterfaces
	fi
else
	echo -n > /etc/dnsmasq.conf
	
	/etc/init.d/nodogsplash stop
fi
