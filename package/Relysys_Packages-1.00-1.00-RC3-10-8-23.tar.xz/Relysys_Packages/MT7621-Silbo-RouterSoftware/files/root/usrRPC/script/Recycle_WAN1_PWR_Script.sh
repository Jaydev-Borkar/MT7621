#!/bin/sh

. /lib/functions.sh


########################################################################
#  Description:This script basically drives GPIO498 LOW for 5 seconds
#              before turning it HIGH again. This turns OFF the mini-PCIe 
#              2G/3G/4G modem in slot J5 (USB3) OFF for 5 seconds
########################################################################
ComPort="$1"
ReadSystemGpioFile()                               
{                                                    
        config_load "$SystemGpioConfig"              
        config_get Modem1PowerGpio gpio modem1powergpio
        config_get Modem1PowerOnValue gpio modem1poweronvalue
        config_get Modem1PowerOffValue gpio modem1poweroffvalue
}

SystemGpioConfig="/etc/config/systemgpio"

ReadSystemGpioFile

TmpSim1DataFile="/tmp/sim1data"
TmpSim2DataFile="/tmp/sim2data"
TmpSimDataFile="/tmp/simdata"

echo 0 > "$TmpSim1DataFile"
echo 0 > "$TmpSim2DataFile"
echo 0 > "$TmpSimDataFile"

echo " " >> /tmp/all_logs.txt
echo "<Recycle_WAN1_PWR_Script.sh> $ComPortSymLink ..." >> /tmp/all_logs.txt

pid_AddInterface=$(ps w | grep "AddInterface.sh" | grep -v grep | awk '{print $1}')
kill -9 $pid_AddInterface 

status=$(/bin/at-cmd $ComPort at+qpowd)

if [ -z "$status" ]                                                                                                        
then
	echo "<Recycle_WAN1_PWR_Script.sh> REBOOT VIA GPIO ..." >> /tmp/all_logs.txt

	echo "$Modem1PowerOffValue" > /sys/class/gpio/gpio$Modem1PowerGpio/value
	sleep 5
	echo "$Modem1PowerOnValue" > /sys/class/gpio/gpio$Modem1PowerGpio/value
fi

exit 0


