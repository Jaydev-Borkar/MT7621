L.ui.view.extend({
        title: L.tr('URL FILTERING'),
        description: L.tr(''),

        RS485GetUCISections: L.rpc.declare({
                object: 'uci',
                method: 'get',
                params: ['config', 'type'],
                expect: { values: {} }
        }),

        RS485CreateUCISection: L.rpc.declare({
                object: 'uci',
                method: 'add',
                params: ['config', 'type', 'values']
        }),

        RS485CommitUCISection: L.rpc.declare({
                object: 'uci',
                method: 'commit',
                params: ['config']
        }),

        RS485DeleteUCISection: L.rpc.declare({
                object: 'uci',
                method: 'delete',
                params: ['config', 'type', 'section']
        }),

        updatefirewallconfig: L.rpc.declare({
                object: 'rpc-updateipconfig',
                method: 'configure',
                expect: { output: '' }
        }),

        updateopenvpnconfig: L.rpc.declare({
                object: 'rpc-updateipconfig',
                method: 'enableopenvpn',
                expect: { output: '' }
        }),

        deletecertficates: L.rpc.declare({
                object: 'rpc-updateipconfig',
                method: 'delete',
                expect: { output: '' }
        }),

        countcertficates: L.rpc.declare({
                object: 'rpc-updateipconfig',
                method: 'countcertfiles',
                expect: { output: '' }
        }),

        startopenvpnservice: L.rpc.declare({
                object: 'rpc-updateipconfig',
                method: 'startopenvpn',
                expect: { output: '' }
        }),

        stopopenvpnservice: L.rpc.declare({
                object: 'rpc-updateipconfig',
                method: 'stopopenvpn',
                expect: { output: '' }
        }),



        TestArchive: L.rpc.declare({
                object: 'rpc-updateipconfig',
                method: 'testarchive',
                params: ['archive'],
        }),


        handleArchiveUpload: function () {
                var self = this;
                L.ui.archiveUploadcerts(
                        L.tr('Archive Upload'),
                        L.tr('Select the archive and click on "%c" button to proceed.').format(L.tr('Apply')), {
                        success: function (info) {
                                self.handleArchiveVerify(info);
                        }
                }
                );
        },

        handleArchiveVerify: function (info) {
                var self = this;
                var archive = $('[name=filename]').val();

                L.ui.loading(true);
                self.TestArchive(archive).then(function (TestArchiveOutput) {

                        L.ui.dialog(
                                L.tr('TestArchive'), [
                                $('<p />').text(L.tr('Success')),
                                $('<pre />')
                                        .addClass('alert-success')
                                        .text("file uploaded successfully")
                        ], {
                                style: 'close',

                        }
                        );
                        L.ui.loading(false);
                });

        },

        RS485FormCallback: function () {
                var map = this;
                var RS485ConfigSectionName = map.options.RS485ConfigSection;
                var numericExpression = /^[0-9]+$/;

                map.options.caption = L.tr(RS485ConfigSectionName + ' Configuration');

                var s = map.section(L.cbi.NamedSection, RS485ConfigSectionName, {

                        collabsible: true
                });
                console.log(RS485ConfigSectionName)
                s.option(L.cbi.CheckboxValue, 'Enable', {
                        caption: L.tr('Enable/Disable')
                })

                s.option(L.cbi.InputValue, 'RS485ConfigSectionName', {

                        caption: L.tr('Url Blocking'),
                        datatype: 'url',
                }).depends({ 'Enable': '1' });

        },



        RS485RenderContents: function (rv) {
                var self = this;
                configdata = function () {
                        return rv;
                }
                var list = new L.ui.table({
                        columns: [{
                                caption: L.tr('Sl No'),
                                align: 'center',
                                format: function (v, n) {
                                        var div = $('<p />').attr('id', 'remoteserverIP%s'.format(n));
                                        var serialNo = n + 1;
                                        return div.append(serialNo);
                                }
                        },

                        {
                                caption: L.tr('Url Blocking'),
                                width: '30%',
                                align: 'center',
                                format: function (v, n) {
                                        var div = $('<p />').attr('id', 'remoteserverIP%s'.format(n));
                                        return div.append(v);

                                }
                        },
                        {
                                caption: L.tr('Status'),
                                width: '30%',
                                align: 'center',
                                format: function (v, n) {
                                        console.log(this.status)
                                        var div = $('<label />').attr('id', 'RS485DeviceEventName_%s'.format(n)).attr('class', 'switch');
                                        return div.append(`<input type="checkbox" ${v} disabled  id="PortforwardingstatusSwitch${n}" onclick="changestatus(${n})">
          <span class="slider round"></span>`);
                                }
                        },
                        {
                                caption: L.tr('Update'),
                                align: 'center',
                                format: function (v, n) {
                                        return $('<div />')
                                                .addClass('btn-group btn-group-sm')
                                                .append(L.ui.button(L.tr('Edit'), 'primary', L.tr('Configure'))
                                                        .click({ self: self, RS485ConfigSectionName: v }, self.RS485ConfigSectionEdit))
                                                .append(L.ui.button(L.tr('Delete'), 'danger', L.tr('Delete Event'))
                                                        .click({ self: self, RS485ConfigSectionName: v }, self.RS485ConfigSectionRemove));

                                }
                        }]
                });
                for (var key in rv) {
                        if (rv.hasOwnProperty(key)) {
                                var obj = rv[key];
                                console.log(obj);
                                var RS485ConfigSectionName = obj.RS485ConfigSectionName
                                RS485ConfigSectionName = RS485ConfigSectionName.replaceAll("/", "")

                                var status = obj.UrlfilteringSwitch;
                                if (status == "1") {
                                        status = "checked"
                                }
                                else {
                                        status = ""
                                }
                                list.row([key, RS485ConfigSectionName, status, key]);
                        }
                }
                $('#section_vpn_ipsec').append(list.render());
        },

        RS485ConfigSectionAdd: function (id) {
                var self = this;
                var UrlfilteringSwitch = $('#UrlfilteringSwitch')[0].checked;
                var RS485ConfigSectionName = $('#UrlBlocking').val();
                RS485ConfigSectionName = RS485ConfigSectionName.replaceAll("/", "")
                RS485ConfigSectionName = "/" + RS485ConfigSectionName + "/";
                var sensorSectionOptions = { EEnable: 0, UrlfilteringSwitch: UrlfilteringSwitch, RS485ConfigSectionName: RS485ConfigSectionName };

                this.RS485GetUCISections("urlipconfig", "urlipconfig").then(function (rv) {
                        var keys = Object.keys(rv);
                        var uniquedevicename = [];

                        for (var key in rv) {
                                var obj = rv[key];
                            uniquedevicename.push(obj.RS485ConfigSectionName)
                        }
                        console.log(uniquedevicename);
                        debugger
                        var keysLength = keys.length;
                        if (id != "") {
                                console.log(id);
                           
                        }
                        if (keysLength >= 10) {
                                alert("Only 10 connections can be configured");
                        }
                          else {
                                if (id != "") {
                                        var editfields = rv[id]
                                        var key = editfields.RS485ConfigSectionName;
                                        console.log(key);
                                        self.RS485DeleteUCISection("urlipconfig", "urlipconfig", id).then(function (rv) {
                                                if (rv == 0) {
                                                        self.RS485CommitUCISection("urlipconfig").then(function (res) {
                                                                if (res != 0) {
                                                                        alert("Error: Delete Configuration");
                                                                }
                                                                else {
                                                                        location.reload();
                                                                }
                                                        });
                                                };
                                        });
                                  self.RS485CreateUCISection("urlipconfig", "urlipconfig", sensorSectionOptions).then(function (rv) {
                                          if (rv) {
                                                  if (rv.section) {
                                                          self.RS485CommitUCISection("urlipconfig").then(function (res) {
  
                                                                  if (res != 0) {
                                                                          alert("Error:New Event Configuration");
                                                                  }
                                                                  else {
                                                                          location.reload();
                                                                  }
                                                          });
                                                  };
                                          };
                                  });
                                }
                                else{
                                        debugger;
                                        let uniquekey=uniquedevicename.includes(RS485ConfigSectionName)
                                        if(uniquekey){
                                         alert("Url Already Exists Please Enter different url")
                                        }
                                        else{
                                                self.RS485CreateUCISection("urlipconfig", "urlipconfig", sensorSectionOptions).then(function (rv) {
                                                        if (rv) {
                                                                if (rv.section) {
                                                                        self.RS485CommitUCISection("urlipconfig").then(function (res) {
                
                                                                                if (res != 0) {
                                                                                        alert("Error:New Event Configuration");
                                                                                }
                                                                                else {
                                                                                        location.reload();
                                                                                }
                                                                        });
                                                                };
                                                        };
                                                });
                                        }
                                        console.log(uniquekey);
                                       
                                }
                          }
                });
        },

        RS485ConfigSectionRemove: function (ev) {
                debugger;
                var self = ev.data.self;
                var RS485ConfigSectionName = ev.data.RS485ConfigSectionName;
                self.RS485DeleteUCISection("urlipconfig", "urlipconfig", RS485ConfigSectionName).then(function (rv) {
                        if (rv == 0) {
                                self.RS485CommitUCISection("urlipconfig").then(function (res) {
                                        if (res != 0) {
                                                alert("Error: Delete Configuration");
                                        }
                                        else {
                                                location.reload();
                                        }
                                });
                        };
                });
        },

        RS485ConfigSectionEdit: function (ev) {
                $("#Applyconfig").css("display", "none")
                $("#editconfig").css("display", "inline")
                console.log(ev);
                var key = ev.data.RS485ConfigSectionName;
                editkey = function () {
                        return key;
                }
                var porteditdata = configdata();
                var editfields = porteditdata[key];
                console.log(editfields);

                var status = editfields.UrlfilteringSwitch
                if (status == "1") {
                        status = true;
                }
                else {
                        status = false;
                }
                var urlfiltering = editfields.RS485ConfigSectionName
                urlfiltering = urlfiltering.replaceAll("/", "")
                $('#UrlBlocking').val(urlfiltering);
                document.getElementById("UrlfilteringSwitch").checked = status;
                $("#exampleModal").modal('show');
        },

        execute: function () {
                $('#addnew').click(function () {
                        $('#UrlBlocking').val("");
                        document.getElementById("UrlfilteringSwitch").checked = true;
                });
                $("#editconfig").css("display", "none")
                $("#Applyconfig").css("display", "inline")
                var self = this;

                var m = new L.cbi.Map('urlipconfig', {
                });

                var s = m.section(L.cbi.NamedSection, 'general', {
                        caption: L.tr('General Configurations')
                });


                s.option(L.cbi.CheckboxValue, 'enableipsecgeneral', {
                        caption: L.tr('Enable IPSEC'),
                        optional: true
                });

                s.option(L.cbi.CheckboxValue, 'enableopenvpngeneral', {
                        caption: L.tr('Enable Openvpn'),
                        optional: true
                });

                s.option(L.cbi.CheckboxValue, 'enablepptp', {
                        caption: L.tr('Enable PPTP'),
                        optional: true
                });


                m.insertInto('#section_vpn_general');

                var m1 = new L.cbi.Map('urlipconfig', {
                });

                var s1 = m1.section(L.cbi.NamedSection, 'pptp', {
                        caption: L.tr('PPTP Configurations')
                });


                //PPTP

                s1.option(L.cbi.InputValue, 'pptpserver', {
                        caption: L.tr('Server'),
                }).depends({ 'enablepptp': '1' });

                s1.option(L.cbi.InputValue, 'pptpuser', {
                        caption: L.tr('User'),
                }).depends({ 'enablepptp': '1' });

                s1.option(L.cbi.PasswordValue, 'pptppassword', {
                        caption: L.tr('Password'),
                        optional: true
                }).depends({ 'enablepptp': '1' });

                m1.insertInto('#section_pptp');



                var self = this;
                $('#Applyconfig').click(function () {
                        var res = "";
                        debugger

                        var url = document.getElementById("UrlBlocking").value;
                        var validationResult = document.getElementById("validationResult");

                        if (
                                url.match(
                                        /([w]{3}\.)[-a-zA-Z0-9@:%.\+#=]{2,256}\.[a-z]{2,3}\b([-a-zA-Z0-9@:%\+.#?&=]*)/g
                                )
                        ) {

                                self.RS485ConfigSectionAdd("");
                        } else {
                                console.log("Invalid");
                                res = "Must be a valid url";
                        }
                        validationResult.innerHTML = res;




                });
                $('#editconfig').click(function () {
                        var res = "";
                        debugger

                        var url = document.getElementById("UrlBlocking").value;
                        var validationResult = document.getElementById("validationResult");

                        if (
                                url.match(
                                        /([w]{3}\.)[-a-zA-Z0-9@:%.\+#=]{2,256}\.[a-z]{2,3}\b([-a-zA-Z0-9@:%\+.#?&=]*)/g
                                )
                        ) {
                                var key = editkey()

                                self.RS485ConfigSectionAdd(key);
                        } else {
                                console.log("Invalid");
                                res = "Must be a valid url";
                        }
                        validationResult.innerHTML = res;




                });
                self.RS485GetUCISections("urlipconfig", "urlipconfig").then(function (rv) {
                        self.RS485RenderContents(rv);
                });

                $('#update_ipsec').click(function () {
                        L.ui.loading(true);
                        self.updatefirewallconfig('configure').then(function (rv) {
                                L.ui.dialog(
                                        L.tr('update configuration'), [
                                        $('<pre />')
                                                .addClass('alert alert-success')
                                                .text(rv)
                                ],

                                        { style: 'close' }
                                );

                        });
                        L.ui.loading(false);
                });

                //Openvpn     
                $('#btn_upload').click(function () {

                        self.countcertficates().then(function (rv) {


                                if (rv < '1') {
                                        self.handleArchiveUpload();
                                }
                                else {
                                        L.ui.loading(false);
                                        L.ui.dialog(

                                                L.tr('Upload Certificates error'), [
                                                $('<p />').text(L.tr('Output')),
                                                $('<pre />')
                                                        .addClass('alert alert-danger')
                                                        .text("Please click on Delete button to delete existing .ovpn files and then click on Upload button to upload the new .ovpn file."),
                                        ],
                                                {
                                                        style: 'close',
                                                        close: function () {
                                                                location.reload();
                                                        }
                                                }
                                        );
                                }

                        });
                });

                $('#btn_delete').click(function () {

                        self.deletecertficates().then(function (rv) {

                                L.ui.loading(false);
                                L.ui.dialog(

                                        L.tr('Delete Openvpn certificates'), [
                                        $('<p />').text(L.tr('Output')),
                                        $('<pre />')
                                                .addClass('alert alert-info')
                                                .text("Openvpn certificates Deleted"),
                                ],
                                        {
                                                style: 'close',
                                                close: function () {
                                                        location.reload();
                                                }
                                        }
                                );
                        });
                });

                self.RS485GetUCISections("urlipconfig", "urlipconfig").then(function (rv) {
                        for (var key in rv) {
                                if (rv.hasOwnProperty(key)) {
                                        var obj = rv[key];
                                        var running = obj.openvpnrunning;
                                        if (running == '0') {
                                                var AppstartCreateButton = $('<button/>', {
                                                        class: 'btn btn-primary',
                                                        text: 'Start',
                                                        id: 'start',
                                                        title: 'Start the Apps',
                                                        style: 'width:110px',
                                                        on: {
                                                                click: function (e) {
                                                                        L.ui.loading(true);
                                                                        self.startopenvpnservice().then(function (rv) {
                                                                                L.ui.loading(false);
                                                                                L.ui.dialog(

                                                                                        L.tr('Started the openvpn service'), [
                                                                                        $('<p />').text(L.tr('Output')),
                                                                                        $('<pre />')
                                                                                                .addClass('alert alert-info')
                                                                                                .text(rv),
                                                                                ],
                                                                                        {
                                                                                                style: 'close',
                                                                                                close: function () {
                                                                                                        location.reload();
                                                                                                }
                                                                                        }
                                                                                );
                                                                        });
                                                                }
                                                        }
                                                });
                                                $("#btn-group").append(AppstartCreateButton);
                                        }

                                        if (running == '1') {
                                                var AppStopCreateButton = $('<button/>', {
                                                        class: 'btn btn-danger',
                                                        text: 'Stop',
                                                        title: 'Stop the Apps',
                                                        style: 'width:110px',
                                                        on: {
                                                                click: function (e) {
                                                                        L.ui.loading(true);
                                                                        self.stopopenvpnservice().then(function (rv) {
                                                                                L.ui.loading(false);
                                                                                L.ui.dialog(
                                                                                        L.tr('Stopped the openvpn service'), [
                                                                                        $('<pre />')
                                                                                                .addClass('alert alert-danger')
                                                                                                .text(rv),
                                                                                ],
                                                                                        {
                                                                                                style: 'close',
                                                                                                close: function () {

                                                                                                        location.reload();
                                                                                                }
                                                                                        }
                                                                                );
                                                                        });
                                                                }
                                                        }
                                                });
                                                $("#btn-group").append(AppStopCreateButton);
                                        }
                                }
                        }
                });

                s.commit = function () {

                        self.updateopenvpnconfig('enableopenvpn').then(function (rv) {

                        });
                }
        }
});


