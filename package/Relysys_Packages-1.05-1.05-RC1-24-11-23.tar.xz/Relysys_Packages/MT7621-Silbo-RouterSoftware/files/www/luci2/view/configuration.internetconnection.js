L.ui.view.extend({
   title: L.tr('Internet Connection Configuration'),
   description: L.tr('Please update after editing or deleting any changes.'),
    
    RS485GetUCISections: L.rpc.declare({
            object: 'uci',
            method: 'get',
            params: [ 'config', 'type'],
            expect: { values: {} }
    }),
    
    RS485CreateUCISection:  L.rpc.declare({
            object: 'uci',
            method: 'add',
            params: [ 'config', 'type', 'name', 'values' ]
    }),
    
    RS485CommitUCISection:  L.rpc.declare({
            object: 'uci',
            method: 'commit',
            params: [ 'config' ]
    }),
    
    RS485DeleteUCISection:  L.rpc.declare({
    object: 'uci',
    method: 'delete',
    params: [ 'config','type','section' ]
}),
  
  updategeneralconfig: L.rpc.declare({
        object: 'rpc-validatepriority',
        method: 'configure',
        expect: { output: '' }
    }),
  
	updatefailoverconfig: L.rpc.declare({
        object: 'rpc-validatepriority',
        method: 'configure',
        expect: { output: '' }
    }),
     deletefailoverconfig: L.rpc.declare({
        object: 'rpc-validatepriority',
        method: 'delete',
         params: ['FailoverConfigSectionName'],
            expect: { output: '' }
    }),
    
    updateloadbalanceconfig: L.rpc.declare({
        object: 'rpc-validatepriority',
        method: 'configure',
        expect: { output: '' }
    }),
    
    deleteloadbalanceconfig: L.rpc.declare({
        object: 'rpc-validatepriority',
        method: 'delete',
        params: ['LoadBalanceConfigSectionName'],
        expect: { output: '' }
    }),
        
    FailoverFormCallback: function() 
    {
            var map = this;
            var FailoverConfigSectionName = map.options.FailoverConfigSection;
            var numericExpression = /^[0-9]+$/;
            
            map.options.caption = L.tr(FailoverConfigSectionName+' Configuration');
            
            var s = map.section(L.cbi.NamedSection, FailoverConfigSectionName, {
                    collabsible: true
            });
                         
           
    //s.option(L.cbi.InputValue, 'name', {
				//caption:     L.tr('Name')
		//});
		
		s.option(L.cbi.ComboBox, 'wanpriority', {
			caption:     L.tr('Priority'),
			optional:      'true'
		}).value("1", L.tr('1'))
		  .value("2", L.tr('2'))
		  .value("3", L.tr('3'));   
		  
	   s.option(L.cbi.ListValue, 'validtrackip', {
                        caption: L.tr('Select Track IP Numbers')
                }).value("0",L.tr("Please select the option"))
	              .value("1",L.tr("1"))
	              .value("2",L.tr("2"))
			      .value("3",L.tr("3"))
	              .value("4",L.tr("4"));
	                
	     s.option(L.cbi.InputValue, 'trackIp1', {                                       
                caption: L.tr('TrackIP1'), 
                placeholder:     '8.8.8.8',                                                           
                        optional: true,                                                                             
                }).depends({'validtrackip':'1'})
                .depends({'validtrackip':'2'})
                .depends({'validtrackip':'3'})
                .depends({'validtrackip':'4'});           
                 
	     s.option(L.cbi.InputValue, 'trackIp2', {                                       
                caption: L.tr('TrackIP2'), 
                placeholder:     '8.8.8.8',                                                           
                        optional: true,                                                                             
                }).depends({'validtrackip':'2'})
                .depends({'validtrackip':'3'})
                .depends({'validtrackip':'4'}); 
                                            
	     s.option(L.cbi.InputValue, 'trackIp3', {                                       
                caption: L.tr('TrackIP3'), 
                placeholder:     '8.8.8.8',                                                           
                        optional: true,                                                                             
                }).depends({'validtrackip':'3'})
                .depends({'validtrackip':'4'});          
                       
	     s.option(L.cbi.InputValue, 'trackIp4', {                                       
                caption: L.tr('TrackIP4'), 
                placeholder:     '8.8.8.8',                                                           
                        optional: true,                                                                             
                }).depends({'validtrackip':'4'});     
                
           
         s.option(L.cbi.InputValue, 'reliability', {
		caption:	L.tr('Reliability'),
		datatype: 'integer',
		}); 
		
		    
         s.option(L.cbi.InputValue, 'count', {
		caption:	L.tr('Count'),
		datatype: 'integer',
		});                          
	          
	         
         s.option(L.cbi.InputValue, 'up', {
		caption:	L.tr('Up'),
		datatype: 'integer',
		});                          
	          
	         
         s.option(L.cbi.InputValue, 'down', {
		caption:	L.tr('Down'),
		datatype: 'integer',
		});                          
	                                                     
	},

                       
    LoadBalancingFormCallback: function() 
    {
            var map = this;
            var LoadBalanceConfigSectionName = map.options.LoadBalanceConfigSection;
            var numericExpression = /^[0-9]+$/;
          
            map.options.caption = L.tr(LoadBalanceConfigSectionName+' Configuration');
            
            var s1 = map.section(L.cbi.NamedSection, LoadBalanceConfigSectionName, {
                    collabsible: true
            });
            
          //s1.option(L.cbi.InputValue, 'name', {
				//caption:     L.tr('Name')
		//});
		
		s1.option(L.cbi.InputValue, 'wanweight', {
			caption:     L.tr('Traffic Distribution Ratio'),
		});  
		
		s1.option(L.cbi.ListValue, 'validtrackip', {
                        caption: L.tr('Select Track IP Numbers')
                }).value("0",L.tr("Please select the option"))
	              .value("1",L.tr("1"))
	              .value("2",L.tr("2"))
			      .value("3",L.tr("3"))
	              .value("4",L.tr("4"));
	                
	     s1.option(L.cbi.InputValue, 'trackIp1', {                                       
                caption: L.tr('TrackIP1'), 
                placeholder:     '8.8.8.8',                                                           
                        optional: true,                                                                             
                }).depends({'validtrackip':'1'})
                .depends({'validtrackip':'2'})
                .depends({'validtrackip':'3'})
                .depends({'validtrackip':'4'});           
                 
	     s1.option(L.cbi.InputValue, 'trackIp2', {                                       
                caption: L.tr('TrackIP2'), 
                placeholder:     '8.8.8.8',                                                           
                        optional: true,                                                                             
                }).depends({'validtrackip':'2'})
                .depends({'validtrackip':'3'})
                .depends({'validtrackip':'4'}); 
                                            
	     s1.option(L.cbi.InputValue, 'trackIp3', {                                       
                caption: L.tr('TrackIP3'), 
                placeholder:     '8.8.8.8',                                                           
                        optional: true,                                                                             
                }).depends({'validtrackip':'3'})
                .depends({'validtrackip':'4'});          
                       
	     s1.option(L.cbi.InputValue, 'trackIp4', {                                       
                caption: L.tr('TrackIP4'), 
                placeholder:     '8.8.8.8',                                                           
                        optional: true,                                                                             
                }).depends({'validtrackip':'4'});     
                
           
         s1.option(L.cbi.InputValue, 'reliability', {
		        caption:	L.tr('Reliability'),
		        datatype: 'integer',
		     }); 
		
		    
         s1.option(L.cbi.InputValue, 'count', {
		       caption:	L.tr('Count'),
		       datatype: 'integer',
		     });                          
	          
	         
         s1.option(L.cbi.InputValue, 'up', {
		        caption:	L.tr('Up'),
		        datatype: 'integer',
		   });                          
	          
	         
         s1.option(L.cbi.InputValue, 'down', {
		       caption:	L.tr('Down'),
		       datatype: 'integer',
		   });                          
		
       },                  

    FailoverConfigCreateForm: function(mapwidget,FailoverConfigSectionName) 
    {
            var self = this;
            
            if (!mapwidget)
                    mapwidget = L.cbi.Map;
            
            var map = new mapwidget('mwan3config', {
                    prepare: self.FailoverFormCallback,
                    FailoverConfigSection: FailoverConfigSectionName
            });
            return map;
    },
  
    LoadBalanceConfigCreateForm: function(mapwidget,LoadBalanceConfigSectionName) 
    {
            var self = this;
            
            if (!mapwidget)
                    mapwidget = L.cbi.Map;
            
            var map = new mapwidget('mwan3config', {
                    prepare: self.LoadBalancingFormCallback,
                    LoadBalanceConfigSection: LoadBalanceConfigSectionName
            });
            return map;
    },
    
    FailoverRenderContents: function(rv) 
    {
		configdata1 = function () {
                        return rv;
                    }
                    
         var self = this;
            var list = new L.ui.table({
			columns: [ 
			{ 
				caption: L.tr('Name'),
				format:  function(v,n) {
					var div = $('<small />').attr('id', 'FailoverDeviceEventName_%s'.format(n));
					return div.append(v);
				}
		    },
			
			{ 
				caption: L.tr('Priority'),
				format:  function(v,n) {
					var div = $('<p />').attr('id', 'FailoverDeviceEventWanpriority_%s'.format(n));
					return div.append(v);
				}
			},
			
			{
                                caption: L.tr('Enable/Disable'),
                                width: '40%',
                                align: 'center',
                                format: function (v, n) {
                                        //alert(v)
                                        console.log(this.Enabled)
                                        var div = $('<label />').attr('id', 'FailoverDevice_%s'.format(n)).attr('class', 'switch');
                                        return div.append(`<input type="checkbox" ${v}   id="FailoverstatusSwitch${n}" onclick="changestatusfail(${n})">
  <span class="slider round"></span>`);
                                        
                                }
                        },
			
                    {
                            caption: L.tr('Update'),
                            align: 'left',
                            format: function(v, n) {
                                    return $('<div />')
                                            .addClass('btn-group btn-group-sm')
                                            .append(L.ui.button(L.tr('Edit'),'primary', L.tr('Configure'))
                                            .click({ self: self, FailoverConfigSectionName: v }, self.FailoverConfigSectionEdit))
                                            .append(L.ui.button(L.tr('Delete'), 'danger', L.tr('Delete Event'))
                                            .click({ self: self, FailoverConfigSectionName: v }, self.FailoverConfigSectionRemove));
                                           
                            }
                    }]
            });
          
         for (var key in rv) 
                {
                        if (rv.hasOwnProperty(key)) 
                        {
                                var obj = rv[key];
                                var Name = obj.name
						        var Wanpriority = obj.wanpriority
						        var Enabled = obj.enabled
						    
							 if (Enabled == "1") 
                              {
                                Enabled = "checked"
                              }

                              else 
                              {
                                Enabled = ""
                              }

							
                               list.row([Name,Wanpriority,Enabled,key]); 
                               
                        }
                }
          
          $('#section_internet_failover').append(list.render());	
          
    },
  
    LoadBalancingRenderContents: function(rv) 
    {
		configdata = function () {
                        return rv;
                    }
		
		
         var self = this;

              var list2 = new L.ui.table({
                    columns: [ 
			{ 
				caption: L.tr('Name'),
				format:  function(v,n) {
					var div = $('<small />').attr('id', 'LoadBalanceDeviceEventName_%s'.format(n));
					return div.append(v);
				}
		    },
			
			{ 
				caption: L.tr('Traffic Distribution Ratio(total sum must be 100)'),
				width: '40%',
                                align: 'center',
				format:  function(v,n) {
					var div = $('<p />').attr('id', 'LoadBalanceDeviceEventWeight_%s'.format(n));
					return div.append(v);
				}
			},
			
			
			{
                                caption: L.tr('Enable/Disable'),
                                width: '40%',
                                align: 'center',
                                format: function (v, n) {
                                        //alert(v)
                                        console.log(this.Enabled)
                                        var div = $('<label />').attr('id', 'LoadBalanceDevice_%s'.format(n)).attr('class', 'switch');
                                        return div.append(`<input type="checkbox" ${v}   id="PortforwardingstatusSwitch${n}" onclick="changestatus(${n})">
  <span class="slider round"></span>`);
                                        
                                }
                        },
			
			
			
                    {
                            caption: L.tr('Update'),
                            align: 'left',
                            format: function(v, n) {
                                    return $('<div />')
                                            .addClass('btn-group btn-group-sm')
                                            .append(L.ui.button(L.tr('Edit'),'primary', L.tr('Configure'))
                                            .click({ self: self, LoadBalanceConfigSectionName: v }, self.LoadBalanceConfigSectionEdit))
                                            .append(L.ui.button(L.tr('Delete'), 'danger', L.tr('Delete Event'))
                                            .click({ self: self, LoadBalanceConfigSectionName: v }, self.LoadBalanceConfigSectionRemove));
                                           
                            }
                    }]
            });

                   for (var key in rv) 
                       {
                        if (rv.hasOwnProperty(key)) 
                        {
							 var obj = rv[key];
							var Name = obj.name
						    var Weight = obj.wanweight
						    var Enabled = obj.enabled
						    
							 if (Enabled == "1") 
                              {
                                Enabled = "checked"
                              }

                              else 
                              {
                                Enabled = ""
                              }

                             
                                    list2.row([Name,Weight,Enabled,key])
                             
                        }
                }
        
           $('#section_internet_loadbalancing').append(list2.render());
            
    },
  
  
    FailoverConfigSectionAdd: function () 
    {
      var self = this;
      var FailoverConfigSectionName = $('#field_failover_redirect_newRedirect_name').val();
      var FailoverConfigWanpriority = $('#field_failover_redirect_newRedirect_wanpriority').val();
      var FailoverConfigSection= {name:FailoverConfigSectionName,wanpriority:FailoverConfigWanpriority,enabled: "1"};             
                    
        self.RS485GetUCISections("mwan3config","genericconfig").then(function(rv){
		for (var key in rv) 
		{ 
			if (rv.hasOwnProperty(key))
	     {
		  var obj = rv[key];
		  var Selection = obj.select;  
		 if(Selection=='failover')
		   {     
             self.RS485CreateUCISection("mwan3config","redirect",FailoverConfigSectionName,FailoverConfigSection).then(function(rv){
               if(rv)
                   {
                      if (rv.section)
                         {
                           self.RS485CommitUCISection("mwan3config").then(function(res){
                                                              
                            if (res != 0) 
                                                            {
                                alert("Error:New Event Configuration");
                                                            }
                                                            else 
                                                            {
                                                                    location.reload();
                                                            }
                                                    });
                                            };
                                    };
                            }); 
                    }        
              else 
                  {
                     alert("Cannot Add Configuration, Please select Failover in General Settings tab to Add");
                  }
                }
              }
         });  
    },
    
    
      LoadBalanceConfigSectionAdd: function () 
      {
         var self = this;
         var LoadBalanceConfigSectionName = $('#field_loadbalancing_rule_newRule_name').val();
         var LoadBalanceConfigWeight = $('#field_loadbalancing_rule_newRule_weight').val();
         var  LoadBalanceConfigSection= {name:LoadBalanceConfigSectionName,wanweight:LoadBalanceConfigWeight,enabled: "1" };
                    
        self.RS485GetUCISections("mwan3config","genericconfig").then(function(rv){
		   for (var key in rv) 
		   { 
			if (rv.hasOwnProperty(key))
	         {
		        var obj = rv[key];
		        var Selection = obj.select;  
		        if(Selection=='balanced')
		          {
                    self.RS485CreateUCISection("mwan3config","redirect",LoadBalanceConfigSectionName,LoadBalanceConfigSection).then(function(rv){
                      if(rv)
                        {
                          if (rv.section)
                            {
                               self.RS485CommitUCISection("mwan3config").then(function(res){
                     	       if (res != 0) 
                                 {
					    	       alert("Error:New Event Configuration");
                                 }
                               else 
                                  {
                                    location.reload();
                                  }
                                });
                              };
                            };
                          }); 
                         }
              else 
                 {
                    alert("Cannot Add Configuration, Please select Load Balancing in General Settings tab to Add");
                 }
                }
              }
           });
       },
    
    
    FailoverConfigSectionRemove: function(ev) 
    {
     var self = ev.data.self;
     var FailoverConfigSectionName = ev.data.FailoverConfigSectionName;
     self.RS485GetUCISections("mwan3config","genericconfig").then(function(rv){
	 for (var key in rv) 
		{ 
			if (rv.hasOwnProperty(key))
	         {
		       var obj = rv[key];
		       var Selection = obj.select;  
		       if(Selection=='failover')
		         {
			      self.deletefailoverconfig(FailoverConfigSectionName).then(function(rv) {
					if(rv == 1){
					       alert("Cannot Delete CWAN1_0, CWAN1_1 and CWAN1");
					   }
					  else
					  {    
			       self.RS485DeleteUCISection("mwan3config","redirect",FailoverConfigSectionName).then(function(rv){
                   if(rv == 0){
                     self.RS485CommitUCISection("mwan3config").then(function(res){
                     if (res != 0)
                       {
                         alert("Error: Delete Configuration");
                       }
                     else 
                       {
                         location.reload();
                       }
                     });
                   };
                 });
			 }
              });
             }
          else 
           {
               alert("Cannot Delete Configuration, Please select Failover in General Settings tab to delete");
           }
          }
         }
        });
    },
    
     LoadBalanceConfigSectionRemove: function(ev) 
    {
    var self = ev.data.self;
    var LoadBalanceConfigSectionName = ev.data.LoadBalanceConfigSectionName;
    
    self.RS485GetUCISections("mwan3config","genericconfig").then(function(rv){
		for (var key in rv) 
		 { 
			if (rv.hasOwnProperty(key))
	          {
		       var obj = rv[key];
		       var Selection = obj.select;  
		       if(Selection=='balanced')
		         {
	               self.deleteloadbalanceconfig(LoadBalanceConfigSectionName).then(function(rv) {		
					   if(rv == 1){
					       alert("Cannot Delete CWAN1_0, CWAN1_1 and CWAN1");
					   }
					  else
				   {      
                   self.RS485DeleteUCISection("mwan3config","redirect",LoadBalanceConfigSectionName).then(function(rv){
                   if(rv == 0){
                   self.RS485CommitUCISection("mwan3config").then(function(res){
                   if (res != 0)
                    {
                      alert("Error: Delete Configuration");
                    }
                   else 
                    {
                      location.reload();
                    }
                   });
                  };
                });  
			}
              });   
             }
          else 
            {
             alert("Cannot Delete Configuration, Please select Load Balancing in General Settings tab to delete");
            }
           }
          }
        });
     },
    
    FailoverConfigSectionEdit: function(ev) 
    {
            var self = ev.data.self;
            var FailoverConfigSectionName = ev.data.FailoverConfigSectionName;
            return self.FailoverConfigCreateForm(L.cbi.Modal,FailoverConfigSectionName).show();
    },
 
          
        LoadBalanceConfigSectionEdit: function(ev) 
    {
            var self = ev.data.self;
            var LoadBalanceConfigSectionName = ev.data.LoadBalanceConfigSectionName;
            return self.LoadBalanceConfigCreateForm(L.cbi.Modal,LoadBalanceConfigSectionName).show();
    },       
           
  
    execute:function()
    {
    var self = this;
          
    var m = new L.cbi.Map('mwan3config', {
                });
        
    var s = m.section(L.cbi.NamedSection, 'general', {
        caption:L.tr('General Configurations')
    });
    
         s.option(L.cbi.ListValue, 'select', {
                        caption: L.tr('Choose')
           //     }).value("none", L.tr('None'))
                }).value("failover", L.tr('Failover'))
                 .value("balanced", L.tr('Load Balancing'));   
      
   m.insertInto('#section_internet_connection');  
   
   
   $('#btn_internet_general_update').click(function() {
        L.ui.loading(true);
        self.updategeneralconfig('configure').then(function(rv) {
                L.ui.dialog(
                    L.tr('update configuration'),[
                        $('<pre />')
                        .addClass('alert alert-success')
                        .text(rv)
                    ],
                   
                    { style: 'close'}
                );
                
               });
               L.ui.loading(false);
        });
                
   
   
   
             var self = this;
             
            $('#AddNewConnectionfailover').click(function() { 
                    self.FailoverConfigSectionAdd();
            });
          
          self.RS485GetUCISections("mwan3config","redirect").then(function(rv) {
                    self.FailoverRenderContents(rv);
            });           
           
            $('#AddNewConnectionLoadBalancing').click(function() { 
                self.LoadBalanceConfigSectionAdd();
          });
            self.RS485GetUCISections("mwan3config","redirect").then(function(rv) {
                self.LoadBalancingRenderContents(rv);
          }); 


          $('#btn_internet_update').click(function() {
        L.ui.loading(true);
        self.updatefailoverconfig('configure').then(function(rv) {
                L.ui.dialog(
                    L.tr('update configuration'),[
                        $('<pre />')
                        .addClass('alert alert-success')
                        .text(rv)
                    ],
                   
                    { style: 'close'}
                );
                
               });
               L.ui.loading(false);
        });
        
        
         
        changestatusfail=function (n) {
                        var checkbox = $("#FailoverstatusSwitch" + n)[0].checked
                        var faileditdata = configdata1();
                        console.log(faileditdata)
                        var failName=Object.keys(faileditdata)[n] 
                        console.log(failName)
                        var failsensorSectionOptions = { enabled: "0" };
                          console.log(checkbox);
                        if (checkbox) {
                            document.getElementById("FailoverstatusSwitch"+n).checked = true;
                             failsensorSectionOptions = { enabled: "1" };
                        }
                        else {
                            document.getElementById("FailoverstatusSwitch"+n).checked = false;
                            failsensorSectionOptions = { enabled: "0" };
                        }
                        self.RS485CreateUCISection("mwan3config", "redirect",failName,failsensorSectionOptions).then(function (rv) {
                            if (rv) {
                                if (rv.section) {
                                    self.RS485CommitUCISection("mwan3config").then(function (res) {
                                        if (res != 0) {
                                            alert("Error:New Event Configuration");
                                        }
                                        else {
                                            location.reload();
                                        }
                                    });
                                };
                            };
                        });
                }
        
        
        
            $('#btn_internet_loadbalance_update').click(function() {
        L.ui.loading(true);
        self.updateloadbalanceconfig('configure').then(function(rv) {
                L.ui.dialog(
                    L.tr('update configuration'),[
                        $('<pre />')
                        .addClass('alert alert-success')
                        .text(rv)
                    ],
                   
                    { style: 'close'}
                );
                
               });
               L.ui.loading(false);
        });
        
        
      
            changestatus=function (n) {
                        var checkbox = $("#PortforwardingstatusSwitch" + n)[0].checked
                        var porteditdata = configdata();
                        console.log(porteditdata)
                        var portName=Object.keys(porteditdata)[n] 
                        console.log(portName)
                        var sensorSectionOptions = { enabled: "0" };
                          console.log(checkbox);
                        if (checkbox) {
                            document.getElementById("PortforwardingstatusSwitch"+n).checked = true;
                             sensorSectionOptions = { enabled: "1" };
                        }
                        else {
                            document.getElementById("PortforwardingstatusSwitch"+n).checked = false;
                            sensorSectionOptions = { enabled: "0" };
                        }
                        self.RS485CreateUCISection("mwan3config", "redirect",portName,sensorSectionOptions).then(function (rv) {
                            if (rv) {
                                if (rv.section) {
                                    self.RS485CommitUCISection("mwan3config").then(function (res) {
                                        if (res != 0) {
                                            alert("Error:New Event Configuration");
                                        }
                                        else {
                                            location.reload();
                                        }
                                    });
                                };
                            };
                        });
                }
        
               //$('#btn_internet_general_update').click(function() {
        //L.ui.loading(true);
        //self.updategeneralconfig('configure').then(function(rv) {
                //L.ui.dialog(
                    //L.tr('update configuration'),[
                        //$('<pre />')
                        //.addClass('alert alert-success')
                        //.text(rv)
                    //],
                   
                    //{ style: 'close'}
                //);
                
               //});
               //L.ui.loading(false);
        //});
                
        
        

    }
});



