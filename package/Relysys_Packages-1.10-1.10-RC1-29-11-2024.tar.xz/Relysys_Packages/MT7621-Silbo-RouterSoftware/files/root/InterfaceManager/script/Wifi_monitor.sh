#!/bin/sh

while true
do
	enable_wifi=$(uci get sysconfig.wificonfig.wifi1enable)
	enable_gwifi=$(uci get sysconfig.guestwifi.guestwifienable5)
	
	if [ "$enable_wifi" = "1" ] || [ "$enable_gwifi" = "1" ]				
	then	
		ipv4=$(ifconfig "wlan0" | awk '/inet addr/{print substr($2,6)}')
		gipv4=$(ifconfig "wlan1" | awk '/inet addr/{print substr($2,6)}')

		if [ -z "$ipv4" ] || [ -z "$gipv4" ]
		then
			wifi
			sleep 1
		fi
	fi

	/bin/Wifi_restart.sh
	sleep 10
done
