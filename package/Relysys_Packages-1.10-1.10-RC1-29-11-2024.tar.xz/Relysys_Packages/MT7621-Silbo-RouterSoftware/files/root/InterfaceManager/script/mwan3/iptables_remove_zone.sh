#!/bin/sh

. /lib/functions.sh

LogrotateConfigFile1="/etc/logrotate.d/alllogsmod1"
Logfile1="/root/ConfigFiles/Logs/all_logs_mod1.txt"

echo "<iptables_remove_zone> Updating mwan3 status." >> $Logfile1

/bin/mwan3statusupdate.sh

echo "<iptables_remove_zone> 15s sleep." >> $Logfile1
sleep 15

Iptables_Remove_Zone()
{
	config=$1
	config_get name "$config" name
	config_get status "$config" status
	
	if [ "$status" != "online" ]
	then
		
		echo "<iptables_remove_zone> Status of $name is - $status. Hence, deleting" >> $Logfile1
		
		input_line_number=$(iptables -t filter -L -n -v --line-numbers | grep -i "zone_${name}_input" | awk '{print $1}' | sed 's/[^0-9]*//g')
		forward_line_number=$(iptables -t filter -L -n -v --line-numbers | grep -i "zone_${name}_forward" | awk '{print $1}' | sed 's/[^0-9]*//g')
		output_line_number=$(iptables -t filter -L -n -v --line-numbers | grep -i "zone_${name}_output" | awk '{print $1}' | sed 's/[^0-9]*//g')
		
		#If the zones are entered more than once. Delete them all.
		for lines in "$output_line_number"; do
			# Check if the variable is not empty before deleting them.
			if [ -n "$lines" ]; then
				echo "<iptables_remove_zone> Deleting line $lines from OUTPUT." >> $Logfile1
				iptables -w -D OUTPUT $lines
			fi
		done

		#If the zones are entered more than once. Delete them all.
		for lines in "$forward_line_number"; do
			# Check if the variable is not empty before deleting them.
			if [ -n "$lines" ]; then
			echo "<iptables_remove_zone> Deleting line $lines from FORWARD." >> $Logfile1
				iptables -w -D FORWARD $lines
			fi
		done

		#If the zones are entered more than once. Delete them all.
		for lines in "$input_line_number"; do
			# Check if the variable is not empty before deleting them.
			if [ -n "$lines" ]; then
			echo "<iptables_remove_zone> Deleting line $lines from INPUT." >> $Logfile1
				iptables -w -D INPUT $lines
			fi
		done
	fi
}

#MWAN3STATUSCONFIG
config_load "/etc/config/mwan3statusconfig" 
config_foreach Iptables_Remove_Zone redirect

logrotate "$LogrotateConfigFile1"
