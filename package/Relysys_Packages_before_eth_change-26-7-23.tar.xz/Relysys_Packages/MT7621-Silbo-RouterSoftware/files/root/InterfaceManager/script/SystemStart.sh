#!/bin/sh

. /lib/functions.sh

swlaninterface="SW_LAN"
lan1interface="LAN1"
lan2interface="LAN2"
lan3interface="LAN3"
lan4interface="LAN4"
lan5interface="LAN5"
ethwan1interface="EWAN1"
ethwan2interface="EWAN2"
ethwan3interface="EWAN3"
ethwan4interface="EWAN4"
ethwan5interface="EWAN5"
cellularwan1interface="CWAN1"
cellularwan2interface="CWAN2"
cellularwan3interface="CWAN3"
cellularwan1sim1interface="CWAN1_0"
cellularwan1sim2interface="CWAN1_1"

#IPV6 Variables 
cellular1wan6interface="wan6c1"
cellular2wan6interface="wan6c2"

wifiinterface="ra0"
wifi5interface="rai0"
wifiap="ra0_ap"
wifi5ap="rai0_ap"

#To change guest name -- 
wifiap1="ra1"
wifiap51="rai1"
 
InternetOverWifi="1"

ReadSystemConfigFile()
{
	config_load "$SystemConfigFile"

	# sw_lan
	config_get Port1Mode sysconfig port1mode
	config_get SwlanInterfaceName sysconfig swlaninterfacename
	config_get EthernetServerStaticDnsServer sysconfig EthernetServerStaticDnsServer
	config_get EthernetServerStaticDnsServerNo1 sysconfig EthernetServerStaticDnsServerNo1
	config_get EthernetServerStaticDnsServerNo2 sysconfig EthernetServerStaticDnsServerNo2
	config_get EthernetProtocolSwLan sysconfig EthernetProtocolswlan
	config_get EthernetServerStaticIPSwLan sysconfig EthernetServerStaticIPswlan
	config_get EthernetServerDHCPIPSwLan sysconfig EthernetServerDHCPIPswlan
	config_get EthernetServerDHCPrangeSwLan sysconfig EthernetServerDHCPrangeswlan
	config_get EthernetServerDHCPlimitSwLan sysconfig EthernetServerDHCPlimitswlan       
	config_get InternetoverSwLan sysconfig internetoverswlan
	config_get SwLanMacId sysconfig swlanmacid
	config_get EthernetServerDHCPNetmaskSwLan sysconfig EthernetServerDHCPNetmaskswlan
	config_get EthernetServerStaticNetmaskSwLan sysconfig EthernetServerStaticNetmaskswlan

	# lan1
	config_get Port1Mode sysconfig port1mode
	config_get Port1LanIfName sysconfig port1lanifname
	config_get EthernetServerStaticDnsServer1 sysconfig EthernetServerStaticDnsServer1
	config_get EthernetServerStaticDnsServer1No1 sysconfig EthernetServerStaticDnsServer1No1
	config_get EthernetServerStaticDnsServer1No2 sysconfig EthernetServerStaticDnsServer1No2
	config_get Port1lanInterfaceName sysconfig port1laninterfacename
	config_get Port1WaninterfaceName sysconfig port1waninterfacename
	config_get EthernetProtocolPort1lan sysconfig EthernetProtocolPort1lan
	config_get EthernetServerDHCPIPPort1lan sysconfig EthernetServerDHCPIPPort1lan
	config_get EthernetServerDHCPrangePort1lan sysconfig EthernetServerDHCPrangePort1lan
	config_get EthernetServerDHCPlimitPort1lan sysconfig EthernetServerDHCPlimitPort1lan
	config_get EthernetServerStaticIPPort1lan sysconfig EthernetServerStaticIPPort1lan
	config_get EthernetProtocolPort1wan sysconfig EthernetProtocolPort1wan
	config_get EthernetClientDHCPGatewayPort1wan sysconfig EthernetClientDHCPGatewayPort1wan
	config_get EthernetClientStaticIPPort1wan sysconfig EthernetClientStaticIPPort1wan
	config_get EthernetClientStaticGatewayPort1wan sysconfig EthernetClientStaticGatewayPort1wan
	config_get Port1InternetOverLan sysconfig port1internetoverlan
	config_get Port1MacId sysconfig port1macid
	config_get EthernetServerDHCPNetmaskPort1Lan sysconfig EthernetServerDHCPNetmaskPort1lan
	config_get EthernetServerStaticNetmaskPort1Lan sysconfig EthernetServerStaticNetmaskPort1lan
	config_get EthernetClientnetmaskPort1Wan sysconfig EthernetClientnetmaskPort1wan

	# lan2
	config_get Port2Mode sysconfig port2mode
	config_get Port2LanIfName sysconfig port2lanifname
	config_get Port1LanIfName sysconfig port1lanifname
	config_get EthernetServerStaticDnsServer2 sysconfig EthernetServerStaticDnsServer2
	config_get EthernetServerStaticDnsServer2No1 sysconfig EthernetServerStaticDnsServer2No1
	config_get EthernetServerStaticDnsServer2No2 sysconfig EthernetServerStaticDnsServer2No2
	config_get Port2lanInterfaceName sysconfig port2laninterfacename
	config_get Port2WaninterfaceName sysconfig port2waninterfacename
	config_get EthernetProtocolPort2lan sysconfig EthernetProtocolPort2lan
	config_get EthernetServerDHCPIPPort2lan sysconfig EthernetServerDHCPIPPort2lan
	config_get EthernetServerDHCPrangePort2lan sysconfig EthernetServerDHCPrangePort2lan
	config_get EthernetServerDHCPlimitPort2lan sysconfig EthernetServerDHCPlimitPort2lan
	config_get EthernetServerStaticIPPort2lan sysconfig EthernetServerStaticIPPort2lan
	config_get EthernetProtocolPort2wan sysconfig EthernetProtocolPort2wan
	config_get EthernetClientDHCPGatewayPort2wan sysconfig EthernetClientDHCPGatewayPort2wan
	config_get EthernetClientStaticIPPort2wan sysconfig EthernetClientStaticIPPort2wan
	config_get EthernetClientStaticGatewayPort2wan sysconfig EthernetClientStaticGatewayPort2wan
	config_get Port2InternetOverLan sysconfig port2internetoverlan
	config_get Port2MacId sysconfig port2macid
	config_get EthernetServerDHCPNetmaskPort2Lan sysconfig EthernetServerDHCPNetmaskPort2lan
	config_get EthernetServerStaticNetmaskPort2Lan sysconfig EthernetServerStaticNetmaskPort2lan
	config_get EthernetClientnetmaskPort2Wan sysconfig EthernetClientnetmaskPort2wan

	# lan3
	config_get Port3Mode sysconfig port3mode
	config_get Port3LanIfName sysconfig port3lanifname
	config_get Port1LanIfName sysconfig port1lanifname
	config_get EthernetServerStaticDnsServer3 sysconfig EthernetServerStaticDnsServer3
	config_get EthernetServerStaticDnsServer3No1 sysconfig EthernetServerStaticDnsServer3No1
	config_get EthernetServerStaticDnsServer3No2 sysconfig EthernetServerStaticDnsServer3No2
	config_get Port3lanInterfaceName sysconfig port3laninterfacename
	config_get Port3WaninterfaceName sysconfig port3waninterfacename
	config_get EthernetProtocolPort3lan sysconfig EthernetProtocolPort3lan
	config_get EthernetServerDHCPIPPort3lan sysconfig EthernetServerDHCPIPPort3lan
	config_get EthernetServerDHCPrangePort3lan sysconfig EthernetServerDHCPrangePort3lan
	config_get EthernetServerDHCPlimitPort3lan sysconfig EthernetServerDHCPlimitPort3lan
	config_get EthernetServerStaticIPPort3lan sysconfig EthernetServerStaticIPPort3lan
	config_get EthernetProtocolPort3wan sysconfig EthernetProtocolPort3wan
	config_get EthernetClientDHCPGatewayPort3wan sysconfig EthernetClientDHCPGatewayPort3wan
	config_get EthernetClientStaticIPPort3wan sysconfig EthernetClientStaticIPPort3wan
	config_get EthernetClientStaticGatewayPort3wan sysconfig EthernetClientStaticGatewayPort3wan
	config_get Port3InternetOverLan sysconfig port3internetoverlan
	config_get Port3MacId sysconfig port3macid
	config_get EthernetServerDHCPNetmaskPort3Lan sysconfig EthernetServerDHCPNetmaskPort3lan
	config_get EthernetServerStaticNetmaskPort3Lan sysconfig EthernetServerStaticNetmaskPort3lan
	config_get EthernetClientnetmaskPort3Wan sysconfig EthernetClientnetmaskPort3wan

	# lan4     
	config_get Port4Mode sysconfig port4mode
	config_get Port4LanIfName sysconfig port4lanifname
	config_get Port1LanIfName sysconfig port1lanifname
	config_get EthernetServerStaticDnsServer4 sysconfig EthernetServerStaticDnsServer4
	config_get EthernetServerStaticDnsServer4No1 sysconfig EthernetServerStaticDnsServer4No1
	config_get EthernetServerStaticDnsServer4No2 sysconfig EthernetServerStaticDnsServer4No2
	config_get Port4lanInterfaceName sysconfig port4laninterfacename
	config_get Port4WaninterfaceName sysconfig port4waninterfacename
	config_get EthernetProtocolPort4lan sysconfig EthernetProtocolPort4lan
	config_get EthernetServerDHCPIPPort4lan sysconfig EthernetServerDHCPIPPort4lan
	config_get EthernetServerDHCPrangePort4lan sysconfig EthernetServerDHCPrangePort4lan
	config_get EthernetServerDHCPlimitPort4lan sysconfig EthernetServerDHCPlimitPort4lan
	config_get EthernetServerStaticIPPort4lan sysconfig EthernetServerStaticIPPort4lan
	config_get EthernetProtocolPort4wan sysconfig EthernetProtocolPort4wan
	config_get EthernetClientDHCPGatewayPort4wan sysconfig EthernetClientDHCPGatewayPort4wan
	config_get EthernetClientStaticIPPort4wan sysconfig EthernetClientStaticIPPort4wan
	config_get EthernetClientStaticGatewayPort4wan sysconfig EthernetClientStaticGatewayPort4wan
	config_get Port4InternetOverLan sysconfig port4internetoverlan
	config_get Port4MacId sysconfig port4macid
	config_get EthernetServerDHCPNetmaskPort4Lan sysconfig EthernetServerDHCPNetmaskPort4lan
	config_get EthernetServerStaticNetmaskPort4Lan sysconfig EthernetServerStaticNetmaskPort4lan
	config_get EthernetClientnetmaskPort4Wan sysconfig EthernetClientnetmaskPort4wan

	# lan5
	config_get Port5Mode sysconfig port5mode
	config_get Port5LanIfName sysconfig port5lanifname
	config_get Port1LanIfName sysconfig port1lanifname
	config_get EthernetServerStaticDnsServer5 sysconfig EthernetServerStaticDnsServer5
	config_get EthernetServerStaticDnsServer5No1 sysconfig EthernetServerStaticDnsServer5No1
	config_get EthernetServerStaticDnsServer5No2 sysconfig EthernetServerStaticDnsServer5No2
	config_get Port5lanInterfaceName sysconfig port5laninterfacename
	config_get Port5WaninterfaceName sysconfig port5waninterfacename     
	config_get EthernetProtocolPort5lan sysconfig EthernetProtocolPort5lan
	config_get EthernetServerDHCPIPPort5lan sysconfig EthernetServerDHCPIPPort5lan
	config_get EthernetServerDHCPrangePort5lan sysconfig EthernetServerDHCPrangePort5lan
	config_get EthernetServerDHCPlimitPort5lan sysconfig EthernetServerDHCPlimitPort5lan
	config_get EthernetServerStaticIPPort5lan sysconfig EthernetServerStaticIPPort5lan
	config_get EthernetProtocolPort5wan sysconfig EthernetProtocolPort5wan
	config_get EthernetClientDHCPGatewayPort5wan sysconfig EthernetClientDHCPGatewayPort5wan
	config_get EthernetClientStaticIPPort5wan sysconfig EthernetClientStaticIPPort5wan
	config_get EthernetClientStaticGatewayPort5wan sysconfig EthernetClientStaticGatewayPort5wan
	config_get Port5InternetOverLan sysconfig port5internetoverlan
	config_get Port5MacId sysconfig port5macid
	config_get EthernetServerDHCPNetmaskPort5Lan sysconfig EthernetServerDHCPNetmaskPort5lan
	config_get EthernetServerStaticNetmaskPort5Lan sysconfig EthernetServerStaticNetmaskPort5lan
	config_get EthernetClientnetmaskPort5Wan sysconfig EthernetClientnetmaskPort5wan
	config_get EthernetClientPppoeUsername sysconfig EthernetClientPppoeUsername
	config_get EthernetClientPppoePassword sysconfig EthernetClientPppoePassword
	config_get EthernetClientPppoeAccessConcentrator sysconfig EthernetClientPppoeAccessConcentrator
	config_get EthernetClientPppoeServiceName sysconfig EthernetClientPppoeServiceName    
	config_get EthernetClientPptpServerAddress sysconfig EthernetClientPptpServerAddress
	config_get EthernetClientPptpUsername sysconfig EthernetClientPptpUsername
	config_get EthernetClientPptpPassword sysconfig EthernetClientPptpPassword
	config_get EthernetClientPptpMppeEncryption sysconfig EthernetClientPptpMppeEncryption
	config_get EthernetClientPptpDNSServerSource sysconfig EthernetClientPptpDNSServerSource
	config_get EthernetClientPptpNumberOfDNSServer sysconfig EthernetClientPptpNumberOfDNSServer
	config_get EthernetClientPptpDnsServerNo1 sysconfig EthernetClientPptpDnsServerNo1
	config_get EthernetClientPptpDnsServerNo2 sysconfig EthernetClientPptpDnsServerNo2

	#  Cellular
	config_get CellularOperationModelocal sysconfig CellularOperationMode
	config_get CellularModem1 sysconfig cellularmodem1
	config_get Protocol1EC20 sysconfig protocol1EC20
	config_get Manufacturerlocal1 sysconfig Manufacturer1
	config_get Model1 sysconfig model1
	config_get PortType1 sysconfig porttype1
	config_get VendorId1 sysconfig vendorid1
	config_get ProductId1 sysconfig productid1
	config_get DataPort1 sysconfig dataport1
	config_get ComPort1 sysconfig comport1
	config_get SmsPort1 sysconfig smsport1
	config_get SmsEnable1 sysconfig smsenable1
	config_get SmsCenterNumber1 sysconfig smscenternumber1
	config_get DeviceId1 sysconfig smsdeviceid
	config_get ApiKey1 sysconfig smsapikey
	config_get Manufacturerlocal2 sysconfig Manufacturer2
	config_get Model2 sysconfig model2
	config_get PortType2 sysconfig porttype2
	config_get VendorId2 sysconfig vendorid2
	config_get ProductId2 sysconfig productid2
	config_get DataPort2 sysconfig dataport2
	config_get ComPort2 sysconfig comport2
	config_get SmsPort2 sysconfig smsport2
	config_get SmsEnable2 sysconfig smsenable2
	config_get SmsCenterNumber2 sysconfig smscenternumber2
	config_get DeviceId2 sysconfig deviceid2
	config_get ApiKey2 sysconfig apikey2
	config_get MonitorEnable1 sysconfig monitorenable1
	config_get QueryModematAnalytics1 sysconfig querymodematanalytics1
	config_get DataTestEnable1 sysconfig datatestenable1
	config_get PingTestEnable1 sysconfig pingtestenable1
	config_get PingIp1 sysconfig pingip1
	config_get MonitorEnable2 sysconfig monitorenable2
	config_get QueryModematAnalytics2 sysconfig querymodematanalytics2
	config_get DataTestEnable2 sysconfig datatestenable2
	config_get PingTestEnable2 sysconfig pingtestenable2
	config_get PingIp2 sysconfig pingip2
	config_get DataEnable1 sysconfig dataenable
	config_get Cellular1 sysconfig cellular
	config_get Service1 sysconfig service
	config_get Apn1 sysconfig apn
	config_get Pdp1 sysconfig pdp
	config_get PinCode1 sysconfig pincode
	config_get UserName1 sysconfig username
	config_get Password1 sysconfig password
	config_get Auth1 sysconfig auth
	config_get DataEnable2 sysconfig dataenable2
	config_get Cellular2 sysconfig cellular2
	config_get Sim2Service sysconfig sim2service
	config_get Sim2Apn sysconfig sim2apn
	config_get sim2pdp sysconfig sim2pdp
	config_get Sim2PinCode sysconfig sim2pincode
	config_get Sim2UserName sysconfig sim2username
	config_get Sim2Password sysconfig sim2password
	config_get sim2auth sysconfig sim2auth
	config_get EnableCellular sysconfig enablecellular
	config_get UsbBusPath1 sysconfig usbbuspath1
	config_get UsbBusPath2 sysconfig usbbuspath2
	config_get ActionInterval1 sysconfig actioninterval1
	config_get ActionInterval2 sysconfig actioninterval2
	config_get Protocol1 sysconfig protocol1
	config_get Protocol2 sysconfig protocol2
	config_get SmsResponseSenderEnable1 sysconfig smsresponsesenderenable1
	config_get SmsResponseSenderEnable2 sysconfig smsresponsesenderenable2
	config_get SmsResponseServerEnable1 sysconfig smsresponseserverenable1
	config_get SmsResponseServerEnable2 sysconfig smsresponseserverenable2
	config_get SmsServerNumber1 sysconfig smsservernumber1
	config_get SmsServerNumber2 sysconfig smsservernumber2
	config_get SmsServerNumber3 sysconfig smsservernumber3
	config_get SmsServerNumber4 sysconfig smsservernumber4        
	config_get SmsServerNumber5 sysconfig smsservernumber5
	#5g
	config_get support5gnetwork sysconfig support5gnetwork
	config_get networkingmode1 sysconfig networkingmode1
	config_get autoconfigsim1 sysconfig autoconfigsim1
	config_get rattype1 sysconfig rattype1
	config_get nsa_bands1 sysconfig nsa_bands1
	config_get sa_bands1 sysconfig sa_bands1
	config_get ComPortSymLink1 sysconfig ComPortSymLink1
	config_get networkingmode2 sysconfig networkingmode2
	config_get autoconfigsim2 sysconfig autoconfigsim2
	config_get rattype2 sysconfig rattype2
	config_get nsa_bands2 sysconfig nsa_bands2
	config_get sa_bands2 sysconfig sa_bands2
	config_get ComPortSymLink2 sysconfig ComPortSymLink2

	# Wifi 2.4
	config_get WifiDevice sysconfig wifidevice
	config_get channelwidth sysconfig channelwidth
	config_get wifi1protocol sysconfig wifi1protocol
	config_get TxPower sysconfig TxPower
	config_get WifiDevicesChannel sysconfig wifideviceschannel
	config_get CountryCode sysconfig CountryCode
	config_get wifi1CountryRegion sysconfig wifi1CountryRegion
	config_get wifi1enable sysconfig wifi1enable
	config_get Radio0StationEnable sysconfig radio0stationenable
	config_get Wifi1Ssid sysconfig wifi1ssid
	config_get Wifi1Key sysconfig wifi1key
	config_get Wifi1Mode sysconfig wifi1mode
	config_get Wifi1StaMode sysconfig wifi1stamode
	config_get Wifi1Authentication sysconfig wifi1authentication
	config_get Wifi1Encryption sysconfig wifi1encryption
	config_get Wifi1StaSsid sysconfig wifi1stassid
	config_get Wifi1StaEncryption sysconfig wifi1staencryption
	config_get Wifi1StaKey sysconfig wifi1stakey
	config_get Wifi2Enable sysconfig wifi2enable
	config_get Wifi2Ssid sysconfig wifi2ssid
	config_get Wifi2Key sysconfig wifi2key
	config_get Wifi2Mode sysconfig wifi2mode
	config_get InternetOverWifi sysconfig internetoverwifi
	config_get LanWifiBridgeEnable sysconfig lanwifibridgeenable
	config_get Radio0DhcpIp sysconfig radio0dhcpip
	config_get Radio0DHCPRange sysconfig Radio0DHCPrange
	config_get Radio0DHCPLimit sysconfig Radio0DHCPlimit
	config_get ScheduledOnOff sysconfig ScheduledOnOff

	# Wifi 5 
	config_get Wifi5Mode sysconfig wifi5mode       
	config_get wifi51protocol sysconfig wifi51protocol       
	config_get wifi5CountryRegion sysconfig wifi5CountryRegion       
	config_get wifi5TxPower sysconfig wifi5TxPower       
	config_get wifi5ssid sysconfig wifi5ssid
	config_get wifi5encryption sysconfig wifi5encryption
	config_get wifi5key sysconfig wifi5key
	config_get wifi5authentication sysconfig wifi5authentication
	config_get wifi5encryption sysconfig wifi5encryption
	config_get wifi5radio0dhcpip sysconfig wifi5radio0dhcpip
	config_get wifi5Radio0DHCPrange sysconfig wifi5Radio0DHCPrange
	config_get wifi5Radio0DHCPlimit sysconfig wifi5Radio0DHCPlimit
	config_get wifi5enable sysconfig wifi5enable
	config_get wifi5channelwidth sysconfig wifi5channelwidth
	config_get wifi5CountryCode sysconfig wifi5CountryCode
	config_get wifi5deviceschannel sysconfig wifi5deviceschannel
	config_get wifi5WmmEnable sysconfig wifi5WmmEnable

	#guest 2.4ghz
	config_get guestwifienable2 sysconfig guestwifienable2
	config_get guestwifissid2 sysconfig guestwifissid2
	config_get guestwifi1authentication2 sysconfig guestwifi1authentication2
	config_get guestwifi1encryption2 sysconfig guestwifi1encryption2
	config_get guestwifikey2 sysconfig guestwifikey2
	config_get guestradio0dhcpip2 sysconfig guestradio0dhcpip2
	config_get guestRadio0DHCPrange2 sysconfig guestRadio0DHCPrange2
	config_get guestRadio0DHCPlimit2 sysconfig guestRadio0DHCPlimit2

	#guest 5ghz        
	config_get guestwifienable5 sysconfig guestwifienable5
	config_get guestwifissid5 sysconfig guestwifissid5
	config_get guestwifi1authentication5 sysconfig guestwifi1authentication5
	config_get guestwifi1encryption5 sysconfig guestwifi1encryption5
	config_get guestwifikey5 sysconfig guestwifikey5
	config_get guestradio0dhcpip5 sysconfig guestradio0dhcpip5
	config_get guestRadio0DHCPrange5 sysconfig guestRadio0DHCPrange5
	config_get guestRadio0DHCPlimit5 sysconfig guestRadio0DHCPlimit5

	#Advanced 2.4ghz
	config_get radiusport sysconfig radiusport
	config_get radiusacctport sysconfig radiusacctport
	config_get TxBurst sysconfig TxBurst
	config_get HTOpMode sysconfig HTOpMode
	config_get HTMpduDensity sysconfig HTMpduDensity
	config_get HTBW sysconfig HTBW
	config_get HTPROTECT sysconfig HTPROTECT
	config_get HTRxStream sysconfig HTRxStream
	config_get HTTxStream sysconfig HTTxStream
	config_get E2pAccessMode sysconfig E2pAccessMode
	config_get WHNAT sysconfig WHNAT
	config_get BeaconPeriod sysconfig BeaconPeriod
	config_get DtimPeriod sysconfig DtimPeriod
	config_get WmmCapable sysconfig WmmCapable
	config_get RTSThreshold sysconfig RTSThreshold
	config_get FragThreshold sysconfig FragThreshold
	config_get IgmpSnEnable sysconfig IgmpSnEnable
	config_get HT_STBC sysconfig HT_STBC
	config_get HT_LDPC sysconfig HT_LDPC
	config_get VHT_STBC sysconfig VHT_STBC
	config_get VHT_LDPC sysconfig VHT_LDPC

	#Advanced 5ghz        
	config_get wifi5radiusport sysconfig wifi5radiusport
	config_get wifi5radiusacctport sysconfig wifi5radiusacctport
	config_get wifi5TxBurst sysconfig wifi5TxBurst
	config_get wifi5HTOpMode sysconfig wifi5HTOpMode
	config_get wifi5HTMpduDensity sysconfig wifi5HTMpduDensity
	config_get wifi5HTBW sysconfig wifi5HTBW
	config_get wifi5HTPROTECT sysconfig wifi5HTPROTECT
	config_get wifi5HTRxStream sysconfig wifi5HTRxStream
	config_get wifi5HTTxStream sysconfig wifi5HTTxStream
	config_get wifi5E2pAccessMode sysconfig wifi5E2pAccessMode
	config_get wifi5WHNAT sysconfig wifi5WHNAT
	config_get wifi5BeaconPeriod sysconfig wifi5BeaconPeriod
	config_get wifi5DtimPeriod sysconfig wifi5DtimPeriod
	config_get wifi5WmmCapable sysconfig wifi5WmmCapable
	config_get wifi5RTSThreshold sysconfig wifi5RTSThreshold
	config_get wifi5FragThreshold sysconfig wifi5FragThreshold
	config_get wifi5IgmpSnEnable sysconfig wifi5IgmpSnEnable
	config_get wifi5HT_STBC sysconfig wifi5HT_STBC
	config_get wifi5HT_LDPC sysconfig wifi5HT_LDPC
	config_get wifi5VHT_STBC sysconfig wifi5VHT_STBC
	config_get wifi5VHT_LDPC sysconfig wifi5VHT_LDPC
}

ReadMwanConfigFile()
{ 
   config_load "$MwanConfigFile"
   config_get NameEwan1 "$ethwan1interface" name
   config_get Ewan1Priority "$ethwan1interface" wanpriority
   config_get Ewan1TrackIp1 "$ethwan1interface" trackIp1
   config_get Ewan1TrackIp2 "$ethwan1interface" trackIp2
   config_get Ewan1TrackIp3 "$ethwan1interface" trackIp3
   config_get Ewan1TrackIp4 "$ethwan1interface" trackIp4
   config_get Ewan1Reliability "$ethwan1interface" reliability 
   config_get Ewan1Count "$ethwan1interface" count
   config_get Ewan1Up "$ethwan1interface" up
   config_get Ewan1Down "$ethwan1interface" down
   config_get Ewan1Validtrackip "$ethwan1interface" validtrackip
   
   config_get NameEwan2 "$ethwan2interface" name
   config_get Ewan2Priority "$ethwan2interface" wanpriority
   config_get Ewan2TrackIp1 "$ethwan2interface" trackIp1
   config_get Ewan2TrackIp2 "$ethwan2interface" trackIp2
   config_get Ewan2TrackIp3 "$ethwan2interface" trackIp3
   config_get Ewan2TrackIp4 "$ethwan2interface" trackIp4
   config_get Ewan2Reliability "$ethwan2interface" reliability 
   config_get Ewan2Count "$ethwan2interface" count
   config_get Ewan2Up "$ethwan2interface" up
   config_get Ewan2Down "$ethwan2interface" down
   config_get Ewan2Validtrackip "$ethwan2interface" validtrackip
   
   config_get NameEwan3 "$ethwan3interface" name
   config_get Ewan3Priority "$ethwan3interface" wanpriority
   config_get Ewan3TrackIp1 "$ethwan3interface" trackIp1
   config_get Ewan3TrackIp2 "$ethwan3interface" trackIp2
   config_get Ewan3TrackIp3 "$ethwan3interface" trackIp3
   config_get Ewan3TrackIp4 "$ethwan3interface" trackIp4
   config_get Ewan3Reliability "$ethwan3interface" reliability 
   config_get Ewan3Count "$ethwan3interface" count
   config_get Ewan3Up "$ethwan3interface" up
   config_get Ewan3Down "$ethwan3interface" down
   config_get Ewan3Validtrackip "$ethwan3interface" validtrackip
   
   config_get NameEwan4 "$ethwan4interface" name
   config_get Ewan4Priority "$ethwan4interface" wanpriority
   config_get Ewan4TrackIp1 "$ethwan4interface" trackIp1
   config_get Ewan4TrackIp2 "$ethwan4interface" trackIp2
   config_get Ewan4TrackIp3 "$ethwan4interface" trackIp3
   config_get Ewan4TrackIp4 "$ethwan4interface" trackIp4
   config_get Ewan4Reliability "$ethwan4interface" reliability 
   config_get Ewan4Count "$ethwan4interface" count
   config_get Ewan4Up "$ethwan4interface" up
   config_get Ewan4Down "$ethwan4interface" down
   config_get Ewan4Validtrackip "$ethwan4interface" validtrackip
   
   config_get NameEwan5 "$ethwan5interface" name
   config_get Ewan5Priority "$ethwan5interface" wanpriority
   config_get Ewan5TrackIp1 "$ethwan5interface" trackIp1
   config_get Ewan5TrackIp2 "$ethwan5interface" trackIp2
   config_get Ewan5TrackIp3 "$ethwan5interface" trackIp3
   config_get Ewan5TrackIp4 "$ethwan5interface" trackIp4
   config_get Ewan5Reliability "$ethwan5interface" reliability 
   config_get Ewan5Count "$ethwan5interface" count
   config_get Ewan5Up "$ethwan5interface" up
   config_get Ewan5Down "$ethwan5interface" down
   config_get Ewan5Validtrackip "$ethwan5interface" validtrackip
	
   config_get NameCwan1 "$cellularwan1interface" name
   config_get Cwan1Priority "$cellularwan1interface" wanpriority
   config_get Cwan1TrackIp1 "$cellularwan1interface" trackIp1
   config_get Cwan1TrackIp2 "$cellularwan1interface" trackIp2
   config_get Cwan1TrackIp3 "$cellularwan1interface" trackIp3
   config_get Cwan1TrackIp4 "$cellularwan1interface" trackIp4
   config_get Cwan1Reliability "$cellularwan1interface" reliability 
   config_get Cwan1Count "$cellularwan1interface" count
   config_get Cwan1Up "$cellularwan1interface" up
   config_get Cwan1Down "$cellularwan1interface" down
   config_get Cwan1Validtrackip "$cellularwan1interface" validtrackip
   
   config_get NameCwan2 "$cellularwan2interface" name
   config_get Cwan2Priority "$cellularwan2interface" wanpriority
   config_get Cwan2TrackIp1 "$cellularwan2interface" trackIp1
   config_get Cwan2TrackIp2 "$cellularwan2interface" trackIp2
   config_get Cwan2TrackIp3 "$cellularwan2interface" trackIp3
   config_get Cwan2TrackIp4 "$cellularwan2interface" trackIp4
   config_get Cwan2Reliability "$cellularwan2interface" reliability 
   config_get Cwan2Count "$cellularwan2interface" count
   config_get Cwan2Up "$cellularwan2interface" up
   config_get Cwan2Down "$cellularwan2interface" down
   config_get Cwan2Validtrackip "$cellularwan2interface" validtrackip
   
   config_get NameCwansim1 "$cellularwan1sim1interface" name
   config_get Cwan1sim1Priority "$cellularwan1sim1interface" wanpriority
   config_get Cwan1sim1TrackIp1 "$cellularwan1sim1interface" trackIp1
   config_get Cwan1sim1TrackIp2 "$cellularwan1sim1interface" trackIp2
   config_get Cwan1sim1TrackIp3 "$cellularwan1sim1interface" trackIp3
   config_get Cwan1sim1TrackIp4 "$cellularwan1sim1interface" trackIp4
   config_get Cwan1sim1Reliability "$cellularwan1sim1interface" reliability 
   config_get Cwan1sim1Count "$cellularwan1sim1interface" count
   config_get Cwan1sim1Up "$cellularwan1sim1interface" up
   config_get Cwan1sim1Down "$cellularwan1sim1interface" down
   config_get Cwan1sim1Validtrackip "$cellularwan1sim1interface" validtrackip
   
   config_get NameCwansim2 "$cellularwan1sim2interface" name
   config_get Cwan1sim2Priority "$cellularwan1sim2interface" wanpriority
   config_get Cwan1sim2TrackIp1 "$cellularwan1sim2interface" trackIp1
   config_get Cwan1sim2TrackIp2 "$cellularwan1sim2interface" trackIp2
   config_get Cwan1sim2TrackIp3 "$cellularwan1sim2interface" trackIp3
   config_get Cwan1sim2TrackIp4 "$cellularwan1sim2interface" trackIp4
   config_get Cwan1sim2Reliability "$cellularwan1sim2interface" reliability 
   config_get Cwan1sim2Count "$cellularwan1sim2interface" count
   config_get Cwan1sim2Up "$cellularwan1sim2interface" up
   config_get Cwan1sim2Down "$cellularwan1sim2interface" down
   config_get Cwan1sim2Validtrackip "$cellularwan1sim2interface" validtrackip
   
   #IPV6 variables
	config_get NameCwan6_1 "$cellular1wan6interface" name
	config_get Cwan6_1Priority "$cellular1wan6interface" wanpriority
	config_get Cwan6_1TrackIp1 "$cellular1wan6interface" trackIp1
	config_get Cwan6_1TrackIp2 "$cellular1wan6interface" trackIp2
	config_get Cwan6_1TrackIp3 "$cellular1wan6interface" trackIp3
	config_get Cwan6_1TrackIp4 "$cellular1wan6interface" trackIp4
	config_get Cwan6_1Reliability "$cellular1wan6interface" reliability
	config_get Cwan6_1Count "$cellular1wan6interface" count
	config_get Cwan6_1Up "$cellular1wan6interface" up
	config_get Cwan6_1Down "$cellular1wan6interface" down
	config_get Cwan6_1validtrackip "$cellular1wan6interface" validtrackip

	config_get NameCwan6_2 "$cellular2wan6interface" name
	config_get Cwan6_2Priority "$cellular2wan6interface" wanpriority
	config_get Cwan6_2TrackIp1 "$cellular2wan6interface" trackIp1
	config_get Cwan6_2TrackIp2 "$cellular2wan6interface" trackIp2
	config_get Cwan6_2TrackIp3 "$cellular2wan6interface" trackIp3
	config_get Cwan6_2TrackIp4 "$cellular2wan6interface" trackIp4
	config_get Cwan6_2Reliability "$cellular2wan6interface" reliability
	config_get Cwan6_2Count "$cellular2wan6interface" count
	config_get Cwan6_2Up "$cellular2wan6interface" up
	config_get Cwan6_2Down "$cellular2wan6interface" down
	config_get Cwan6_2validtrackip "$cellular2wan6interface" validtrackip
   
}

UpdateMwanConfig()
{
	#Delete all including policy (balanced).
	uci delete mwan3."${ethwan1interface}" > /dev/null 2>&1
	uci delete mwan3."${ethwan2interface}" > /dev/null 2>&1
	uci delete mwan3."${ethwan3interface}" > /dev/null 2>&1
	uci delete mwan3."${ethwan4interface}" > /dev/null 2>&1
	uci delete mwan3."${ethwan5interface}" > /dev/null 2>&1
	uci delete mwan3."${cellularwan1interface}" > /dev/null 2>&1
	uci delete mwan3."${cellularwan2interface}" > /dev/null 2>&1
	uci delete mwan3."${cellularwan3interface}" > /dev/null 2>&1
	uci delete mwan3."${cellularwan1sim1interface}" > /dev/null 2>&1
	uci delete mwan3."${cellularwan1sim2interface}" > /dev/null 2>&1
	#ipv6
	uci delete mwan3."${cellular1wan6interface}" > /dev/null 2>&1
    uci delete mwan3."${cellular2wan6interface}" > /dev/null 2>&1
	
	uci delete mwan3.PPTP > /dev/null 2>&1
	uci delete mwan3.L2TP > /dev/null 2>&1
	uci delete mwan3.ewan1_only > /dev/null 2>&1
	uci delete mwan3.ewan2_only > /dev/null 2>&1
	uci delete mwan3.ewan3_only > /dev/null 2>&1
	uci delete mwan3.ewan4_only > /dev/null 2>&1
	uci delete mwan3.ewan5_only > /dev/null 2>&1
	uci delete mwan3.pptp_only > /dev/null 2>&1
	uci delete mwan3.l2tp_only > /dev/null 2>&1
	uci delete mwan3.cwan1_only > /dev/null 2>&1
	uci delete mwan3.cwan2_only > /dev/null 2>&1
	uci delete mwan3.cwan1sim1_only > /dev/null 2>&1
	uci delete mwan3.cwan1sim2_only > /dev/null 2>&1
	#Ipv6
	uci delete mwan3.cwan6_1_only > /dev/null 2>&1
    uci delete mwan3.cwan6_2_only > /dev/null 2>&1
    
	uci delete mwan3.wifiwan_only > /dev/null 2>&1
	uci delete mwan3.balanced > /dev/null 2>&1
	
	#Now create all depending on the user input.
	uci set mwan3.balanced=policy
    
    #Ewan1
    if [ "$Port1Mode" = "EWAN1" ]
	then
		uci delete mwan3.ewan1_m10_w1 > /dev/null 2>&1

		uci set mwan3."${ethwan1interface}"=interface
		uci set mwan3."${ethwan1interface}".enabled="1"
		
		if [ "$Ewan1Validtrackip" =  "1" ]
		then 
			uci add_list mwan3."${ethwan1interface}".track_ip="$Ewan1TrackIp1"
		fi
		if [ "$Ewan1Validtrackip" =  "2" ]
		then 
			uci add_list mwan3."${ethwan1interface}".track_ip="$Ewan1TrackIp1"
			uci add_list mwan3."${ethwan1interface}".track_ip="$Ewan1TrackIp2"
		fi
		if [ "$Ewan1Validtrackip" =  "3" ]
		then 
			uci add_list mwan3."${ethwan1interface}".track_ip="$Ewan1TrackIp1"
			uci add_list mwan3."${ethwan1interface}".track_ip="$Ewan1TrackIp2"
			uci add_list mwan3."${ethwan1interface}".track_ip="$Ewan1TrackIp3"
		fi
		if [ "$Ewan1Validtrackip" =  "4" ]
		then 
			uci add_list mwan3."${ethwan1interface}".track_ip="$Ewan1TrackIp1"
			uci add_list mwan3."${ethwan1interface}".track_ip="$Ewan1TrackIp2"
			uci add_list mwan3."${ethwan1interface}".track_ip="$Ewan1TrackIp3"
			uci add_list mwan3."${ethwan1interface}".track_ip="$Ewan1TrackIp4"
		fi
		
		uci set mwan3."${ethwan1interface}".family="ipv4"
		uci set mwan3."${ethwan1interface}".reliability="$Ewan1Reliability"
		uci set mwan3."${ethwan1interface}".count="$Ewan1Count"
		uci set mwan3."${ethwan1interface}".timeout="2"
		uci set mwan3."${ethwan1interface}".down="$Ewan1Down"
		uci set mwan3."${ethwan1interface}".up="$Ewan1Up"
		
		#member
		uci set mwan3.ewan1_m10_w1=member
		uci set mwan3.ewan1_m10_w1.interface="${ethwan1interface}"
		uci set mwan3.ewan1_m10_w1.metric="$Ewan1Priority"
		uci set mwan3.ewan1_m10_w1.weight="$Ewan1Priority"
		
		#policy
		uci set mwan3.ewan1_only=policy
		uci add_list mwan3.ewan1_only.use_member="ewan1_m10_w1"
		uci set mwan3.ewan1_only.last_resort="default"
		
		#balance
		uci add_list mwan3.balanced.use_member="ewan1_m10_w1"

    elif [ "$Port1Mode" = "LAN1" ]
	then
	    uci delete mwan3.ewan1_m10_w1 > /dev/null 2>&1
	elif [ "$Port1Mode" = "SW_LAN" ]
	then
		uci delete mwan3.ewan1_m10_w1 > /dev/null 2>&1
	fi
    
    #Ewan2
    if [ "$Port2Mode" = "EWAN2" ]
	then
		uci delete mwan3.ewan2_m10_w1 > /dev/null 2>&1

		uci set mwan3."${ethwan2interface}"=interface
		uci set mwan3."${ethwan2interface}".enabled="1"
		
		if [ "$Ewan2Validtrackip" =  "1" ]
		then 
			uci add_list mwan3."${ethwan2interface}".track_ip="$Ewan2TrackIp1"
		fi
		if [ "$Ewan2Validtrackip" =  "2" ]
		then 
			uci add_list mwan3."${ethwan2interface}".track_ip="$Ewan2TrackIp1"
			uci add_list mwan3."${ethwan2interface}".track_ip="$Ewan2TrackIp2"
		fi
		if [ "$Ewan2Validtrackip" =  "3" ]
		then 
			uci add_list mwan3."${ethwan2interface}".track_ip="$Ewan2TrackIp1"
			uci add_list mwan3."${ethwan2interface}".track_ip="$Ewan2TrackIp2"
			uci add_list mwan3."${ethwan2interface}".track_ip="$Ewan2TrackIp3"
		fi
		if [ "$Ewan2Validtrackip" =  "4" ]
		then 
			uci add_list mwan3."${ethwan2interface}".track_ip="$Ewan2TrackIp1"
			uci add_list mwan3."${ethwan2interface}".track_ip="$Ewan2TrackIp2"
			uci add_list mwan3."${ethwan2interface}".track_ip="$Ewan2TrackIp3"
			uci add_list mwan3."${ethwan2interface}".track_ip="$Ewan2TrackIp4"
		fi
		
		uci set mwan3."${ethwan2interface}".family="ipv4"
		uci set mwan3."${ethwan2interface}".reliability="$Ewan2Reliability"
		uci set mwan3."${ethwan2interface}".count="$Ewan2Count"
		uci set mwan3."${ethwan2interface}".timeout="2"
		uci set mwan3."${ethwan2interface}".down="$Ewan2Down"
		uci set mwan3."${ethwan2interface}".up="$Ewan2Up"
		
		#member
		uci set mwan3.ewan2_m10_w1=member
		uci set mwan3.ewan2_m10_w1.interface="${ethwan2interface}"
		uci set mwan3.ewan2_m10_w1.metric="$Ewan2Priority"
		uci set mwan3.ewan2_m10_w1.weight="$Ewan2Priority"
		
		#policy
		uci set mwan3.ewan2_only=policy
		uci add_list mwan3.ewan2_only.use_member="ewan2_m10_w1"
		uci set mwan3.ewan2_only.last_resort="default"
		
		#balance
		uci add_list mwan3.balanced.use_member="ewan2_m10_w1"

    elif [ "$Port2Mode" = "LAN2" ]
	then
	    uci delete mwan3.ewan2_m10_w1 > /dev/null 2>&1
	elif [ "$Port2Mode" = "SW_LAN" ]
	then
		uci delete mwan3.ewan2_m10_w1 > /dev/null 2>&1
	fi
    
    #Ewan3
    if [ "$Port3Mode" = "EWAN3" ]
	then
		uci delete mwan3.ewan3_m10_w1 > /dev/null 2>&1

		uci set mwan3."${ethwan3interface}"=interface
		uci set mwan3."${ethwan3interface}".enabled="1"
		
		if [ "$Ewan3Validtrackip" =  "1" ]
		then 
			uci add_list mwan3."${ethwan3interface}".track_ip="$Ewan3TrackIp1"
		fi
		if [ "$Ewan3Validtrackip" =  "2" ]
		then 
			uci add_list mwan3."${ethwan3interface}".track_ip="$Ewan3TrackIp1"
			uci add_list mwan3."${ethwan3interface}".track_ip="$Ewan3TrackIp2"
		fi
		if [ "$Ewan3Validtrackip" =  "3" ]
		then 
			uci add_list mwan3."${ethwan3interface}".track_ip="$Ewan3TrackIp1"
			uci add_list mwan3."${ethwan3interface}".track_ip="$Ewan3TrackIp2"
			uci add_list mwan3."${ethwan3interface}".track_ip="$Ewan3TrackIp3"
		fi
		if [ "$Ewan3Validtrackip" =  "4" ]
		then 
			uci add_list mwan3."${ethwan3interface}".track_ip="$Ewan3TrackIp1"
			uci add_list mwan3."${ethwan3interface}".track_ip="$Ewan3TrackIp2"
			uci add_list mwan3."${ethwan3interface}".track_ip="$Ewan3TrackIp3"
			uci add_list mwan3."${ethwan3interface}".track_ip="$Ewan3TrackIp4"
		fi
		
		uci set mwan3."${ethwan3interface}".family="ipv4"
		uci set mwan3."${ethwan3interface}".reliability="$Ewan3Reliability"
		uci set mwan3."${ethwan3interface}".count="$Ewan3Count"
		uci set mwan3."${ethwan3interface}".timeout="2"
		uci set mwan3."${ethwan3interface}".down="$Ewan3Down"
		uci set mwan3."${ethwan3interface}".up="$Ewan3Up"
		
		#member
		uci set mwan3.ewan3_m10_w1=member
		uci set mwan3.ewan3_m10_w1.interface="${ethwan3interface}"
		uci set mwan3.ewan3_m10_w1.metric="$Ewan3Priority"
		uci set mwan3.ewan3_m10_w1.weight="$Ewan3Priority"
		
		#policy
		uci set mwan3.ewan3_only=policy
		uci add_list mwan3.ewan3_only.use_member="ewan3_m10_w1"
		uci set mwan3.ewan3_only.last_resort="default"
		
		#balance
		uci add_list mwan3.balanced.use_member="ewan3_m10_w1"

    elif [ "$Port3Mode" = "LAN3" ]
	then
	    uci delete mwan3.ewan3_m10_w1 > /dev/null 2>&1
	elif [ "$Port3Mode" = "SW_LAN" ]
	then
		uci delete mwan3.ewan3_m10_w1 > /dev/null 2>&1
	fi
    
    #Ewan4
    if [ "$Port4Mode" = "EWAN4" ]
	then
		uci delete mwan3.ewan4_m10_w1 > /dev/null 2>&1

		uci set mwan3."${ethwan4interface}"=interface
		uci set mwan3."${ethwan4interface}".enabled="1"
		
		if [ "$Ewan4Validtrackip" =  "1" ]
		then 
			uci add_list mwan3."${ethwan4interface}".track_ip="$Ewan4TrackIp1"
		fi
		if [ "$Ewan4Validtrackip" =  "2" ]
		then 
			uci add_list mwan3."${ethwan4interface}".track_ip="$Ewan4TrackIp1"
			uci add_list mwan3."${ethwan4interface}".track_ip="$Ewan4TrackIp2"
		fi
		if [ "$Ewan4Validtrackip" =  "3" ]
		then 
			uci add_list mwan3."${ethwan4interface}".track_ip="$Ewan4TrackIp1"
			uci add_list mwan3."${ethwan4interface}".track_ip="$Ewan4TrackIp2"
			uci add_list mwan3."${ethwan4interface}".track_ip="$Ewan4TrackIp3"
		fi
		if [ "$Ewan4Validtrackip" =  "4" ]
		then 
			uci add_list mwan3."${ethwan4interface}".track_ip="$Ewan4TrackIp1"
			uci add_list mwan3."${ethwan4interface}".track_ip="$Ewan4TrackIp2"
			uci add_list mwan3."${ethwan4interface}".track_ip="$Ewan4TrackIp3"
			uci add_list mwan3."${ethwan4interface}".track_ip="$Ewan4TrackIp4"
		fi
		
		uci set mwan3."${ethwan4interface}".family="ipv4"
		uci set mwan3."${ethwan4interface}".reliability="$Ewan4Reliability"
		uci set mwan3."${ethwan4interface}".count="$Ewan4Count"
		uci set mwan3."${ethwan4interface}".timeout="2"
		uci set mwan3."${ethwan4interface}".down="$Ewan4Down"
		uci set mwan3."${ethwan4interface}".up="$Ewan4Up"
		
		#member
		uci set mwan3.ewan4_m10_w1=member
		uci set mwan3.ewan4_m10_w1.interface="${ethwan4interface}"
		uci set mwan3.ewan4_m10_w1.metric="$Ewan4Priority"
		uci set mwan3.ewan4_m10_w1.weight="$Ewan4Priority"
		
		#policy
		uci set mwan3.ewan4_only=policy
		uci add_list mwan3.ewan4_only.use_member="ewan4_m10_w1"
		uci set mwan3.ewan4_only.last_resort="default"
		
		#balance
		uci add_list mwan3.balanced.use_member="ewan4_m10_w1"

    elif [ "$Port4Mode" = "LAN4" ]
	then
	    uci delete mwan3.ewan4_m10_w1 > /dev/null 2>&1
	elif [ "$Port4Mode" = "SW_LAN" ]
	then
		uci delete mwan3.ewan4_m10_w1 > /dev/null 2>&1
	fi
    
	if [ "$Port5Mode" = "EWAN5" ]
	then
		uci delete mwan3.ewan5_m10_w1 > /dev/null 2>&1
		uci delete mwan3.pptp_m10_w1 > /dev/null 2>&1
		uci delete mwan3.l2tp_m10_w1 > /dev/null 2>&1

		uci set mwan3."${ethwan5interface}"=interface
		uci set mwan3."${ethwan5interface}".enabled="1"
		
		if [ "$Ewan5Validtrackip" =  "1" ]
		then 
			uci add_list mwan3."${ethwan5interface}".track_ip="$Ewan5TrackIp1"
		fi
		if [ "$Ewan5Validtrackip" =  "2" ]
		then 
			uci add_list mwan3."${ethwan5interface}".track_ip="$Ewan5TrackIp1"
			uci add_list mwan3."${ethwan5interface}".track_ip="$Ewan5TrackIp2"
		fi
		if [ "$Ewan5Validtrackip" =  "3" ]
		then 
			uci add_list mwan3."${ethwan5interface}".track_ip="$Ewan5TrackIp1"
			uci add_list mwan3."${ethwan5interface}".track_ip="$Ewan5TrackIp2"
			uci add_list mwan3."${ethwan5interface}".track_ip="$Ewan5TrackIp3"
		fi
		if [ "$Ewan5Validtrackip" =  "4" ]
		then 
			uci add_list mwan3."${ethwan5interface}".track_ip="$Ewan5TrackIp1"
			uci add_list mwan3."${ethwan5interface}".track_ip="$Ewan5TrackIp2"
			uci add_list mwan3."${ethwan5interface}".track_ip="$Ewan5TrackIp3"
			uci add_list mwan3."${ethwan5interface}".track_ip="$Ewan5TrackIp4"
		fi
		
		uci set mwan3."${ethwan5interface}".family="ipv4"
		uci set mwan3."${ethwan5interface}".reliability="$Ewan5Reliability"
		uci set mwan3."${ethwan5interface}".count="$Ewan5Count"
		uci set mwan3."${ethwan5interface}".timeout="2"
		uci set mwan3."${ethwan5interface}".down="$Ewan5Down"
		uci set mwan3."${ethwan5interface}".up="$Ewan5Up"
		
		#member
		uci set mwan3.ewan5_m10_w1=member
		uci set mwan3.ewan5_m10_w1.interface="${ethwan5interface}"
		uci set mwan3.ewan5_m10_w1.metric="$Ewan5Priority"
		uci set mwan3.ewan5_m10_w1.weight="$Ewan5Priority"
		
		#policy
		uci set mwan3.ewan5_only=policy
		uci add_list mwan3.ewan5_only.use_member="ewan5_m10_w1"
		uci set mwan3.ewan5_only.last_resort="default"
		
		#balance
		uci add_list mwan3.balanced.use_member="ewan5_m10_w1"
	   
	   #pptp
		if [ "$EthernetProtocolPort5wan" = "pptp" ]
		then
			uci set mwan3.PPTP=interface
			uci set mwan3.PPTP.enabled="1"
			
			if [ "$Ewan5Validtrackip" =  "1" ]
			then 
				uci add_list mwan3.PPTP.track_ip="$Ewan5TrackIp1"
			fi
			if [ "$Ewan5Validtrackip" =  "2" ]
			then 
				uci add_list mwan3.PPTP.track_ip="$Ewan5TrackIp1"
				uci add_list mwan3.PPTP.track_ip="$Ewan5TrackIp2"
			fi
			if [ "$Ewan5Validtrackip" =  "3" ]
			then 
				uci add_list mwan3.PPTP.track_ip="$Ewan5TrackIp1"
				uci add_list mwan3.PPTP.track_ip="$Ewan5TrackIp2"
				uci add_list mwan3.PPTP.track_ip="$Ewan5TrackIp3"
			fi
			if [ "$Ewan5Validtrackip" =  "4" ]
			then 
				uci add_list mwan3.PPTP.track_ip="$Ewan5TrackIp1"
				uci add_list mwan3.PPTP.track_ip="$Ewan5TrackIp2"
				uci add_list mwan3.PPTP.track_ip="$Ewan5TrackIp3"
				uci add_list mwan3.PPTP.track_ip="$Ewan5TrackIp4"
			fi
					
			uci set mwan3.PPTP.family="ipv4"
			uci set mwan3.PPTP.reliability="$Ewan5Reliability"
			uci set mwan3.PPTP.count="$Ewan5Count"
			uci set mwan3.PPTP.timeout="2"
			uci set mwan3.PPTP.down="$Ewan5Down"
			uci set mwan3.PPTP.up="$Ewan5Up"
			
			#member	
			#Highest priority, if it is pptp/l2tp.
			uci set mwan3.pptp_m10_w1=member
			uci set mwan3.pptp_m10_w1.interface="PPTP"
			uci set mwan3.pptp_m10_w1.metric="0"
			uci set mwan3.pptp_m10_w1.weight="0"
			
			#policy
			uci set mwan3.pptp_only=policy
			uci add_list mwan3.pptp_only.use_member="ewan5_m10_w1"
			uci add_list mwan3.pptp_only.use_member="pptp_m10_w1"
			uci set mwan3.pptp_only.last_resort="default"
			
			#balance
			uci add_list mwan3.balanced.use_member="pptp_m10_w1"			
		fi
		
	   #l2tp
		if [ "$EthernetProtocolPort5wan" = "l2tp" ]
		then
			uci set mwan3.L2TP=interface
			uci set mwan3.L2TP.enabled="1"
			
			if [ "$Ewan5Validtrackip" =  "1" ]
			then 
				uci add_list mwan3.L2TP.track_ip="$Ewan5TrackIp1"
			fi
			if [ "$Ewan5Validtrackip" =  "2" ]
			then 
				uci add_list mwan3.L2TP.track_ip="$Ewan5TrackIp1"
				uci add_list mwan3.L2TP.track_ip="$Ewan5TrackIp2"
			fi
			if [ "$Ewan5Validtrackip" =  "3" ]
			then 
				uci add_list mwan3.L2TP.track_ip="$Ewan5TrackIp1"
				uci add_list mwan3.L2TP.track_ip="$Ewan5TrackIp2"
				uci add_list mwan3.L2TP.track_ip="$Ewan5TrackIp3"
			fi
			if [ "$Ewan5Validtrackip" =  "4" ]
			then 
				uci add_list mwan3.L2TP.track_ip="$Ewan5TrackIp1"
				uci add_list mwan3.L2TP.track_ip="$Ewan5TrackIp2"
				uci add_list mwan3.L2TP.track_ip="$Ewan5TrackIp3"
				uci add_list mwan3.L2TP.track_ip="$Ewan5TrackIp4"
			fi
					
			uci set mwan3.L2TP.family="ipv4"
			uci set mwan3.L2TP.reliability="$Ewan5Reliability"
			uci set mwan3.L2TP.count="$Ewan5Count"
			uci set mwan3.L2TP.timeout="2"
			uci set mwan3.L2TP.down="$Ewan5Down"
			uci set mwan3.L2TP.up="$Ewan5Up"
			
			#member	
			#Highest priority, if it is pptp/l2tp.
			uci set mwan3.l2tp_m10_w1=member
			uci set mwan3.l2tp_m10_w1.interface="l2tp"
			uci set mwan3.l2tp_m10_w1.metric="0"
			uci set mwan3.l2tp_m10_w1.weight="0"
			
			#policy
			uci set mwan3.l2tp_only=policy
			uci add_list mwan3.l2tp_only.use_member="ewan5_m10_w1"
			uci add_list mwan3.l2tp_only.use_member="l2tp_m10_w1"
			uci set mwan3.l2tp_only.last_resort="default"
			
			#balance
			uci add_list mwan3.balanced.use_member="l2tp_m10_w1"			
		fi

	elif [ "$Port5Mode" = "LAN5" ]
	then
	    uci delete mwan3.ewan5_m10_w1 > /dev/null 2>&1
		uci delete mwan3.pptp_m10_w1 > /dev/null 2>&1
		uci delete mwan3.l2tp_m10_w1 > /dev/null 2>&1
	elif [ "$Port5Mode" = "SW_LAN" ]
	then
		uci delete mwan3.ewan5_m10_w1 > /dev/null 2>&1
		uci delete mwan3.pptp_m10_w1 > /dev/null 2>&1
		uci delete mwan3.l2tp_m10_w1 > /dev/null 2>&1
	fi
	
	#Cellular
	if [ "$EnableCellular" = "1" ]
    then
		#dualcellularsinglesim
		if [ "$CellularOperationModelocal" = "dualcellularsinglesim" ]
		then
			uci delete mwan3.cwan1sim1_m10_w1 > /dev/null 2>&1
			uci delete mwan3.cwan1sim2_m10_w1 > /dev/null 2>&1
			uci delete mwan3.cwan1_m10_w1 > /dev/null 2>&1
			uci delete mwan3.cwan2_m10_w1 > /dev/null 2>&1
			uci delete mwan3.cwan6_1_m10_w1 > /dev/null 2>&1
			uci delete mwan3.cwan6_2_m10_w1 > /dev/null 2>&1
			
			#CWAN1
			#If pdp1 is ipv4 or ipv4v6
			if [ "$Pdp1" = "1" ]  || [ "$Pdp1" = "3" ]
            then
				uci set mwan3."${cellularwan1interface}"=interface
				uci set mwan3."${cellularwan1interface}".enabled="1"

				if [ "$Cwan1Validtrackip" =  "1" ]
				then 
					uci add_list mwan3."${cellularwan1interface}".track_ip="$Cwan1TrackIp1"
				fi
				if [ "$Cwan1Validtrackip" =  "2" ]
				then 
					uci add_list mwan3."${cellularwan1interface}".track_ip="$Cwan1TrackIp1"
					uci add_list mwan3."${cellularwan1interface}".track_ip="$Cwan1TrackIp2"
				fi
				if [ "$Cwan1Validtrackip" =  "3" ]
				then 
					uci add_list mwan3."${cellularwan1interface}".track_ip="$Cwan1TrackIp1"
					uci add_list mwan3."${cellularwan1interface}".track_ip="$Cwan1TrackIp2"
					uci add_list mwan3."${cellularwan1interface}".track_ip="$Cwan1TrackIp3"
				fi
				if [ "$Cwan1Validtrackip" =  "4" ]
				then 
					uci add_list mwan3."${cellularwan1interface}".track_ip="$Cwan1TrackIp1"
					uci add_list mwan3."${cellularwan1interface}".track_ip="$Cwan1TrackIp2"
					uci add_list mwan3."${cellularwan1interface}".track_ip="$Cwan1TrackIp3"
					uci add_list mwan3."${cellularwan1interface}".track_ip="$Cwan1TrackIp4"
				fi

				uci set mwan3."${cellularwan1interface}".family="ipv4"
				uci set mwan3."${cellularwan1interface}".reliability="$Cwan1Reliability"
				uci set mwan3."${cellularwan1interface}".count="$Cwan1Count"
				uci set mwan3."${cellularwan1interface}".timeout="2"
				uci set mwan3."${cellularwan1interface}".down="$Cwan1Down"
				uci set mwan3."${cellularwan1interface}".up="$Cwan1Up"

				#member
				uci set mwan3.cwan1_m10_w1=member
				uci set mwan3.cwan1_m10_w1.interface="${cellularwan1interface}"
				uci set mwan3.cwan1_m10_w1.metric="$Cwan1Priority"
				uci set mwan3.cwan1_m10_w1.weight="$Cwan1Priority"

				#policy
				uci set mwan3.cwan1_only=policy
				uci add_list mwan3.cwan1_only.use_member="cwan1_m10_w1"
				uci set mwan3.cwan1_only.last_resort="default"

				#balance
				uci add_list mwan3.balanced.use_member="cwan1_m10_w1"
			fi
			
			#If pdp1 is ipv6
			if [ "$Pdp1" = "2" ]
            then
				uci set mwan3."${cellular1wan6interface}"=interface
                uci set mwan3."${cellular1wan6interface}".enabled="1"
                if [ "$Cwan6_1validtrackip" = "1" ]
                then
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp1"
                fi
                if [ "$Cwan6_1validtrackip" = "2" ]
                then
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp1"
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp2"
                fi
                if [ "$Cwan6_1validtrackip" = "3" ]
                then
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp1"
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp2"
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp3"
                fi
                if [ "$Cwan6_1validtrackip" = "4" ]
                then
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp1"
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp2"
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp3"
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp4"
                fi
				uci set mwan3."${cellular1wan6interface}".family="ipv6"
				uci set mwan3."${cellular1wan6interface}".reliability="$Cwan6_1Reliability"
				uci set mwan3."${cellular1wan6interface}".count="$Cwan6_1Count"
				uci set mwan3."${cellular1wan6interface}".timeout="2"
				uci set mwan3."${cellular1wan6interface}".down="$Cwan6_1Down"
				uci set mwan3."${cellular1wan6interface}".up="$Cwan6_1Up"
				
				uci set mwan3.cwan6_1_m10_w1=member
				uci set mwan3.cwan6_1_m10_w1.interface="${cellular1wan6interface}"
				uci set mwan3.cwan6_1_m10_w1.metric="$Cwan6_1Priority"
				uci set mwan3.cwan6_1_m10_w1.weight="$Cwan6_1Priority"
				
				uci set mwan3.cwan6_1_only=policy
				uci add_list mwan3.cwan6_1_only.use_member="cwan6_1_m10_w1"
				uci set mwan3.cwan6_1_only.last_resort="default"
				
				uci add_list mwan3.balanced.use_member="cwan6_1_m10_w1"
            fi 
			
			#CWAN2
			if [ "$sim2pdp" = "1" ]  || [ "$sim2pdp" = "3" ]
            then
				uci set mwan3."${cellularwan2interface}"=interface
				uci set mwan3."${cellularwan2interface}".enabled="1"

				if [ "$Cwan2Validtrackip" =  "1" ]
				then 
					uci add_list mwan3."${cellularwan2interface}".track_ip="$Cwan2TrackIp1"
				fi
				if [ "$Cwan2Validtrackip" =  "2" ]
				then 
					uci add_list mwan3."${cellularwan2interface}".track_ip="$Cwan2TrackIp1"
					uci add_list mwan3."${cellularwan2interface}".track_ip="$Cwan2TrackIp2"
				fi
				if [ "$Cwan2Validtrackip" =  "3" ]
				then 
					uci add_list mwan3."${cellularwan2interface}".track_ip="$Cwan2TrackIp1"
					uci add_list mwan3."${cellularwan2interface}".track_ip="$Cwan2TrackIp2"
					uci add_list mwan3."${cellularwan2interface}".track_ip="$Cwan2TrackIp3"
				fi
				if [ "$Cwan2Validtrackip" =  "4" ]
				then 
					uci add_list mwan3."${cellularwan2interface}".track_ip="$Cwan2TrackIp1"
					uci add_list mwan3."${cellularwan2interface}".track_ip="$Cwan2TrackIp2"
					uci add_list mwan3."${cellularwan2interface}".track_ip="$Cwan2TrackIp3"
					uci add_list mwan3."${cellularwan2interface}".track_ip="$Cwan2TrackIp4"
				fi

				uci set mwan3."${cellularwan2interface}".family="ipv4"
				uci set mwan3."${cellularwan2interface}".reliability="$Cwan2Reliability"
				uci set mwan3."${cellularwan2interface}".count="$Cwan2Count"
				uci set mwan3."${cellularwan2interface}".timeout="2"
				uci set mwan3."${cellularwan2interface}".down="$Cwan2Down"
				uci set mwan3."${cellularwan2interface}".up="$Cwan2Up"

				#member
				uci set mwan3.cwan2_m10_w1=member
				uci set mwan3.cwan2_m10_w1.interface="${cellularwan2interface}"
				uci set mwan3.cwan2_m10_w1.metric="$Cwan2Priority"
				uci set mwan3.cwan2_m10_w1.weight="$Cwan2Priority"

				#policy
				uci set mwan3.cwan2_only=policy
				uci add_list mwan3.cwan2_only.use_member="cwan2_m10_w1"
				uci set mwan3.cwan2_only.last_resort="default"

				#balance
				uci add_list mwan3.balanced.use_member="cwan2_m10_w1"
			fi
			
			#If pdp2 is ipv6
			if [ "$sim2pdp" = "2" ]
            then
				uci set mwan3."${cellular2wan6interface}"=interface
                uci set mwan3."${cellular2wan6interface}".enabled="1"
                if [ "$Cwan6_2validtrackip" = "1" ]
                then
                    uci add_list mwan3."${cellular2wan6interface}".track_ip="$Cwan6_2TrackIp1"
                fi
                if [ "$Cwan6_2validtrackip" = "2" ]
                then
                    uci add_list mwan3."${cellular2wan6interface}".track_ip="$Cwan6_2TrackIp1"
                    uci add_list mwan3."${cellular2wan6interface}".track_ip="$Cwan6_2TrackIp2"
                fi
                if [ "$Cwan6_2validtrackip" = "3" ]
                then
                    uci add_list mwan3."${cellular2wan6interface}".track_ip="$Cwan6_2TrackIp1"
                    uci add_list mwan3."${cellular2wan6interface}".track_ip="$Cwan6_2TrackIp2"
                    uci add_list mwan3."${cellular2wan6interface}".track_ip="$Cwan6_2TrackIp3"
                fi
                if [ "$Cwan6_2validtrackip" = "4" ]
                then
                    uci add_list mwan3."${cellular2wan6interface}".track_ip="$Cwan6_2TrackIp1"
                    uci add_list mwan3."${cellular2wan6interface}".track_ip="$Cwan6_2TrackIp2"
                    uci add_list mwan3."${cellular2wan6interface}".track_ip="$Cwan6_2TrackIp3"
                    uci add_list mwan3."${cellular2wan6interface}".track_ip="$Cwan6_2TrackIp4"
                fi
				uci set mwan3."${cellular2wan6interface}".family="ipv6"
				uci set mwan3."${cellular2wan6interface}".reliability="$Cwan6_2Reliability"
				uci set mwan3."${cellular2wan6interface}".count="$Cwan6_2Count"
				uci set mwan3."${cellular2wan6interface}".timeout="2"
				uci set mwan3."${cellular2wan6interface}".down="$Cwan6_2Down"
				uci set mwan3."${cellular2wan6interface}".up="$Cwan6_2Up"
				
				uci set mwan3.cwan6_2_m10_w1=member
				uci set mwan3.cwan6_2_m10_w1.interface="${cellular2wan6interface}"
				uci set mwan3.cwan6_2_m10_w1.metric="$Cwan6_2Priority"
				uci set mwan3.cwan6_2_m10_w1.weight="$Cwan6_2Priority"
				
				uci set mwan3.cwan6_2_only=policy
				uci add_list mwan3.cwan6_2_only.use_member="cwan6_2_m10_w1"
				uci set mwan3.cwan6_2_only.last_resort="default"
				
				uci add_list mwan3.balanced.use_member="cwan6_2_m10_w1"
			fi 
		
		#singlecellulardualsim
		elif [ "$CellularOperationModelocal" = "singlecellulardualsim" ]
		then
		
			#Don't delete CWAN1_0 & CWAN1_1 as we did earlier & no need to check if it's CWAN1_0 or CWAN1_1.
			#We need both CWAN1_0 and CWAN1_1 in mwan3 interfaces, else, incase of simswitch utility, 
			#systemstart.sh won't be executed and mwan3 interfaces wont be updated.
			uci delete mwan3.cwan1_m10_w1 > /dev/null 2>&1
			uci delete mwan3.cwan2_m10_w1 > /dev/null 2>&1
			uci delete mwan3.cwan6_1_m10_w1 > /dev/null 2>&1
			uci delete mwan3.cwan6_2_m10_w1 > /dev/null 2>&1
			
			#CWAN1_0
			#If pdp1 is ipv4 or ipv4v6
			if [ "$Pdp1" = "1" ]  || [ "$Pdp1" = "3" ]
            then

				uci set mwan3."${cellularwan1sim1interface}"=interface
				uci set mwan3."${cellularwan1sim1interface}".enabled="1"

				if [ "$Cwan1sim1Validtrackip" =  "1" ]
				then 
					uci add_list mwan3."${cellularwan1sim1interface}".track_ip="$Cwan1sim1TrackIp1"
				fi
				if [ "$Cwan1sim1Validtrackip" =  "2" ]
				then 
					uci add_list mwan3."${cellularwan1sim1interface}".track_ip="$Cwan1sim1TrackIp1"
					uci add_list mwan3."${cellularwan1sim1interface}".track_ip="$Cwan1sim1TrackIp2"
				fi
				if [ "$Cwan1sim1Validtrackip" =  "3" ]
				then 
					uci add_list mwan3."${cellularwan1sim1interface}".track_ip="$Cwan1sim1TrackIp1"
					uci add_list mwan3."${cellularwan1sim1interface}".track_ip="$Cwan1sim1TrackIp2"
					uci add_list mwan3."${cellularwan1sim1interface}".track_ip="$Cwan1sim1TrackIp3"
				fi
				if [ "$Cwan1sim1Validtrackip" =  "4" ]
				then 
					uci add_list mwan3."${cellularwan1sim1interface}".track_ip="$Cwan1sim1TrackIp1"
					uci add_list mwan3."${cellularwan1sim1interface}".track_ip="$Cwan1sim1TrackIp2"
					uci add_list mwan3."${cellularwan1sim1interface}".track_ip="$Cwan1sim1TrackIp3"
					uci add_list mwan3."${cellularwan1sim1interface}".track_ip="$Cwan1sim1TrackIp4"
				fi
			
				uci set mwan3."${cellularwan1sim1interface}".family="ipv4"
				uci set mwan3."${cellularwan1sim1interface}".reliability="$Cwan1sim1Reliability"
				uci set mwan3."${cellularwan1sim1interface}".count="$Cwan1sim1Count"
				uci set mwan3."${cellularwan1sim1interface}".timeout="2"
				uci set mwan3."${cellularwan1sim1interface}".down="$Cwan1sim1Down"
				uci set mwan3."${cellularwan1sim1interface}".up="$Cwan1sim1Up"

				#member
				uci set mwan3.cwan1sim1_m10_w1=member
				uci set mwan3.cwan1sim1_m10_w1.interface="${cellularwan1sim1interface}"
				uci set mwan3.cwan1sim1_m10_w1.metric="$Cwan1sim1Priority"
				uci set mwan3.cwan1sim1_m10_w1.weight="$Cwan1sim1Priority"

				#policy
				uci set mwan3.cwan1sim1_only=policy
				uci add_list mwan3.cwan1sim1_only.use_member="cwan1sim1_m10_w1"
				uci set mwan3.cwan1sim1_only.last_resort="default"

				#balance
				uci add_list mwan3.balanced.use_member="cwan1sim1_m10_w1"
			fi
			
			#If pdp1 is ipv6
			if [ "$Pdp1" = "2" ]
            then
				uci set mwan3."${cellular1wan6interface}"=interface
                uci set mwan3."${cellular1wan6interface}".enabled="1"
                if [ "$Cwan6_1validtrackip" = "1" ]
                then
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp1"
                fi
                if [ "$Cwan6_1validtrackip" = "2" ]
                then
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp1"
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp2"
                fi
                if [ "$Cwan6_1validtrackip" = "3" ]
                then
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp1"
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp2"
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp3"
                fi
                if [ "$Cwan6_1validtrackip" = "4" ]
                then
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp1"
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp2"
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp3"
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp4"
                fi
				uci set mwan3."${cellular1wan6interface}".family="ipv6"
				uci set mwan3."${cellular1wan6interface}".reliability="$Cwan6_1Reliability"
				uci set mwan3."${cellular1wan6interface}".count="$Cwan6_1Count"
				uci set mwan3."${cellular1wan6interface}".timeout="2"
				uci set mwan3."${cellular1wan6interface}".down="$Cwan6_1Down"
				uci set mwan3."${cellular1wan6interface}".up="$Cwan6_1Up"
				
				uci set mwan3.cwan6_1_m10_w1=member
				uci set mwan3.cwan6_1_m10_w1.interface="${cellular1wan6interface}"
				uci set mwan3.cwan6_1_m10_w1.metric="$Cwan6_1Priority"
				uci set mwan3.cwan6_1_m10_w1.weight="$Cwan6_1Priority"
				
				uci set mwan3.cwan6_1_only=policy
				uci add_list mwan3.cwan6_1_only.use_member="cwan6_1_m10_w1"
				uci set mwan3.cwan6_1_only.last_resort="default"
				
				uci add_list mwan3.balanced.use_member="cwan6_1_m10_w1"
            fi 

			#CWAN1_1
			#If pdp2 is ipv4 or ipv4v6
			if [ "$sim2pdp" = "1" ]  || [ "$sim2pdp" = "3" ]
            then
				uci set mwan3."${cellularwan1sim2interface}"=interface
				uci set mwan3."${cellularwan1sim2interface}".enabled="1"

				if [ "$Cwan1sim2Validtrackip" =  "1" ]
				then 
					uci add_list mwan3."${cellularwan1sim2interface}".track_ip="$Cwan1sim2TrackIp1"
				fi
				if [ "$Cwan1sim2Validtrackip" =  "2" ]
				then 
					uci add_list mwan3."${cellularwan1sim2interface}".track_ip="$Cwan1sim2TrackIp1"
					uci add_list mwan3."${cellularwan1sim2interface}".track_ip="$Cwan1sim2TrackIp2"
				fi
				if [ "$Cwan1sim2Validtrackip" =  "3" ]
				then 
					uci add_list mwan3."${cellularwan1sim2interface}".track_ip="$Cwan1sim2TrackIp1"
					uci add_list mwan3."${cellularwan1sim2interface}".track_ip="$Cwan1sim2TrackIp2"
					uci add_list mwan3."${cellularwan1sim2interface}".track_ip="$Cwan1sim2TrackIp3"
				fi
				if [ "$Cwan1sim2Validtrackip" =  "4" ]
				then 
					uci add_list mwan3."${cellularwan1sim2interface}".track_ip="$Cwan1sim2TrackIp1"
					uci add_list mwan3."${cellularwan1sim2interface}".track_ip="$Cwan1sim2TrackIp2"
					uci add_list mwan3."${cellularwan1sim2interface}".track_ip="$Cwan1sim2TrackIp3"
					uci add_list mwan3."${cellularwan1sim2interface}".track_ip="$Cwan1sim2TrackIp4"
				fi

				uci set mwan3."${cellularwan1sim2interface}".family="ipv4"
				uci set mwan3."${cellularwan1sim2interface}".reliability="$Cwan1sim2Reliability"
				uci set mwan3."${cellularwan1sim2interface}".count="$Cwan1sim2Count"
				uci set mwan3."${cellularwan1sim2interface}".timeout="2"
				uci set mwan3."${cellularwan1sim2interface}".down="$Cwan1sim2Down"
				uci set mwan3."${cellularwan1sim2interface}".up="$Cwan1sim2Up"

				#member
				uci set mwan3.cwan1sim2_m10_w1=member
				uci set mwan3.cwan1sim2_m10_w1.interface="${cellularwan1sim2interface}"
				uci set mwan3.cwan1sim2_m10_w1.metric="$Cwan1sim2Priority"
				uci set mwan3.cwan1sim2_m10_w1.weight="$Cwan1sim2Priority"

				#policy
				uci set mwan3.cwan1sim2_only=policy
				uci add_list mwan3.cwan1sim2_only.use_member="cwan1sim2_m10_w1"
				uci set mwan3.cwan1sim2_only.last_resort="default"

				#balance
				uci add_list mwan3.balanced.use_member="cwan1sim2_m10_w1"
			fi
			
			#If pdp2 is ipv6
			if [ "$sim2pdp" = "2" ]
            then
				uci set mwan3."${cellular2wan6interface}"=interface
                uci set mwan3."${cellular2wan6interface}".enabled="1"
                if [ "$Cwan6_2validtrackip" = "1" ]
                then
                    uci add_list mwan3."${cellular2wan6interface}".track_ip="$Cwan6_2TrackIp1"
                fi
                if [ "$Cwan6_2validtrackip" = "2" ]
                then
                    uci add_list mwan3."${cellular2wan6interface}".track_ip="$Cwan6_2TrackIp1"
                    uci add_list mwan3."${cellular2wan6interface}".track_ip="$Cwan6_2TrackIp2"
                fi
                if [ "$Cwan6_2validtrackip" = "3" ]
                then
                    uci add_list mwan3."${cellular2wan6interface}".track_ip="$Cwan6_2TrackIp1"
                    uci add_list mwan3."${cellular2wan6interface}".track_ip="$Cwan6_2TrackIp2"
                    uci add_list mwan3."${cellular2wan6interface}".track_ip="$Cwan6_2TrackIp3"
                fi
                if [ "$Cwan6_2validtrackip" = "4" ]
                then
                    uci add_list mwan3."${cellular2wan6interface}".track_ip="$Cwan6_2TrackIp1"
                    uci add_list mwan3."${cellular2wan6interface}".track_ip="$Cwan6_2TrackIp2"
                    uci add_list mwan3."${cellular2wan6interface}".track_ip="$Cwan6_2TrackIp3"
                    uci add_list mwan3."${cellular2wan6interface}".track_ip="$Cwan6_2TrackIp4"
                fi
				uci set mwan3."${cellular2wan6interface}".family="ipv6"
				uci set mwan3."${cellular2wan6interface}".reliability="$Cwan6_2Reliability"
				uci set mwan3."${cellular2wan6interface}".count="$Cwan6_2Count"
				uci set mwan3."${cellular2wan6interface}".timeout="2"
				uci set mwan3."${cellular2wan6interface}".down="$Cwan6_2Down"
				uci set mwan3."${cellular2wan6interface}".up="$Cwan6_2Up"
				
				uci set mwan3.cwan6_2_m10_w1=member
				uci set mwan3.cwan6_2_m10_w1.interface="${cellular2wan6interface}"
				uci set mwan3.cwan6_2_m10_w1.metric="$Cwan6_2Priority"
				uci set mwan3.cwan6_2_m10_w1.weight="$Cwan6_2Priority"
				
				uci set mwan3.cwan6_2_only=policy
				uci add_list mwan3.cwan6_2_only.use_member="cwan6_2_m10_w1"
				uci set mwan3.cwan6_2_only.last_resort="default"
				
				uci add_list mwan3.balanced.use_member="cwan6_2_m10_w1"
			fi 
		
		#singlecellularsinglesim
		else
			uci delete mwan3.cwan1_m10_w1 > /dev/null 2>&1
			uci delete mwan3.cwan6_1_m10_w1 > /dev/null 2>&1
			uci delete mwan3.cwan6_2_m10_w1 > /dev/null 2>&1
			
			#CWAN1
			#If pdp1 is ipv4 or ipv4v6
			if [ "$Pdp1" = "1" ]  || [ "$Pdp1" = "3" ]
            then
				uci set mwan3."${cellularwan1interface}"=interface
				uci set mwan3."${cellularwan1interface}".enabled="1"

				if [ "$Cwan1Validtrackip" =  "1" ]
				then 
					uci add_list mwan3."${cellularwan1interface}".track_ip="$Cwan1TrackIp1"
				fi
				if [ "$Cwan1Validtrackip" =  "2" ]
				then 
					uci add_list mwan3."${cellularwan1interface}".track_ip="$Cwan1TrackIp1"
					uci add_list mwan3."${cellularwan1interface}".track_ip="$Cwan1TrackIp2"
				fi
				if [ "$Cwan1Validtrackip" =  "3" ]
				then 
					uci add_list mwan3."${cellularwan1interface}".track_ip="$Cwan1TrackIp1"
					uci add_list mwan3."${cellularwan1interface}".track_ip="$Cwan1TrackIp2"
					uci add_list mwan3."${cellularwan1interface}".track_ip="$Cwan1TrackIp3"
				fi
				if [ "$Cwan1Validtrackip" =  "4" ]
				then 
					uci add_list mwan3."${cellularwan1interface}".track_ip="$Cwan1TrackIp1"
					uci add_list mwan3."${cellularwan1interface}".track_ip="$Cwan1TrackIp2"
					uci add_list mwan3."${cellularwan1interface}".track_ip="$Cwan1TrackIp3"
					uci add_list mwan3."${cellularwan1interface}".track_ip="$Cwan1TrackIp4"
				fi

				uci set mwan3."${cellularwan1interface}".family="ipv4"
				uci set mwan3."${cellularwan1interface}".reliability="$Cwan1Reliability"
				uci set mwan3."${cellularwan1interface}".count="$Cwan1Count"
				uci set mwan3."${cellularwan1interface}".timeout="2"
				uci set mwan3."${cellularwan1interface}".down="$Cwan1Down"
				uci set mwan3."${cellularwan1interface}".up="$Cwan1Up"

				#member
				uci set mwan3.cwan1_m10_w1=member
				uci set mwan3.cwan1_m10_w1.interface="${cellularwan1interface}"
				uci set mwan3.cwan1_m10_w1.metric="$Cwan1Priority"
				uci set mwan3.cwan1_m10_w1.weight="$Cwan1Priority"

				#policy
				uci set mwan3.cwan1_only=policy
				uci add_list mwan3.cwan1_only.use_member="cwan1_m10_w1"
				uci set mwan3.cwan1_only.last_resort="default"

				#balance
				uci add_list mwan3.balanced.use_member="cwan1_m10_w1"
			fi
			
			#If pdp1 is ipv6
			if [ "$Pdp1" = "2" ]
            then
				uci set mwan3."${cellular1wan6interface}"=interface
                uci set mwan3."${cellular1wan6interface}".enabled="1"
                if [ "$Cwan6_1validtrackip" = "1" ]
                then
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp1"
                fi
                if [ "$Cwan6_1validtrackip" = "2" ]
                then
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp1"
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp2"
                fi
                if [ "$Cwan6_1validtrackip" = "3" ]
                then
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp1"
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp2"
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp3"
                fi
                if [ "$Cwan6_1validtrackip" = "4" ]
                then
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp1"
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp2"
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp3"
                    uci add_list mwan3."${cellular1wan6interface}".track_ip="$Cwan6_1TrackIp4"
                fi
				uci set mwan3."${cellular1wan6interface}".family="ipv6"
				uci set mwan3."${cellular1wan6interface}".reliability="$Cwan6_1Reliability"
				uci set mwan3."${cellular1wan6interface}".count="$Cwan6_1Count"
				uci set mwan3."${cellular1wan6interface}".timeout="2"
				uci set mwan3."${cellular1wan6interface}".down="$Cwan6_1Down"
				uci set mwan3."${cellular1wan6interface}".up="$Cwan6_1Up"
				
				uci set mwan3.cwan6_1_m10_w1=member
				uci set mwan3.cwan6_1_m10_w1.interface="${cellular1wan6interface}"
				uci set mwan3.cwan6_1_m10_w1.metric="$Cwan6_1Priority"
				uci set mwan3.cwan6_1_m10_w1.weight="$Cwan6_1Priority"
				
				uci set mwan3.cwan6_1_only=policy
				uci add_list mwan3.cwan6_1_only.use_member="cwan6_1_m10_w1"
				uci set mwan3.cwan6_1_only.last_resort="default"
				
				uci add_list mwan3.balanced.use_member="cwan6_1_m10_w1"
            fi			
		fi
	
	#If EnableCellular is 0.
	else
		uci delete mwan3.cwan1sim1_m10_w1 > /dev/null 2>&1
		uci delete mwan3.cwan1sim2_m10_w1 > /dev/null 2>&1
		uci delete mwan3.cwan1_m10_w1 > /dev/null 2>&1
		uci delete mwan3.cwan2_m10_w1 > /dev/null 2>&1
		uci delete mwan3.cwan1_only > /dev/null 2>&1
		uci delete mwan3.cwan2_only > /dev/null 2>&1
		uci delete mwan3.cwan1sim1_only > /dev/null 2>&1
		uci delete mwan3.cwan1sim2_only > /dev/null 2>&1
		uci delete mwan3.cwan6_1_m10_w1 > /dev/null 2>&1
		uci delete mwan3.cwan6_2_m10_w1 > /dev/null 2>&1
		uci delete mwan3.cwan6_1_only > /dev/null 2>&1
		uci delete mwan3.cwan6_2_only > /dev/null 2>&1
		uci delete mwan3."${cellularwan1interface}"
		uci delete mwan3."${cellularwan1sim1interface}"
		uci delete mwan3."${cellularwan1sim2interface}"
		uci delete mwan3."${cellularwan2interface}"
		uci delete mwan3."${cellular1wan6interface}"
		uci delete mwan3."${cellular2wan6interface}"
	fi

	uci commit mwan3
}

UpdateWirelessConfig()
{
	# 1 is for enable; 0 for disable
	if [ "$wifi1enable" = "1" ]
	then
		uci delete network."${wifiinterface}" > /dev/null 2>&1
		uci delete  network."${wifi5interface}" > /dev/null 2>&1
		
		#wifi - 2.4GHZ	
		#DHCP
		uci set dhcp."${wifiinterface}".start="$Radio0DHCPRange"
		uci set dhcp."${wifiinterface}".limit="$Radio0DHCPLimit"
		
		#NETWORK
		uci set network."${wifiinterface}"=interface
		uci set network."${wifiinterface}".netmask="255.255.255.0"
		uci set network."${wifiinterface}".ipaddr="$Radio0DhcpIp"
		uci set network."${wifiinterface}".proto="static"
		uci set network."${wifiinterface}".ifname="wlan0"
		
		#Wireless
		#hwmode changed to band
		uci set wireless."${wifiinterface}"="wifi-device"
		uci set wireless."${wifiinterface}".type="mac80211"
		uci set wireless."${wifiinterface}".path="1e140000.pcie/pci0000:00/0000:00:00.0/0000:01:00.0"
		uci set wireless."${wifiinterface}".variant="mt7603e"
		uci set wireless."${wifiinterface}".channel="$WifiDevicesChannel"
		uci set wireless."${wifiinterface}".band="2g"
		uci set wireless."${wifiinterface}".htmode="$channelwidth"
		uci set wireless."${wifiinterface}".disabled="0"
		uci set wireless."${wifiinterface}".country="$CountryCode"
		uci set wireless."${wifiinterface}".txpower="$TxPower"

		uci set wireless."${wifiap}"="wifi-iface"
		uci set wireless."${wifiap}".device="ra0"
		uci set wireless."${wifiap}".mode="ap"
		uci set wireless."${wifiap}".network="lan"
		uci set wireless."${wifiap}".ifname="wlan0"
		uci set wireless."${wifiap}".disabled="0"
		uci set wireless."${wifiap}".key="$Wifi1Key"
		uci set wireless."${wifiap}".encryption="$Wifi1Encryption"
		uci set wireless."${wifiap}".ssid="$Wifi1Ssid"

		#wifi - 5GHZ	
		#DHCP
		uci set dhcp."${wifi5interface}".limit="$wifi5Radio0DHCPlimit"
		uci set dhcp."${wifi5interface}".start="$wifi5Radio0DHCPrange"
		
		#NETWORK
		uci set network."${wifi5interface}"=interface
		uci set network."${wifi5interface}".netmask="255.255.255.0"
		uci set network."${wifi5interface}".ipaddr="$wifi5radio0dhcpip"
		uci set network."${wifi5interface}".proto="static"
		uci set network."${wifi5interface}".ifname="wlan1"
		
		#Wireless
		#hwmode changed to band
		uci set wireless."${wifi5interface}"="wifi-device"
		uci set wireless."${wifi5interface}".type="mac80211"
		uci set wireless."${wifi5interface}".path="1e140000.pcie/pci0000:00/0000:00:01.0/0000:02:00.0"
		uci set wireless."${wifi5interface}".variant="mt7663"
		uci set wireless."${wifi5interface}".channel="$wifi5deviceschannel"
		uci set wireless."${wifi5interface}".band="5g"
		uci set wireless."${wifi5interface}".htmode="$wifi5channelwidth"
		uci set wireless."${wifi5interface}".disabled="0"
		uci set wireless."${wifi5interface}".country="$wifi5CountryCode"
		uci set wireless."${wifi5interface}".txpower="$wifi5TxPower"

		uci set wireless."${wifi5ap}"="wifi-iface"
		uci set wireless."${wifi5ap}".device="rai0"
		uci set wireless."${wifi5ap}".mode="ap"
		uci set wireless."${wifi5ap}".network="lan"
		uci set wireless."${wifi5ap}".ifname="wlan1"
		uci set wireless."${wifi5ap}".disabled="0"
		uci set wireless."${wifi5ap}".key="$wifi5key"
		uci set wireless."${wifi5ap}".encryption="$wifi5encryption"
		uci set wireless."${wifi5ap}".ssid="$wifi5ssid"
	else
		uci delete network."${wifiinterface}" > /dev/null 2>&1
		uci delete  network."${wifi5interface}" > /dev/null 2>&1
		uci set wireless."${wifiinterface}".disabled="1"
		uci set wireless."${wifiap}".disabled="1"
		uci set wireless."${wifi5interface}".disabled="1"
		uci set wireless."${wifi5ap}".disabled="1"
	fi
	
	uci commit wireless
	uci commit network
	uci commit dhcp
	
	#HAVE TO TEST GUEST WIFI
		
	#if [ "$guestwifienable2" = "1" ]
	#then
		#uci set network."${wifiap1}"=interface
		#uci set network."${wifiap1}".netmask="255.255.255.0"
		#uci set network."${wifiap1}".ipaddr="$guestradio0dhcpip2"
		#uci set network."${wifiap1}".proto="static"
		#uci set network."${wifiap1}".ifname="ra1"
		#uci set dhcp."${wifiap1}".limit="$Radio0DHCPlimit"
		#uci set dhcp."${wifiap1}".start="$Radio0DHCPrange"
		#ssid=$(grep -w "SSID2" ${wirelessdatfile})        
		#ssid_replace="SSID2=$guestwifissid2"
		#sed -i "s/${ssid}/${ssid_replace}/" "$wirelessdatfile"
		#WPAPSK2=$(grep -w "WPAPSK2" ${wirelessdatfile})        
		#WPAPSK2_replace="WPAPSK2=$guestwifikey2"
		#sed -i "s/${WPAPSK2}/${WPAPSK2_replace}/" "$wirelessdatfile"
	#else
		#uci delete network."${wifiap1}"=interface
		#uci delete wireless."${wifiap1}"=interface
	#fi

	#if [ "$guestwifienable5" = "1" ]
	#then
		#uci set network."${wifiap51}"=interface
		#uci set network."${wifiap51}".netmask="255.255.255.0"
		#uci set network."${wifiap51}".ipaddr="$guestradio0dhcpip5"
		#uci set network."${wifiap51}".proto="static"
		#uci set network."${wifiap51}".ifname="rai1"		
		#uci set dhcp."${wifiap51}".limit="$guestRadio0DHCPlimit"
		#uci set dhcp."${wifiap51}".start="$guestRadio0DHCPrange"
		#ssid=$(grep -w "SSID2" ${wirelessdatfile1})        
		#ssid_replace="SSID2=$guestwifissid5"
		#sed -i "s/${ssid}/${ssid_replace}/" "$wirelessdatfile1"
		#WPAPSK2=$(grep -w "WPAPSK2" ${wirelessdatfile1})        
		#WPAPSK2_replace="WPAPSK2=$guestwifikey5"
		#sed -i "s/${WPAPSK2}/${WPAPSK2_replace}/" "$wirelessdatfile1"
	#else
		#uci delete network."${wifiap51}"=interface
		#uci delete wireless."${wifiap51}"=interface
	#fi 

}

UpdateScheduledWifiOnOff()
{	
	        CronReadListValuesMaintenanceReboot()
			{
				TmpVal=""
				local value="$1"
				local VarName="$2"
				echo "var is $VarName"
				echo "value  is $value"
				TmpVal="$(eval echo '$'ListValue"$VarName")"
				eval ListValue"$VarName"="${TmpVal}${value},"
			
			}
			
	
             if [ "$ScheduledOnOff" = "1" ]
             then
				config_load "$SystemConfigFile"				
				config_list_foreach "sysconfig" fromHours CronReadListValuesMaintenanceReboot fromHours
				config_list_foreach "sysconfig" fromMinutes CronReadListValuesMaintenanceReboot fromMinutes
				config_list_foreach "sysconfig" toHours CronReadListValuesMaintenanceReboot toHours
				config_list_foreach "sysconfig" toMinutes CronReadListValuesMaintenanceReboot toMinutes
				config_list_foreach "sysconfig" DayOfMonth CronReadListValuesMaintenanceReboot DayOfMonth
             	config_list_foreach "sysconfig" Month CronReadListValuesMaintenanceReboot Month
				config_list_foreach "sysconfig" DayOfWeek CronReadListValuesMaintenanceReboot DayOfWeek
             fi

			
		ListValfromHours=$(echo "$ListValuefromHours" | sed s'/,$//')
	    ListValfromMinutes=$(echo "$ListValuefromMinutes" | sed s'/,$//')
	    ListValtoHours=$(echo "$ListValuetoHours" | sed s'/,$//')
	    ListValtoMinutes=$(echo "$ListValuetoMinutes" | sed s'/,$//')
	    ListValDayOfWeek=$(echo "$ListValueDayOfWeek" | sed s'/,$//')
	    ListValDayOfMonth=$(echo "$ListValueDayOfMonth" | sed s'/,$//')
	    ListValMonth=$(echo "$ListValueMonth" | sed s'/,$//')
	    echo "$ListValfromMinutes $ListValfromHours * * $ListValDayOfWeek /root/InterfaceManager/script/ScheduledWifiOff.sh" >> /etc/crontabs/root
	    echo "$ListValtoMinutes $ListValtoHours * * $ListValDayOfWeek /root/InterfaceManager/script/ScheduledWifiOn.sh" >> /etc/crontabs/root

	
}

UpdateNetworkConfig()
{
	if [ "$Port1Mode" = "LAN1" ] 
	then
		uci delete network.SW_LAN > /dev/null 2>&1
		uci delete network.swlan > /dev/null 2>&1
		uci delete network.LAN1 > /dev/null 2>&1
		uci delete dhcp."${SwlanInterfaceName}" > /dev/null 2>&1
		uci delete network."${SwlanInterfaceName}" > /dev/null 2>&1
	    uci delete network."${Port1WaninterfaceName}" > /dev/null 2>&1
	    uci set network.lan1=switch_vlan
		uci set network.lan1.device="switch0"
		uci set network.lan1.vlan="1"
		uci set network.lan1.ports="0 6t"
	   	if [ "$EthernetProtocolPort1lan" = "static" ]
	    then
	        uci delete dhcp."${Port1lanInterfaceName}" > /dev/null 2>&1
			uci set network."${Port1lanInterfaceName}"=interface
			uci set network."${Port1lanInterfaceName}".ifname="$Port1LanIfName"
			uci set network."${Port1lanInterfaceName}".proto="static"
			uci set network."${Port1lanInterfaceName}".ipaddr="$EthernetServerStaticIPPort1lan"
			uci set network."${Port1lanInterfaceName}".netmask="$EthernetServerStaticNetmaskPort1Lan"
			uci set network."${Port1lanInterfaceName}".macaddr="$Port1MacId"
		else
		    uci set network."${Port1lanInterfaceName}"=interface
			uci set network."${Port1lanInterfaceName}".ifname="$Port1LanIfName"
			uci set network."${Port1lanInterfaceName}".proto="static"
			uci set network."${Port1lanInterfaceName}".ipaddr="$EthernetServerDHCPIPPort1lan"
			uci set network."${Port1lanInterfaceName}".netmask="$EthernetServerDHCPNetmaskPort1Lan"
			uci set network."${Port1lanInterfaceName}".macaddr="$Port1MacId"
			uci set dhcp."${Port1lanInterfaceName}"=dhcp
			uci set	dhcp."${Port1lanInterfaceName}".interface="$Port1lanInterfaceName"
			uci set	dhcp."${Port1lanInterfaceName}".start="$EthernetServerDHCPrangePort1lan"
			uci set	dhcp."${Port1lanInterfaceName}".limit="$EthernetServerDHCPlimitPort1lan"
			uci set	dhcp."${Port1lanInterfaceName}".leasetime="12h"
			uci set	dhcp."${Port1lanInterfaceName}".dhcpv6="disabled"
			uci set	dhcp."${Port1lanInterfaceName}".ra="disabled"
        fi
        if [ $EthernetServerStaticDnsServer1 = "1" ]
		then 
			uci add_list network."${Port1lanInterfaceName}".dns="$EthernetServerStaticDnsServer1No1"
		elif [ $EthernetServerStaticDnsServer1 = "2" ]
		then 
			uci add_list network."${Port1lanInterfaceName}".dns="$EthernetServerStaticDnsServer1No1"
			uci add_list network."${Port1lanInterfaceName}".dns="$EthernetServerStaticDnsServer1No2"	
		fi
    elif [ "$Port1Mode" = "EWAN1" ] 
	then
		uci delete network.SW_LAN > /dev/null 2>&1
		uci delete network.swlan > /dev/null 2>&1
		uci delete dhcp."${SwlanInterfaceName}" > /dev/null 2>&1
		uci delete network."${SwlanInterfaceName}" > /dev/null 2>&1
		uci delete dhcp."${Port1lanInterfaceName}" > /dev/null 2>&1
        uci delete network."${Port1lanInterfaceName}" > /dev/null 2>&1  
        uci set network.lan1=switch_vlan
		uci set network.lan1.device="switch0"
		uci set network.lan1.vlan="1"
		uci set network.lan1.ports="0 6t"    	   	
        if [ "$EthernetProtocolPort1wan" = "static" ]
	    then
			uci set network."${Port1WaninterfaceName}"=interface
			uci set network."${Port1WaninterfaceName}".ifname="$Port1LanIfName"
			uci set network."${Port1WaninterfaceName}".proto="static"
			uci set network."${Port1WaninterfaceName}".ipaddr="$EthernetClientStaticIPPort1wan"
			uci set network."${Port1WaninterfaceName}".gateway="$EthernetClientStaticGatewayPort1wan"
			uci set network."${Port1WaninterfaceName}".metric="$Ewan1Priority"
			uci set network."${Port1WaninterfaceName}".netmask="$EthernetClientnetmaskPort1Wan"
			uci set network."${Port1WaninterfaceName}".macaddr="$Port1MacId"
		else
		    uci set network."${Port1WaninterfaceName}"=interface
		    uci set network."${Port1WaninterfaceName}".ifname="$Port1LanIfName"
			uci set network."${Port1WaninterfaceName}".proto="dhcp"
			uci set network."${Port1WaninterfaceName}".gateway="$EthernetClientDHCPGatewayPort1wan"
			uci set network."${Port1WaninterfaceName}".metric="$Ewan1Priority"
			uci set network."${Port1WaninterfaceName}".macaddr="$Port1MacId"
		fi
    else
		uci delete network.lan1 > /dev/null 2>&1
        uci delete dhcp."${Port1lanInterfaceName}" > /dev/null 2>&1
        uci delete network."${Port1lanInterfaceName}" > /dev/null 2>&1
       	uci delete network."${Port1WaninterfaceName}" > /dev/null 2>&1
		port1="0"
		SWNetworkConfig
    fi
    
	if [ "$Port2Mode" = "LAN2" ] 
	then
		uci delete network.SW_LAN > /dev/null 2>&1
		uci delete network.swlan > /dev/null 2>&1
		uci delete network.LAN2 > /dev/null 2>&1
		uci delete dhcp."${SwlanInterfaceName}" > /dev/null 2>&1
		uci delete network."${SwlanInterfaceName}" > /dev/null 2>&1
	    uci delete network."${Port2WaninterfaceName}" > /dev/null 2>&1
	    uci set network.lan2=switch_vlan
		uci set network.lan2.device="switch0"
		uci set network.lan2.vlan="2"
		uci set network.lan2.ports="1 6t"
	   	if [ "$EthernetProtocolPort2lan" = "static" ]
	    then
	        uci delete dhcp."${Port2lanInterfaceName}" > /dev/null 2>&1
			uci set network."${Port2lanInterfaceName}"=interface
			uci set network."${Port2lanInterfaceName}".ifname="$Port2LanIfName"
			uci set network."${Port2lanInterfaceName}".proto="static"
			uci set network."${Port2lanInterfaceName}".ipaddr="$EthernetServerStaticIPPort2lan"
			uci set network."${Port2lanInterfaceName}".netmask="$EthernetServerStaticNetmaskPort2Lan"
			uci set network."${Port2lanInterfaceName}".macaddr="$Port2MacId"
		else
		    uci set network."${Port2lanInterfaceName}"=interface
			uci set network."${Port2lanInterfaceName}".ifname="$Port2LanIfName"
			uci set network."${Port2lanInterfaceName}".proto="static"
			uci set network."${Port2lanInterfaceName}".ipaddr="$EthernetServerDHCPIPPort2lan"
			uci set network."${Port2lanInterfaceName}".netmask="$EthernetServerDHCPNetmaskPort2Lan"
			uci set network."${Port2lanInterfaceName}".macaddr="$Port2MacId"
			uci set dhcp."${Port2lanInterfaceName}"=dhcp
			uci set	dhcp."${Port2lanInterfaceName}".interface="$Port2lanInterfaceName"
			uci set	dhcp."${Port2lanInterfaceName}".start="$EthernetServerDHCPrangePort2lan"
			uci set	dhcp."${Port2lanInterfaceName}".limit="$EthernetServerDHCPlimitPort2lan"
			uci set	dhcp."${Port2lanInterfaceName}".leasetime="12h"
			uci set	dhcp."${Port2lanInterfaceName}".dhcpv6="disabled"
			uci set	dhcp."${Port2lanInterfaceName}".ra="disabled"
        fi
        if [ $EthernetServerStaticDnsServer2 = "1" ]
		then 
			uci add_list network."${Port2lanInterfaceName}".dns="$EthernetServerStaticDnsServer2No1"
		elif [ $EthernetServerStaticDnsServer2 = "2" ]
		then 
			uci add_list network."${Port2lanInterfaceName}".dns="$EthernetServerStaticDnsServer2No1"
			uci add_list network."${Port2lanInterfaceName}".dns="$EthernetServerStaticDnsServer2No2"	
		fi
    elif [ "$Port2Mode" = "EWAN2" ] 
	then
		uci delete network.SW_LAN > /dev/null 2>&1
		uci delete network.swlan > /dev/null 2>&1
		uci delete dhcp."${SwlanInterfaceName}" > /dev/null 2>&1
		uci delete network."${SwlanInterfaceName}" > /dev/null 2>&1
		uci delete dhcp."${Port2lanInterfaceName}" > /dev/null 2>&1
        uci delete network."${Port2lanInterfaceName}" > /dev/null 2>&1  
        uci set network.lan2=switch_vlan
		uci set network.lan2.device="switch0"
		uci set network.lan2.vlan="2"
		uci set network.lan2.ports="1 6t"    	   	
        if [ "$EthernetProtocolPort2wan" = "static" ]
	    then
			uci set network."${Port2WaninterfaceName}"=interface
			uci set network."${Port2WaninterfaceName}".ifname="$Port2LanIfName"
			uci set network."${Port2WaninterfaceName}".proto="static"
			uci set network."${Port2WaninterfaceName}".ipaddr="$EthernetClientStaticIPPort2wan"
			uci set network."${Port2WaninterfaceName}".gateway="$EthernetClientStaticGatewayPort2wan"
			uci set network."${Port2WaninterfaceName}".metric="$Ewan2Priority"
			uci set network."${Port2WaninterfaceName}".netmask="$EthernetClientnetmaskPort2Wan"
			uci set network."${Port2WaninterfaceName}".macaddr="$Port2MacId"
		else
		    uci set network."${Port2WaninterfaceName}"=interface
		    uci set network."${Port2WaninterfaceName}".ifname="$Port2LanIfName"
			uci set network."${Port2WaninterfaceName}".proto="dhcp"
			uci set network."${Port2WaninterfaceName}".gateway="$EthernetClientDHCPGatewayPort2wan"
			uci set network."${Port2WaninterfaceName}".metric="$Ewan2Priority"
			uci set network."${Port2WaninterfaceName}".macaddr="$Port2MacId"
		fi
    else
		uci delete network.lan2 > /dev/null 2>&1
        uci delete dhcp."${Port2lanInterfaceName}" > /dev/null 2>&1
        uci delete network."${Port2lanInterfaceName}" > /dev/null 2>&1
       	uci delete network."${Port2WaninterfaceName}" > /dev/null 2>&1
		port2="1"
		SWNetworkConfig
    fi
    
	if [ "$Port3Mode" = "LAN3" ] 
	then
		uci delete network.SW_LAN > /dev/null 2>&1
		uci delete network.swlan > /dev/null 2>&1
		uci delete network.LAN3 > /dev/null 2>&1
		uci delete dhcp."${SwlanInterfaceName}" > /dev/null 2>&1
		uci delete network."${SwlanInterfaceName}" > /dev/null 2>&1
	    uci delete network."${Port3WaninterfaceName}" > /dev/null 2>&1
	    uci set network.lan3=switch_vlan
		uci set network.lan3.device="switch0"
		uci set network.lan3.vlan="3"
		uci set network.lan3.ports="2 6t"
	   	if [ "$EthernetProtocolPort3lan" = "static" ]
	    then
	        uci delete dhcp."${Port3lanInterfaceName}" > /dev/null 2>&1
			uci set network."${Port3lanInterfaceName}"=interface
			uci set network."${Port3lanInterfaceName}".ifname="$Port3LanIfName"
			uci set network."${Port3lanInterfaceName}".proto="static"
			uci set network."${Port3lanInterfaceName}".ipaddr="$EthernetServerStaticIPPort3lan"
			uci set network."${Port3lanInterfaceName}".netmask="$EthernetServerStaticNetmaskPort3Lan"
			uci set network."${Port3lanInterfaceName}".macaddr="$Port3MacId"
		else
		    uci set network."${Port3lanInterfaceName}"=interface
			uci set network."${Port3lanInterfaceName}".ifname="$Port3LanIfName"
			uci set network."${Port3lanInterfaceName}".proto="static"
			uci set network."${Port3lanInterfaceName}".ipaddr="$EthernetServerDHCPIPPort3lan"
			uci set network."${Port3lanInterfaceName}".netmask="$EthernetServerDHCPNetmaskPort3Lan"
			uci set network."${Port3lanInterfaceName}".macaddr="$Port3MacId"
			uci set dhcp."${Port3lanInterfaceName}"=dhcp
			uci set	dhcp."${Port3lanInterfaceName}".interface="$Port3lanInterfaceName"
			uci set	dhcp."${Port3lanInterfaceName}".start="$EthernetServerDHCPrangePort3lan"
			uci set	dhcp."${Port3lanInterfaceName}".limit="$EthernetServerDHCPlimitPort3lan"
			uci set	dhcp."${Port3lanInterfaceName}".leasetime="12h"
			uci set	dhcp."${Port3lanInterfaceName}".dhcpv6="disabled"
			uci set	dhcp."${Port3lanInterfaceName}".ra="disabled"
        fi
        if [ $EthernetServerStaticDnsServer3 = "1" ]
		then 
			uci add_list network."${Port3lanInterfaceName}".dns="$EthernetServerStaticDnsServer3No1"
		elif [ $EthernetServerStaticDnsServer3 = "2" ]
		then 
			uci add_list network."${Port3lanInterfaceName}".dns="$EthernetServerStaticDnsServer3No1"
			uci add_list network."${Port3lanInterfaceName}".dns="$EthernetServerStaticDnsServer3No2"	
		fi
    elif [ "$Port3Mode" = "EWAN3" ] 
	then
		uci delete network.SW_LAN > /dev/null 2>&1
		uci delete network.swlan > /dev/null 2>&1
		uci delete dhcp."${SwlanInterfaceName}" > /dev/null 2>&1
		uci delete network."${SwlanInterfaceName}" > /dev/null 2>&1
		uci delete dhcp."${Port3lanInterfaceName}" > /dev/null 2>&1
        uci delete network."${Port3lanInterfaceName}" > /dev/null 2>&1  
        uci set network.lan3=switch_vlan
		uci set network.lan3.device="switch0"
		uci set network.lan3.vlan="3"
		uci set network.lan3.ports="2 6t"    	   	
        if [ "$EthernetProtocolPort3wan" = "static" ]
	    then
			uci set network."${Port3WaninterfaceName}"=interface
			uci set network."${Port3WaninterfaceName}".ifname="$Port3LanIfName"
			uci set network."${Port3WaninterfaceName}".proto="static"
			uci set network."${Port3WaninterfaceName}".ipaddr="$EthernetClientStaticIPPort3wan"
			uci set network."${Port3WaninterfaceName}".gateway="$EthernetClientStaticGatewayPort3wan"
			uci set network."${Port3WaninterfaceName}".metric="$Ewan3Priority"
			uci set network."${Port3WaninterfaceName}".netmask="$EthernetClientnetmaskPort3Wan"
			uci set network."${Port3WaninterfaceName}".macaddr="$Port3MacId"
		else
		    uci set network."${Port3WaninterfaceName}"=interface
		    uci set network."${Port3WaninterfaceName}".ifname="$Port3LanIfName"
			uci set network."${Port3WaninterfaceName}".proto="dhcp"
			uci set network."${Port3WaninterfaceName}".gateway="$EthernetClientDHCPGatewayPort3wan"
			uci set network."${Port3WaninterfaceName}".metric="$Ewan3Priority"
			uci set network."${Port3WaninterfaceName}".macaddr="$Port3MacId"
		fi
    else
		uci delete network.lan3 > /dev/null 2>&1
        uci delete dhcp."${Port3lanInterfaceName}" > /dev/null 2>&1
        uci delete network."${Port3lanInterfaceName}" > /dev/null 2>&1
       	uci delete network."${Port3WaninterfaceName}" > /dev/null 2>&1
		port3="2"
		SWNetworkConfig
    fi
    
	if [ "$Port4Mode" = "LAN4" ] 
	then
		uci delete network.SW_LAN > /dev/null 2>&1
		uci delete network.swlan > /dev/null 2>&1
		uci delete network.LAN4 > /dev/null 2>&1
		uci delete dhcp."${SwlanInterfaceName}" > /dev/null 2>&1
		uci delete network."${SwlanInterfaceName}" > /dev/null 2>&1
	    uci delete network."${Port4WaninterfaceName}" > /dev/null 2>&1
	    uci set network.lan4=switch_vlan
		uci set network.lan4.device="switch0"
		uci set network.lan4.vlan="4"
		uci set network.lan4.ports="3 6t"
	   	if [ "$EthernetProtocolPort4lan" = "static" ]
	    then
	        uci delete dhcp."${Port4lanInterfaceName}" > /dev/null 2>&1
			uci set network."${Port4lanInterfaceName}"=interface
			uci set network."${Port4lanInterfaceName}".ifname="$Port4LanIfName"
			uci set network."${Port4lanInterfaceName}".proto="static"
			uci set network."${Port4lanInterfaceName}".ipaddr="$EthernetServerStaticIPPort4lan"
			uci set network."${Port4lanInterfaceName}".netmask="$EthernetServerStaticNetmaskPort4Lan"
			uci set network."${Port4lanInterfaceName}".macaddr="$Port4MacId"
		else
		    uci set network."${Port4lanInterfaceName}"=interface
			uci set network."${Port4lanInterfaceName}".ifname="$Port4LanIfName"
			uci set network."${Port4lanInterfaceName}".proto="static"
			uci set network."${Port4lanInterfaceName}".ipaddr="$EthernetServerDHCPIPPort4lan"
			uci set network."${Port4lanInterfaceName}".netmask="$EthernetServerDHCPNetmaskPort4Lan"
			uci set network."${Port4lanInterfaceName}".macaddr="$Port4MacId"
			uci set dhcp."${Port4lanInterfaceName}"=dhcp
			uci set	dhcp."${Port4lanInterfaceName}".interface="$Port4lanInterfaceName"
			uci set	dhcp."${Port4lanInterfaceName}".start="$EthernetServerDHCPrangePort4lan"
			uci set	dhcp."${Port4lanInterfaceName}".limit="$EthernetServerDHCPlimitPort4lan"
			uci set	dhcp."${Port4lanInterfaceName}".leasetime="12h"
			uci set	dhcp."${Port4lanInterfaceName}".dhcpv6="disabled"
			uci set	dhcp."${Port4lanInterfaceName}".ra="disabled"
        fi
        if [ $EthernetServerStaticDnsServer4 = "1" ]
		then 
			uci add_list network."${Port4lanInterfaceName}".dns="$EthernetServerStaticDnsServer4No1"
		elif [ $EthernetServerStaticDnsServer4 = "2" ]
		then 
			uci add_list network."${Port4lanInterfaceName}".dns="$EthernetServerStaticDnsServer4No1"
			uci add_list network."${Port4lanInterfaceName}".dns="$EthernetServerStaticDnsServer4No2"	
		fi
    elif [ "$Port4Mode" = "EWAN4" ] 
	then
		uci delete network.SW_LAN > /dev/null 2>&1
		uci delete network.swlan > /dev/null 2>&1
		uci delete dhcp."${SwlanInterfaceName}" > /dev/null 2>&1
		uci delete network."${SwlanInterfaceName}" > /dev/null 2>&1
		uci delete dhcp."${Port4lanInterfaceName}" > /dev/null 2>&1
        uci delete network."${Port4lanInterfaceName}" > /dev/null 2>&1  
        uci set network.lan4=switch_vlan
		uci set network.lan4.device="switch0"
		uci set network.lan4.vlan="4"
		uci set network.lan4.ports="3 6t"    	   	
        if [ "$EthernetProtocolPort4wan" = "static" ]
	    then
			uci set network."${Port4WaninterfaceName}"=interface
			uci set network."${Port4WaninterfaceName}".ifname="$Port4LanIfName"
			uci set network."${Port4WaninterfaceName}".proto="static"
			uci set network."${Port4WaninterfaceName}".ipaddr="$EthernetClientStaticIPPort4wan"
			uci set network."${Port4WaninterfaceName}".gateway="$EthernetClientStaticGatewayPort4wan"
			uci set network."${Port4WaninterfaceName}".metric="$Ewan4Priority"
			uci set network."${Port4WaninterfaceName}".netmask="$EthernetClientnetmaskPort4Wan"
			uci set network."${Port4WaninterfaceName}".macaddr="$Port4MacId"
		else
		    uci set network."${Port4WaninterfaceName}"=interface
		    uci set network."${Port4WaninterfaceName}".ifname="$Port4LanIfName"
			uci set network."${Port4WaninterfaceName}".proto="dhcp"
			uci set network."${Port4WaninterfaceName}".gateway="$EthernetClientDHCPGatewayPort4wan"
			uci set network."${Port4WaninterfaceName}".metric="$Ewan4Priority"
			uci set network."${Port4WaninterfaceName}".macaddr="$Port4MacId"
		fi
    else
		uci delete network.lan4 > /dev/null 2>&1
        uci delete dhcp."${Port4lanInterfaceName}" > /dev/null 2>&1
        uci delete network."${Port4lanInterfaceName}" > /dev/null 2>&1
       	uci delete network."${Port4WaninterfaceName}" > /dev/null 2>&1
		port4="3"
    fi
    
	if [ "$Port5Mode" = "LAN5" ] 
	then
		uci delete network.SW_LAN > /dev/null 2>&1
		uci delete network.swlan > /dev/null 2>&1
		uci delete network.LAN5 > /dev/null 2>&1
		uci delete dhcp."${SwlanInterfaceName}" > /dev/null 2>&1
		uci delete network."${SwlanInterfaceName}" > /dev/null 2>&1
	    uci delete network."${Port5WaninterfaceName}" > /dev/null 2>&1
	    uci set network.lan5=switch_vlan
		uci set network.lan5.device="switch0"
		uci set network.lan5.vlan="5"
		uci set network.lan5.ports="4 6t"
	   	if [ "$EthernetProtocolPort5lan" = "static" ]
	    then
	        uci delete dhcp."${Port5lanInterfaceName}" > /dev/null 2>&1
			uci set network."${Port5lanInterfaceName}"=interface
			uci set network."${Port5lanInterfaceName}".ifname="$Port5LanIfName"
			uci set network."${Port5lanInterfaceName}".proto="static"
			uci set network."${Port5lanInterfaceName}".ipaddr="$EthernetServerStaticIPPort5lan"
			uci set network."${Port5lanInterfaceName}".netmask="$EthernetServerStaticNetmaskPort5Lan"
			uci set network."${Port5lanInterfaceName}".macaddr="$Port5MacId"
		else
		    uci set network."${Port5lanInterfaceName}"=interface
			uci set network."${Port5lanInterfaceName}".ifname="$Port5LanIfName"
			uci set network."${Port5lanInterfaceName}".proto="static"
			uci set network."${Port5lanInterfaceName}".ipaddr="$EthernetServerDHCPIPPort5lan"
			uci set network."${Port5lanInterfaceName}".netmask="$EthernetServerDHCPNetmaskPort5Lan"
			uci set network."${Port5lanInterfaceName}".macaddr="$Port5MacId"
			uci set dhcp."${Port5lanInterfaceName}"=dhcp
			uci set	dhcp."${Port5lanInterfaceName}".interface="$Port5lanInterfaceName"
			uci set	dhcp."${Port5lanInterfaceName}".start="$EthernetServerDHCPrangePort5lan"
			uci set	dhcp."${Port5lanInterfaceName}".limit="$EthernetServerDHCPlimitPort5lan"
			uci set	dhcp."${Port5lanInterfaceName}".leasetime="12h"
			uci set	dhcp."${Port5lanInterfaceName}".dhcpv6="disabled"
			uci set	dhcp."${Port5lanInterfaceName}".ra="disabled"
        fi
        if [ $EthernetServerStaticDnsServer5 = "1" ]
		then 
			uci add_list network."${Port5lanInterfaceName}".dns="$EthernetServerStaticDnsServer5No1"
		elif [ $EthernetServerStaticDnsServer5 = "2" ]
		then 
			uci add_list network."${Port5lanInterfaceName}".dns="$EthernetServerStaticDnsServer5No1"
			uci add_list network."${Port5lanInterfaceName}".dns="$EthernetServerStaticDnsServer5No2"	
		fi
    elif [ "$Port5Mode" = "EWAN5" ] 
	then
		uci delete network.SW_LAN > /dev/null 2>&1
		uci delete network.swlan > /dev/null 2>&1
		uci delete dhcp."${SwlanInterfaceName}" > /dev/null 2>&1
		uci delete network."${SwlanInterfaceName}" > /dev/null 2>&1
		uci delete dhcp."${Port5lanInterfaceName}" > /dev/null 2>&1
        uci delete network."${Port5lanInterfaceName}" > /dev/null 2>&1  
        uci delete network.PPTP  > /dev/null 2>&1 
        uci delete network.l2tp  > /dev/null 2>&1  
        uci set network.lan5=switch_vlan
		uci set network.lan5.device="switch0"
		uci set network.lan5.vlan="5"
		uci set network.lan5.ports="4 6t"    	   	
        if [ "$EthernetProtocolPort5wan" = "static" ]
	    then
			uci set network."${Port5WaninterfaceName}"=interface
			uci set network."${Port5WaninterfaceName}".ifname="$Port5LanIfName"
			uci set network."${Port5WaninterfaceName}".proto="static"
			uci set network."${Port5WaninterfaceName}".ipaddr="$EthernetClientStaticIPPort5wan"
			uci set network."${Port5WaninterfaceName}".gateway="$EthernetClientStaticGatewayPort5wan"
			uci set network."${Port5WaninterfaceName}".metric="$Ewan5Priority"
			uci set network."${Port5WaninterfaceName}".netmask="$EthernetClientnetmaskPort5Wan"
			uci set network."${Port5WaninterfaceName}".macaddr="$Port5MacId"
			
		elif [ "$EthernetProtocolPort5wan" = "pppoe" ]                                               
		then
			uci set network."${Port5WaninterfaceName}"=interface                         
            uci set network."${Port5WaninterfaceName}".ifname="$Port5LanIfName"  
			uci set network."${Port5WaninterfaceName}".proto="pppoe"
			uci set network."${Port5WaninterfaceName}".username="$EthernetClientPppoeUsername"
            uci set network."${Port5WaninterfaceName}".password="$EthernetClientPppoePassword"              
            uci set network."${Port5WaninterfaceName}".ac="$EthernetClientPppoeAccessConcentrator"              
            uci set network."${Port5WaninterfaceName}".service="$EthernetClientPppoeServiceName"    
            uci set network."${Port5WaninterfaceName}".macaddr="$Port5MacId"          
                   
		elif [ "$EthernetProtocolPort5wan" = "pptp" ]
		then
			uci set network."${Port5WaninterfaceName}"=interface
		    uci set network."${Port5WaninterfaceName}".ifname="$Port5LanIfName"
			uci set network."${Port5WaninterfaceName}".proto="dhcp"
			uci set network."${Port5WaninterfaceName}".metric="$Ewan5Priority"
			uci set network."${Port5WaninterfaceName}".macaddr="$Port5MacId"
            uci set network.PPTP=interface
            uci set network.PPTP.proto="pptp"
            uci set network.PPTP.ifname="pptp-PPTP"
            uci set network.PPTP.server="$EthernetClientPptpServerAddress"
            uci set network.PPTP.username="$EthernetClientPptpUsername"
            uci set network.PPTP.password="$EthernetClientPptpPassword"
            uci set network.PPTP.require_mppe="$EthernetClientPptpMppeEncryption"
            uci set network.PPTP.mppe_stateless="$EthernetClientPptpMppeEncryption"
            uci set network.PPTP.keepalive="30 60"
            uci set network.PPTP.metric='0'
            uci set network.PPTP.gateway="$EthernetClientDHCPGatewayPort5wan"
			if [ "$EthernetClientPptpDNSServerSource" = "1" ]
			then 
				uci add_list network.PPTP.dns="$EthernetClientPptpDnsServerNo1"
				if [ "$EthernetClientPptpNumberOfDNSServer" = "2" ]
				then
					uci add_list network.PPTP.dns="$EthernetClientPptpDnsServerNo2"
				fi
			fi

		elif [ "$EthernetProtocolPort5wan" = "l2tp" ]
		then
			uci set network."${Port5WaninterfaceName}"=interface
		    uci set network."${Port5WaninterfaceName}".ifname="$Port5LanIfName"
			uci set network."${Port5WaninterfaceName}".proto="dhcp"
			uci set network."${Port5WaninterfaceName}".metric="$Ewan5Priority"
			uci set network."${Port5WaninterfaceName}".macaddr="$Port5MacId"
            
            uci set network.l2tp=interface
            uci set network.l2tp.proto="l2tp"
            uci set network.l2tp.ifname="l2tp-l2tp"
            uci set network.l2tp.server="$EthernetClientPptpServerAddress"
            uci set network.l2tp.username="$EthernetClientPptpUsername"
            uci set network.l2tp.password="$EthernetClientPptpPassword"
            uci set network.l2tp.keepalive="30 60"
            uci set network.l2tp.metric='0'
            uci set network.l2tp.gateway="$EthernetClientDHCPGatewayPort5wan"
			if [ "$EthernetClientPptpDNSServerSource" = "1" ]                                                                             
			then                                                                                                                          
				uci add_list network.l2tp.dns="$EthernetClientPptpDnsServerNo1"                                                       
				if [ "$EthernetClientPptpNumberOfDNSServer" = "2" ]                                                                   
				then                                                                                                                  
					uci add_list network.l2tp.dns="$EthernetClientPptpDnsServerNo2"                                               
				fi                                                                                                                    
			fi   
	
		else
		    uci set network."${Port5WaninterfaceName}"=interface
		    uci set network."${Port5WaninterfaceName}".ifname="$Port5LanIfName"
			uci set network."${Port5WaninterfaceName}".proto="dhcp"
			uci set network."${Port5WaninterfaceName}".gateway="$EthernetClientDHCPGatewayPort5wan"
			uci set network."${Port5WaninterfaceName}".metric="$Ewan5Priority"
			uci set network."${Port5WaninterfaceName}".macaddr="$Port5MacId"
		fi
    else
		uci delete network.lan5 > /dev/null 2>&1
        uci delete dhcp."${Port5lanInterfaceName}" > /dev/null 2>&1
        uci delete network."${Port5lanInterfaceName}" > /dev/null 2>&1
       	uci delete network."${Port5WaninterfaceName}" > /dev/null 2>&1
		port5="4"
    fi
	
	num1=$(echo "$port1 $port2 $port3 $port4 $port5" | sort)
	num=$(echo "$num1" | awk '{print$1}')
	if [ -n "$num" ];then
		num=$((num+1))
		SwlanIfName="eth0.$num"
		SwlanMacId=$(eval echo "\$Port${num}MacId")
		if [ "$EthernetProtocolSwLan" = "static" ]
		then
			uci delete dhcp."${SwlanInterfaceName}" > /dev/null 2>&1
			uci set network."${SwlanInterfaceName}"=interface
			uci set network."${SwlanInterfaceName}".ifname="$SwlanIfName"
			uci set network."${SwlanInterfaceName}".proto="static"
			if [ "$LanWifiBridgeEnable" = "1" ]
			then
			 uci set network."${SwlanInterfaceName}".type="bridge"
			else
			 uci delete network."${SwlanInterfaceName}".type
			fi
			uci set network."${SwlanInterfaceName}".ipaddr="$EthernetServerStaticIPSwLan"
			uci set network."${SwlanInterfaceName}".netmask="$EthernetServerStaticNetmaskSwLan"
			uci set network."${SwlanInterfaceName}".macaddr="$SwlanMacId"
		else
			uci set network."${SwlanInterfaceName}"=interface
			uci set network."${SwlanInterfaceName}".ifname="$SwlanIfName"
			uci set network."${SwlanInterfaceName}".proto="static"
			if [ "$LanWifiBridgeEnable" = "1" ]
			then
			 uci set network."${SwlanInterfaceName}".type="bridge"
			else
			 uci delete network."${SwlanInterfaceName}".type
			fi
			uci set network."${SwlanInterfaceName}".ipaddr="$EthernetServerDHCPIPSwLan"
			uci set network."${SwlanInterfaceName}".netmask="$EthernetServerDHCPNetmaskSwLan"
			uci set network."${SwlanInterfaceName}".macaddr="$SwlanMacId"
			uci set dhcp."${SwlanInterfaceName}"=dhcp
			uci set	dhcp."${SwlanInterfaceName}".interface="$SwlanInterfaceName"
			uci set	dhcp."${SwlanInterfaceName}".start="$EthernetServerDHCPrangeSwLan"
			uci set	dhcp."${SwlanInterfaceName}".limit="$EthernetServerDHCPlimitSwLan"
			uci set	dhcp."${SwlanInterfaceName}".leasetime="12h"
			uci set	dhcp."${SwlanInterfaceName}".dhcpv6="disabled"
			uci set	dhcp."${SwlanInterfaceName}".ra="disabled"
		fi
		
		if [ $EthernetServerStaticDnsServer = "1" ]
		then 
			uci add_list network."${SwlanInterfaceName}".dns="$EthernetServerStaticDnsServerNo1"
		elif [ $EthernetServerStaticDnsServer = "2" ]
		then 
			uci add_list network."${SwlanInterfaceName}".dns="$EthernetServerStaticDnsServerNo1"
			uci add_list network."${SwlanInterfaceName}".dns="$EthernetServerStaticDnsServerNo2"	
		fi
			
		uci set network.swlan=switch_vlan
		uci set network.swlan.device="switch0"
		uci set network.swlan.vlan="$num"
		uci set network.swlan.ports="${port1} ${port2} ${port3} ${port4} ${port5} 6t"
		unset port1
		unset port2
		unset port3
		unset port4
		unset port5
	fi
    uci commit dhcp
    uci commit network	
    ubus call dhcp reload
    ubus call network reload
}

UpdateModemConfig()
{
	if [ "$CellularOperationModelocal" = "dualcellularsinglesim" ]
	then
		uci set modem.cellularmodule.singlesimsinglemodule="0"
		uci set modem.cellularmodule.singlesimdualmodule="1"
		uci set modem.cellularmodule.dualsimsinglemodule="0"
		uci set modem."${cellularwan1interface}".modemenable="1"
		uci set modem."${cellularwan1sim1interface}".modemenable="0"
		uci set modem."${cellularwan1sim2interface}".modemenable="0"
		uci set modem."${cellularwan2interface}".modemenable="1"
		uci set modem."${cellularwan3interface}".modemenable="0"
		#This is set in hotplug script
		#uci set modem."${cellularwan1interface}".manufacturer="$Manufacturerlocal1"
		#uci set modem."${cellularwan1interface}".model="$Model1"
		#uci set modem."${cellularwan1interface}".porttype="$PortType1"
		#uci set modem."${cellularwan1interface}".vendorid="$VendorId1"
		#uci set modem."${cellularwan1interface}".productid="$ProductId1"
		uci set modem."${cellularwan1interface}".device="$DataPort1"
		#uci set modem."${cellularwan1interface}".comport="$ComPort1"
		uci set modem."${cellularwan1interface}".smsport="$SmsPort1"
		uci set modem."${cellularwan1interface}".smsenable="$SmsEnable1"
		uci set modem."${cellularwan1interface}".smsc="$SmsCenterNumber1"
		uci set modem."${cellularwan1interface}".smsdeviceid="$DeviceId1"
		uci set modem."${cellularwan1interface}".smsapikey="$ApiKey1"
		uci set modem."${cellularwan1interface}".monitorenable="1"
		uci set modem."${cellularwan1interface}".actionmanagerenable="$MonitorEnable1"
		uci set modem."${cellularwan1interface}".analyticsmanagerenable="$QueryModematAnalytics1"
		uci set modem."${cellularwan1interface}".statusmanagerenable="$QueryModematAnalytics1"
		uci set modem."${cellularwan1interface}".datatestenable="$DataTestEnable1"
		uci set modem."${cellularwan1interface}".pingtestenable="$PingTestEnable1"
		uci set modem."${cellularwan1interface}".pingip="$PingIp1"
		uci set modem."${cellularwan1interface}".dataenable="$DataEnable1"
		uci set modem."${cellularwan1interface}".service="$Service1"
		uci set modem."${cellularwan1interface}".apn="$Apn1"
		uci set modem."${cellularwan1interface}".pdp="$Pdp1"
		uci set modem."${cellularwan1interface}".username="$UserName1"
		uci set modem."${cellularwan1interface}".password="$Password1"
		uci set modem."${cellularwan1interface}".auth="$Auth1"
		uci set modem."${cellularwan1interface}".metric="$Cwan1Priority"
		#uci set modem."${cellularwan1interface}".usbbuspath="$UsbBusPath1"
		uci set modem."${cellularwan1interface}".action1waitinterval="$ActionInterval1"   
		uci set modem."${cellularwan1interface}".smsresponsesenderenable1="$SmsResponseSenderEnable1"
		uci set modem."${cellularwan1interface}".smsresponseserverenable1="$SmsResponseServerEnable1"
		uci set modem."${cellularwan1interface}".smsservernumber1="$SmsServerNumber1"
		
		#Only if the modems support 5G.
		if [ "$ProductId1" = "0800" ] || [ "$ProductId1" = "0900" ]
		then  
			Settings_5G $autoconfigsim1 $ComPortSymLink1 $networkingmode1 $rattype1 $nsa_bands1 $sa_bands1
		fi

		#uci set modem."${cellularwan2interface}".manufacturer="$Manufacturerlocal2"
		#uci set modem."${cellularwan2interface}".model="$Model2"
		#uci set modem."${cellularwan2interface}".porttype="$PortType2"
		#uci set modem."${cellularwan2interface}".vendorid="$VendorId2"
		#uci set modem."${cellularwan2interface}".productid="$ProductId2"
		uci set modem."${cellularwan2interface}".device="$DataPort2"
		#uci set modem."${cellularwan2interface}".comport="$ComPort2"
		uci set modem."${cellularwan2interface}".smsport="$SmsPort2"
		uci set modem."${cellularwan2interface}".smsenable="$SmsEnable2"
		uci set modem."${cellularwan2interface}".smsc="$SmsCenterNumber2"
		uci set modem."${cellularwan2interface}".smsdeviceid="$DeviceId2"
		uci set modem."${cellularwan2interface}".smsapikey="$ApiKey2"
		uci set modem."${cellularwan2interface}".monitorenable="1"
		uci set modem."${cellularwan2interface}".actionmanagerenable="$MonitorEnable2"
		uci set modem."${cellularwan2interface}".analyticsmanagerenable="$QueryModematAnalytics2"
		uci set modem."${cellularwan2interface}".statusmanagerenable="$QueryModematAnalytics2"
		uci set modem."${cellularwan2interface}".datatestenable="$DataTestEnable2"
		uci set modem."${cellularwan2interface}".pingtestenable="$PingTestEnable2"
		uci set modem."${cellularwan2interface}".pingip="$PingIp2"
		uci set modem."${cellularwan2interface}".dataenable="$DataEnable2"
		uci set modem."${cellularwan2interface}".service="$Sim2Service"
		uci set modem."${cellularwan2interface}".apn="$Sim2Apn"
		uci set modem."${cellularwan2interface}".pdp="$sim2pdp"
		uci set modem."${cellularwan2interface}".username="$sim2username"
		uci set modem."${cellularwan2interface}".password="$sim2password"
		uci set modem."${cellularwan2interface}".auth="$sim2auth"
		uci set modem."${cellularwan2interface}".metric="$Cwan2Priority"
		#uci set modem."${cellularwan2interface}".usbbuspath="$UsbBusPath2"
		uci set modem."${cellularwan2interface}".action1waitinterval="$ActionInterval2"

		uci set modem."${cellularwan2interface}".smsresponsesenderenable="$SmsResponseSenderEnable2"
		uci set modem."${cellularwan2interface}".smsresponseserverenable="$SmsResponseServerEnable2"
		uci set modem."${cellularwan2interface}".smsservernumber2="$SmsServerNumber2"

		#Only if the modems support 5G.
		if [ "$ProductId2" = "0800" ] || [ "$ProductId2" = "0900" ]
		then  
			Settings_5G $autoconfigsim2 $ComPortSymLink2 $networkingmode2 $rattype2 $nsa_bands2 $sa_bands2
		fi
		
	elif [ "$CellularOperationModelocal" = "singlecellulardualsim" ]
    then
		uci set modem.cellularmodule.singlesimsinglemodule="0"
		uci set modem.cellularmodule.singlesimdualmodule="0"
		uci set modem.cellularmodule.dualsimsinglemodule="1"
		uci set modem."${cellularwan1interface}".modemenable="0"
		uci set modem."${cellularwan1sim1interface}".modemenable="1"
		uci set modem."${cellularwan1sim2interface}".modemenable="1"
		uci set modem."${cellularwan1sim1interface}".actionmanagerenable="0"
		uci set modem."${cellularwan1sim2interface}".actionmanagerenable="0"
		uci set modem."${cellularwan2interface}".modemenable="0"
		#uci set modem."${cellularwan1sim1interface}".manufacturer="$Manufacturerlocal1"
		#uci set modem."${cellularwan1sim1interface}".model="$Model1"
		#uci set modem."${cellularwan1sim1interface}".porttype="$PortType1"
		#uci set modem."${cellularwan1sim1interface}".vendorid="$VendorId1"
		#uci set modem."${cellularwan1sim1interface}".productid="$ProductId1"
		uci set modem."${cellularwan1sim1interface}".device="$DataPort1"
		#uci set modem."${cellularwan1sim1interface}".comport="$ComPort1"
		uci set modem."${cellularwan1sim1interface}".smsport="$SmsPort1"
		uci set modem."${cellularwan1sim1interface}".smsenable="$SmsEnable1"
		uci set modem."${cellularwan1sim1interface}".smsc="$SmsCenterNumber1"
		uci set modem."${cellularwan1sim1interface}".smsdeviceid="$DeviceId1"
		uci set modem."${cellularwan1sim1interface}".smsapikey="$ApiKey1"
		uci set modem."${cellularwan1sim1interface}".monitorenable="1"
		uci set modem."${cellularwan1sim1interface}".analyticsmanagerenable="$QueryModematAnalytics1"
		uci set modem."${cellularwan1sim1interface}".statusmanagerenable="$QueryModematAnalytics1"
		uci set modem."${cellularwan1sim1interface}".datatestenable="$DataTestEnable1"
		uci set modem."${cellularwan1sim1interface}".pingtestenable="$PingTestEnable1"
		uci set modem."${cellularwan1sim1interface}".pingip="$PingIp1"
		uci set modem."${cellularwan1sim1interface}".dataenable="$DataEnable1"
		uci set modem."${cellularwan1sim1interface}".service="$Service1"
		uci set modem."${cellularwan1sim1interface}".apn="$Apn1"
		uci set modem."${cellularwan1sim1interface}".pdp="$Pdp1"
		uci set modem."${cellularwan1sim1interface}".username="$UserName1"
		uci set modem."${cellularwan1sim1interface}".password="$Password1"
		uci set modem."${cellularwan1sim1interface}".auth="$Auth1"
		uci set modem."${cellularwan1sim1interface}".metric="$Cwan1sim1Priority"
		#uci set modem."${cellularwan1sim1interface}".usbbuspath="$UsbBusPath1"

		uci set modem."${cellularwan1sim1interface}".smsresponsesenderenable1="$SmsResponseSenderEnable1"
		uci set modem."${cellularwan1sim1interface}".smsresponseserverenable1="$SmsResponseServerEnable1"
		uci set modem."${cellularwan1sim1interface}".smsservernumber1="$SmsServerNumber1"

		#uci set modem."${cellularwan1sim2interface}".manufacturer="$Manufacturerlocal1"
		#uci set modem."${cellularwan1sim2interface}".model="$Model1"
		#uci set modem."${cellularwan1sim2interface}".porttype="$PortType1"
		#uci set modem."${cellularwan1sim2interface}".vendorid="$VendorId1"
		#uci set modem."${cellularwan1sim2interface}".productid="$ProductId1"
		uci set modem."${cellularwan1sim2interface}".device="$DataPort1"
		#uci set modem."${cellularwan1sim2interface}".comport="$ComPort1"
		uci set modem."${cellularwan1sim2interface}".smsport="$SmsPort1"
		uci set modem."${cellularwan1sim2interface}".smsenable="$SmsEnable1"
		uci set modem."${cellularwan1sim2interface}".smsc="$SmsCenterNumber1"
		uci set modem."${cellularwan1sim2interface}".smsdeviceid="$DeviceId1"
		uci set modem."${cellularwan1sim2interface}".smsapikey="$ApiKey1"
		uci set modem."${cellularwan1sim2interface}".monitorenable="1"
		uci set modem."${cellularwan1sim2interface}".analyticsmanagerenable="$QueryModematAnalytics1"
		uci set modem."${cellularwan1sim2interface}".statusmanagerenable="$QueryModematAnalytics1"
		uci set modem."${cellularwan1sim2interface}".datatestenable="$DataTestEnable1"
		uci set modem."${cellularwan1sim2interface}".pingtestenable="$PingTestEnable1"
		uci set modem."${cellularwan1sim2interface}".pingip="$PingIp1"
		uci set modem."${cellularwan1sim2interface}".dataenable="$DataEnable1"
		uci set modem."${cellularwan1sim2interface}".service="$Sim2Service"
		uci set modem."${cellularwan1sim2interface}".apn="$Sim2Apn"
		uci set modem."${cellularwan1sim2interface}".pdp="$sim2pdp"
		uci set modem."${cellularwan1sim2interface}".username="$sim2username"
		uci set modem."${cellularwan1sim2interface}".password="$sim2password"
		uci set modem."${cellularwan1sim2interface}".auth="$sim2auth"
		uci set modem."${cellularwan1sim2interface}".metric="$Cwan1sim2Priority"
		#uci set modem."${cellularwan1sim2interface}".usbbuspath="$UsbBusPath1"

		uci set modem."${cellularwan1sim2interface}".smsresponsesenderenable1="$SmsResponseSenderEnable1"
		uci set modem."${cellularwan1sim2interface}".smsresponseserverenable1="$SmsResponseServerEnable1"
		uci set modem."${cellularwan1sim2interface}".smsservernumber1="$SmsServerNumber1"

		#Only if the modems support 5G.
		if [ "$ProductId1" = "0800" ] || [ "$ProductId1" = "0900" ]
		then  
			Settings_5G $autoconfigsim1 $ComPortSymLink1 $networkingmode1 $rattype1 $nsa_bands1 $sa_bands1
		fi
		
	else
		uci set modem.cellularmodule.singlesimsinglemodule="1"
		uci set modem.cellularmodule.singlesimdualmodule="0"
		uci set modem.cellularmodule.dualsimsinglemodule="0"
		uci set modem."${cellularwan1interface}".modemenable="1"
		uci set modem."${cellularwan1sim1interface}".modemenable="0"
		uci set modem."${cellularwan1sim2interface}".modemenable="0"
		uci set modem."${cellularwan2interface}".modemenable="0"
		#uci set modem."${cellularwan1interface}".manufacturer="$Manufacturerlocal1"
		#uci set modem."${cellularwan1interface}".model="$Model1"
		#uci set modem."${cellularwan1interface}".porttype="$PortType1"
		#uci set modem."${cellularwan1interface}".vendorid="$VendorId1"
		#uci set modem."${cellularwan1interface}".productid="$ProductId1"
		uci set modem."${cellularwan1interface}".device="$DataPort1"
		#uci set modem."${cellularwan1interface}".comport="$ComPort1"
		uci set modem."${cellularwan1interface}".smsport="$SmsPort1"
		uci set modem."${cellularwan1interface}".smsenable="$SmsEnable1"
		uci set modem."${cellularwan1interface}".smsc="$SmsCenterNumber1"
		uci set modem."${cellularwan1interface}".smsdeviceid="$DeviceId1"
		uci set modem."${cellularwan1interface}".smsapikey="$ApiKey1"
		uci set modem."${cellularwan1interface}".monitorenable="1"
		uci set modem."${cellularwan1interface}".actionmanagerenable="$MonitorEnable1"
		uci set modem."${cellularwan1interface}".analyticsmanagerenable="$QueryModematAnalytics1"
		uci set modem."${cellularwan1interface}".statusmanagerenable="$QueryModematAnalytics1"
		uci set modem."${cellularwan1interface}".datatestenable="$DataTestEnable1"
		uci set modem."${cellularwan1interface}".pingtestenable="$PingTestEnable1"
		uci set modem."${cellularwan1interface}".pingip="$PingIp1"
		uci set modem."${cellularwan1interface}".dataenable="$DataEnable1"
		uci set modem."${cellularwan1interface}".service="$Service1"
		uci set modem."${cellularwan1interface}".apn="$Apn1"
		uci set modem."${cellularwan1interface}".pdp="$Pdp1"
		uci set modem."${cellularwan1interface}".username="$UserName1"
		uci set modem."${cellularwan1interface}".password="$Password1"
		uci set modem."${cellularwan1interface}".auth="$Auth1"
		uci set modem."${cellularwan1interface}".metric="$Cwan1Priority"
		#uci set modem."${cellularwan1interface}".usbbuspath="$UsbBusPath1"
		uci set modem."${cellularwan1interface}".action1waitinterval="$ActionInterval1"   

		uci set modem."${cellularwan1interface}".smsresponsesenderenable1="$SmsResponseSenderEnable1"
		uci set modem."${cellularwan1interface}".smsresponseserverenable1="$SmsResponseServerEnable1"
		uci set modem."${cellularwan1interface}".smsservernumber1="$SmsServerNumber1"
		
		#Only if the modems support 5G.
		if [ "$ProductId1" = "0800" ] || [ "$ProductId1" = "0900" ]
		then  
			Settings_5G $autoconfigsim1 $ComPortSymLink1 $networkingmode1 $rattype1 $nsa_bands1 $sa_bands1
		fi
		
	fi
	
	uci commit modem
	ubus call modem reload
}

UpdateFirewallConfig()
{
	if [ "$wifi1enable" = "0" ]
	then 
	   uci delete firewall.wifi > /dev/null 2>&1
	   uci delete firewall.wifi5 > /dev/null 2>&1
	else
		#2.4GHZ
		uci set firewall.wifi=zone
		uci set firewall.wifi.name="$wifiinterface"
		uci set firewall.wifi.input="ACCEPT"
		uci set firewall.wifi.output="ACCEPT"
		uci set firewall.wifi.forward="ACCEPT"
		uci set firewall.wifi.network=ra0
		uci set firewall.wifi.masq="1"
		uci set firewall.wifi.mtu_fix="1"
		
		#5GHZ
		uci set firewall.wifi5=zone
		uci set firewall.wifi5.name="$wifi5interface"
		uci set firewall.wifi5.input="ACCEPT"
		uci set firewall.wifi5.output="ACCEPT"
		uci set firewall.wifi5.forward="ACCEPT"
		uci set firewall.wifi5.network=rai0
		uci set firewall.wifi5.masq="1"
		uci set firewall.wifi5.mtu_fix="1"	
	fi

    if [ "$Port1Mode" = "LAN1" ]
	then
		uci set firewall.lan1=zone
		uci set firewall.lan1.name="$Port1lanInterfaceName"
		uci set firewall.lan1.input="ACCEPT"
		uci set firewall.lan1.output="ACCEPT"
		uci set firewall.lan1.forward="ACCEPT"
		uci set firewall.lan1.network="$Port1lanInterfaceName"
		uci set firewall.lan1.masq="1"
		uci set firewall.lan1.mtu_fix="1"
		#uci set firewall.lan1.extra_src="-m policy --dir in --pol none"
		#uci set firewall.lan1.extra_dest="-m policy --dir out --pol none"
	elif [ "$Port1Mode" = "EWAN1" ]
	then
		uci delete firewall.lan1wifi > /dev/null 2>&1
		uci delete firewall.lan1ewan1 > /dev/null 2>&1
		uci delete firewall.lan1ewan2 > /dev/null 2>&1
		uci delete firewall.lan1ewan3 > /dev/null 2>&1
		uci delete firewall.lan1ewan4 > /dev/null 2>&1
		uci delete firewall.lan1ewan5 > /dev/null 2>&1
		uci delete firewall.lan1cwan1 > /dev/null 2>&1
		uci delete firewall.lan1cwan1_0 > /dev/null 2>&1
		uci delete firewall.lan1cwan1_1 > /dev/null 2>&1
		uci delete firewall.lan1cwan2 > /dev/null 2>&1
		uci delete firewall.lan1 > /dev/null 2>&1
		uci set firewall.ewan1=zone
		uci set firewall.ewan1.name="$Port1WaninterfaceName"
		uci set firewall.ewan1.input="ACCEPT"
		uci set firewall.ewan1.output="ACCEPT"
		uci set firewall.ewan1.forward="ACCEPT"
		uci set firewall.ewan1.network="$Port1WaninterfaceName"
		uci set firewall.ewan1.masq="1"
		uci set firewall.ewan1.mtu_fix="1"
		#uci set firewall.ewan1.extra_src="-m policy --dir in --pol none"
		#uci set firewall.ewan1.extra_dest="-m policy --dir out --pol none"

		if [ "$InternetoverSwLan" = "1" ]
		then
			uci set firewall.swlanewan1=forwarding
			uci set firewall.swlanewan1.src="$SwlanInterfaceName"
			uci set firewall.swlanewan1.dest="$Port1WaninterfaceName"
		fi

		if [ "$Port2InternetOverLan" = "1" ] && [ "$Port2Mode" = "LAN2" ]
		then 
			uci set firewall.lan2ewan1=forwarding
			uci set firewall.lan2ewan1.src="$Port2lanInterfaceName"
			uci set firewall.lan2ewan1.dest="$Port1WaninterfaceName"
		fi
		if [ "$Port3InternetOverLan" = "1" ] && [ "$Port3Mode" = "LAN3" ]
		then 
			uci set firewall.lan3ewan1=forwarding
			uci set firewall.lan3ewan1.src="$Port3lanInterfaceName"
			uci set firewall.lan3ewan1.dest="$Port1WaninterfaceName"
		fi
		if [ "$Port4InternetOverLan" = "1" ] && [ "$Port4Mode" = "LAN4" ]
		then 
			uci set firewall.lan4ewan1=forwarding
			uci set firewall.lan4ewan1.src="$Port4lanInterfaceName"
			uci set firewall.lan4ewan1.dest="$Port1WaninterfaceName"
		fi
		if [ "$Port5InternetOverLan" = "1" ] && [ "$Port5Mode" = "LAN5" ]
		then 
			uci set firewall.lan5ewan1=forwarding
			uci set firewall.lan5ewan1.src="$Port5lanInterfaceName"
			uci set firewall.lan5ewan1.dest="$Port1WaninterfaceName"
		fi
		if [ "$InternetOverWifi" = "1" ]
	    then
			if [ "$wifi1enable" = "1" ]
			then
				uci set firewall.wifiewan1=forwarding
				uci set firewall.wifiewan1.src="$wifiinterface"
				uci set firewall.wifiewan1.dest="$Port1WaninterfaceName"
				
				uci set firewall.wifie5wan1=forwarding
				uci set firewall.wifie5wan1.src="$wifi5interface"
				uci set firewall.wifie5wan1.dest="$Port1WaninterfaceName"
			fi 
		fi 
    fi

    if [ "$Port2Mode" = "LAN2" ]
	then
		uci set firewall.lan2=zone
		uci set firewall.lan2.name="$Port2lanInterfaceName"
		uci set firewall.lan2.input="ACCEPT"
		uci set firewall.lan2.output="ACCEPT"
		uci set firewall.lan2.forward="ACCEPT"
		uci set firewall.lan2.network="$Port2lanInterfaceName"
		uci set firewall.lan2.masq="1"
		uci set firewall.lan2.mtu_fix="1"
		#uci set firewall.lan2.extra_src="-m policy --dir in --pol none"
		#uci set firewall.lan2.extra_dest="-m policy --dir out --pol none"
	elif [ "$Port2Mode" = "EWAN2" ]
	then
		uci delete firewall.lan2wifi > /dev/null 2>&1
		uci delete firewall.lan2ewan1 > /dev/null 2>&1
		uci delete firewall.lan2ewan2 > /dev/null 2>&1
		uci delete firewall.lan2ewan3 > /dev/null 2>&1
		uci delete firewall.lan2ewan4 > /dev/null 2>&1
		uci delete firewall.lan2ewan5 > /dev/null 2>&1
		uci delete firewall.lan2cwan1 > /dev/null 2>&1
		uci delete firewall.lan2cwan1_0 > /dev/null 2>&1
		uci delete firewall.lan2cwan1_1 > /dev/null 2>&1
		uci delete firewall.lan2cwan2 > /dev/null 2>&1
		uci delete firewall.lan2 > /dev/null 2>&1
		uci set firewall.ewan2=zone
		uci set firewall.ewan2.name="$Port2WaninterfaceName"
		uci set firewall.ewan2.input="ACCEPT"
		uci set firewall.ewan2.output="ACCEPT"
		uci set firewall.ewan2.forward="ACCEPT"
		uci set firewall.ewan2.network="$Port2WaninterfaceName"
		uci set firewall.ewan2.masq="1"
		uci set firewall.ewan2.mtu_fix="1"
		#uci set firewall.ewan2.extra_src="-m policy --dir in --pol none"
		#uci set firewall.ewan2.extra_dest="-m policy --dir out --pol none"
		if [ "$InternetoverSwLan" = "1" ]
		then
			uci set firewall.swlanewan2=forwarding
			uci set firewall.swlanewan2.src="$SwlanInterfaceName"
			uci set firewall.swlanewan2.dest="$Port2WaninterfaceName"
		fi
		if [ "$Port1InternetOverLan" = "1" ] && [ "$Port1Mode" = "LAN1" ]
		then 
			uci set firewall.lan1ewan2=forwarding
			uci set firewall.lan1ewan2.src="$Port1lanInterfaceName"
			uci set firewall.lan1ewan2.dest="$Port2WaninterfaceName"
		fi
		if [ "$Port3InternetOverLan" = "1" ] && [ "$Port3Mode" = "LAN3" ]
		then 
			uci set firewall.lan3ewan2=forwarding
			uci set firewall.lan3ewan2.src="$Port3lanInterfaceName"
			uci set firewall.lan3ewan2.dest="$Port2WaninterfaceName"
		fi
		if [ "$Port4InternetOverLan" = "1" ] && [ "$Port4Mode" = "LAN4" ]
		then 
			uci set firewall.lan4ewan2=forwarding
			uci set firewall.lan4ewan2.src="$Port4lanInterfaceName"
			uci set firewall.lan4ewan2.dest="$Port2WaninterfaceName"
		fi
		if [ "$Port5InternetOverLan" = "1" ] && [ "$Port5Mode" = "LAN5" ]
		then 
			uci set firewall.lan5ewan2=forwarding
			uci set firewall.lan5ewan2.src="$Port5lanInterfaceName"
			uci set firewall.lan5ewan2.dest="$Port2WaninterfaceName"
		fi
		if [ "$InternetOverWifi" = "1" ]
	    then
			if [ "$wifi1enable" = "1" ]
			then
				uci set firewall.wifiewan2=forwarding
				uci set firewall.wifiewan2.src="$wifiinterface"
				uci set firewall.wifiewan2.dest="$Port2WaninterfaceName"
				
				uci set firewall.wifi5ewan2=forwarding
				uci set firewall.wifi5ewan2.src="$wifi5interface"
				uci set firewall.wifi5ewan2.dest="$Port2WaninterfaceName"
			fi 
		fi 
    fi

    if [ "$Port3Mode" = "LAN3" ]
	then
		uci set firewall.lan3=zone
		uci set firewall.lan3.name="$Port3lanInterfaceName"
		uci set firewall.lan3.input="ACCEPT"
		uci set firewall.lan3.output="ACCEPT"
		uci set firewall.lan3.forward="ACCEPT"
		uci set firewall.lan3.network="$Port3lanInterfaceName"
		uci set firewall.lan3.masq="1"
		uci set firewall.lan3.mtu_fix="1"
		#uci set firewall.lan3.extra_src="-m policy --dir in --pol none"
		#uci set firewall.lan3.extra_dest="-m policy --dir out --pol none"
	elif [ "$Port3Mode" = "EWAN3" ]
	then
		uci delete firewall.lan3wifi > /dev/null 2>&1
		uci delete firewall.lan3ewan1 > /dev/null 2>&1
		uci delete firewall.lan3ewan2 > /dev/null 2>&1
		uci delete firewall.lan3ewan3 > /dev/null 2>&1
		uci delete firewall.lan3ewan4 > /dev/null 2>&1
		uci delete firewall.lan3ewan5 > /dev/null 2>&1
		uci delete firewall.lan3cwan1 > /dev/null 2>&1
		uci delete firewall.lan3cwan1_0 > /dev/null 2>&1
		uci delete firewall.lan3cwan1_1 > /dev/null 2>&1
		uci delete firewall.lan3cwan2 > /dev/null 2>&1
		uci delete firewall.lan3 > /dev/null 2>&1
		uci set firewall.ewan3=zone
		uci set firewall.ewan3.name="$Port3WaninterfaceName"
		uci set firewall.ewan3.input="ACCEPT"
		uci set firewall.ewan3.output="ACCEPT"
		uci set firewall.ewan3.forward="ACCEPT"
		uci set firewall.ewan3.network="$Port3WaninterfaceName"
		uci set firewall.ewan3.masq="1"
		uci set firewall.ewan3.mtu_fix="1"
		#uci set firewall.ewan3.extra_src="-m policy --dir in --pol none"
		#uci set firewall.ewan3.extra_dest="-m policy --dir out --pol none"
		if [ "$InternetoverSwLan" = "1" ]
		then
			uci set firewall.swlanewan3=forwarding
			uci set firewall.swlanewan3.src="$SwlanInterfaceName"
			uci set firewall.swlanewan3.dest="$Port3WaninterfaceName"
		fi
		if [ "$Port1InternetOverLan" = "1" ] && [ "$Port1Mode" = "LAN1" ]
		then 
			uci set firewall.lan1ewan3=forwarding
			uci set firewall.lan1ewan3.src="$Port1lanInterfaceName"
			uci set firewall.lan1ewan3.dest="$Port3WaninterfaceName"
		fi
		if [ "$Port2InternetOverLan" = "1" ] && [ "$Port2Mode" = "LAN2" ]
		then 
			uci set firewall.lan2ewan3=forwarding
			uci set firewall.lan2ewan3.src="$Port2lanInterfaceName"
			uci set firewall.lan2ewan3.dest="$Port3WaninterfaceName"
		fi
		if [ "$Port4InternetOverLan" = "1" ] && [ "$Port4Mode" = "LAN4" ]
		then 
			uci set firewall.lan4ewan3=forwarding
			uci set firewall.lan4ewan3.src="$Port4lanInterfaceName"
			uci set firewall.lan4ewan3.dest="$Port3WaninterfaceName"
		fi
		if [ "$Port5InternetOverLan" = "1" ] && [ "$Port5Mode" = "LAN5" ]
		then 
			uci set firewall.lan5ewan3=forwarding
			uci set firewall.lan5ewan3.src="$Port5lanInterfaceName"
			uci set firewall.lan5ewan3.dest="$Port3WaninterfaceName"
		fi
		if [ "$InternetOverWifi" = "1" ]
	    then
			if [ "$wifi1enable" = "1" ]
			then
				uci set firewall.wifiewan3=forwarding
				uci set firewall.wifiewan3.src="$wifiinterface"
				uci set firewall.wifiewan3.dest="$Port3WaninterfaceName"
				uci set firewall.wifi5ewan3=forwarding
				uci set firewall.wifi5ewan3.src="$wifi5interface"
				uci set firewall.wifi5ewan3.dest="$Port3WaninterfaceName"
			fi 
		fi 
    fi

    if [ "$Port4Mode" = "LAN4" ]
	then
		uci set firewall.lan4=zone
		uci set firewall.lan4.name="$Port4lanInterfaceName"
		uci set firewall.lan4.input="ACCEPT"
		uci set firewall.lan4.output="ACCEPT"
		uci set firewall.lan4.forward="ACCEPT"
		uci set firewall.lan4.network="$Port4lanInterfaceName"
		uci set firewall.lan4.masq="1"
		uci set firewall.lan4.mtu_fix="1"
		#uci set firewall.lan4.extra_src="-m policy --dir in --pol none"
		#uci set firewall.lan4.extra_dest="-m policy --dir out --pol none"
	elif [ "$Port4Mode" = "EWAN4" ]
	then
		uci delete firewall.lan4wifi > /dev/null 2>&1
		uci delete firewall.lan4ewan1 > /dev/null 2>&1
		uci delete firewall.lan4ewan2 > /dev/null 2>&1
		uci delete firewall.lan4ewan3 > /dev/null 2>&1
		uci delete firewall.lan4ewan4 > /dev/null 2>&1
		uci delete firewall.lan4ewan5 > /dev/null 2>&1
		uci delete firewall.lan4cwan1 > /dev/null 2>&1
		uci delete firewall.lan4cwan1_0 > /dev/null 2>&1
		uci delete firewall.lan4cwan1_1 > /dev/null 2>&1
		uci delete firewall.lan4cwan2 > /dev/null 2>&1
		uci delete firewall.lan4 > /dev/null 2>&1
		uci set firewall.ewan4=zone
		uci set firewall.ewan4.name="$Port4WaninterfaceName"
		uci set firewall.ewan4.input="ACCEPT"
		uci set firewall.ewan4.output="ACCEPT"
		uci set firewall.ewan4.forward="ACCEPT"
		uci set firewall.ewan4.network="$Port4WaninterfaceName"
		uci set firewall.ewan4.masq="1"
		uci set firewall.ewan4.mtu_fix="1"
		#uci set firewall.ewan4.extra_src="-m policy --dir in --pol none"
		#uci set firewall.ewan4.extra_dest="-m policy --dir out --pol none"
		if [ "$InternetoverSwLan" = "1" ]
		then
			uci set firewall.swlanewan4=forwarding
			uci set firewall.swlanewan4.src="$SwlanInterfaceName"
			uci set firewall.swlanewan4.dest="$Port4WaninterfaceName"
		fi
		if [ "$Port1InternetOverLan" = "1" ] && [ "$Port1Mode" = "LAN1" ]
		then 
			uci set firewall.lan1ewan4=forwarding
			uci set firewall.lan1ewan4.src="$Port1lanInterfaceName"
			uci set firewall.lan1ewan4.dest="$Port4WaninterfaceName"
		fi
		if [ "$Port2InternetOverLan" = "1" ] && [ "$Port2Mode" = "LAN2" ]
		then 
			uci set firewall.lan2ewan4=forwarding
			uci set firewall.lan2ewan4.src="$Port2lanInterfaceName"
			uci set firewall.lan2ewan4.dest="$Port4WaninterfaceName"
		fi
		if [ "$Port3InternetOverLan" = "1" ] && [ "$Port3Mode" = "LAN3" ]
		then 
			uci set firewall.lan3ewan4=forwarding
			uci set firewall.lan3ewan4.src="$Port3lanInterfaceName"
			uci set firewall.lan3ewan4.dest="$Port4WaninterfaceName"
		fi
		if [ "$Port5InternetOverLan" = "1" ] && [ "$Port5Mode" = "LAN5" ]
		then 
			uci set firewall.lan5ewan4=forwarding
			uci set firewall.lan5ewan4.src="$Port5lanInterfaceName"
			uci set firewall.lan5ewan4.dest="$Port4WaninterfaceName"
		fi
		if [ "$InternetOverWifi" = "1" ]
	    then
			if [ "$wifi1enable" = "1" ]
			then
				uci set firewall.wifiewan4=forwarding
				uci set firewall.wifiewan4.src="$wifiinterface"
				uci set firewall.wifiewan4.dest="$Port4WaninterfaceName"
				uci set firewall.wifi5ewan4=forwarding
				uci set firewall.wifi5ewan4.src="$wifi5interface"
				uci set firewall.wifi5ewan4.dest="$Port4WaninterfaceName"
			fi 
		fi 
    fi

	if [ "$Port5Mode" = "LAN5" ]
	then
		uci set firewall.lan5=zone
		uci set firewall.lan5.name="$Port5lanInterfaceName"
		uci set firewall.lan5.input="ACCEPT"
		uci set firewall.lan5.output="ACCEPT"
		uci set firewall.lan5.forward="ACCEPT"
		uci set firewall.lan5.network="$Port5lanInterfaceName"
		uci set firewall.lan5.masq="1"
		uci set firewall.lan5.mtu_fix="1"
		#uci set firewall.lan5.extra_src="-m policy --dir in --pol none"
		#uci set firewall.lan5.extra_dest="-m policy --dir out --pol none"
	elif [ "$Port5Mode" = "EWAN5" ]
	then
		uci delete firewall.lan5wifi > /dev/null 2>&1
		uci delete firewall.lan5ewan1 > /dev/null 2>&1
		uci delete firewall.lan5ewan2 > /dev/null 2>&1
		uci delete firewall.lan5ewan3 > /dev/null 2>&1
		uci delete firewall.lan5ewan4 > /dev/null 2>&1
		uci delete firewall.lan5ewan5 > /dev/null 2>&1
		uci delete firewall.lan5cwan1 > /dev/null 2>&1
		uci delete firewall.lan5cwan1_0 > /dev/null 2>&1
		uci delete firewall.lan5cwan1_1 > /dev/null 2>&1
		uci delete firewall.lan5cwan2 > /dev/null 2>&1
		uci delete firewall.lan5 > /dev/null 2>&1
		uci set firewall.ewan5=zone
		uci set firewall.ewan5.name="$Port5WaninterfaceName"
		uci set firewall.ewan5.input="ACCEPT"
		uci set firewall.ewan5.output="ACCEPT"
		uci set firewall.ewan5.forward="ACCEPT"
		uci set firewall.ewan5.network="$Port5WaninterfaceName"
		uci set firewall.ewan5.masq="1"
		uci set firewall.ewan5.mtu_fix="1"
		#uci set firewall.ewan5.extra_src="-m policy --dir in --pol none"
		#uci set firewall.ewan5.extra_dest="-m policy --dir out --pol none"

		if [ "$EthernetProtocolPort5wan" = "pptp" ]
		then 
			uci set firewall.pptp=zone
			uci set firewall.pptp.name="PPTP"
			uci set firewall.pptp.input="ACCEPT"
			uci set firewall.pptp.output="ACCEPT"
			uci set firewall.pptp.mtu_fix="1"
			uci set firewall.pptp.forward="ACCEPT"
			uci set firewall.pptp.network="PPTP"
			uci set firewall.pptp.masq="1"
			uci set firewall.pptp.extra_src '-m policy --dir in --pol ipsec --proto esp'
			uci set firewall.pptp.extra_dest '-m policy --dir out --pol ipsec --proto esp'

			uci set firewall.pptpcwan1_0=forwarding
			uci set firewall.pptpcwan1_0.src="PPTP"
			uci set firewall.pptpcwan1_0.dest="CWAN1_0"

			uci set firewall.cwan1_0pptp=forwarding
			uci set firewall.cwan1_0pptp.src="CWAN1_0"
			uci set firewall.cwan1_0pptp.dest="PPTP"

			uci set firewall.pptpewan5=forwarding
			uci set firewall.pptpewan5.src="PPTP"
			uci set firewall.pptpewan5.dest="EWAN5"

			uci set firewall.ewan5pptp=forwarding
			uci set firewall.ewan5pptp.src="EWAN5"
			uci set firewall.ewan5pptp.dest="PPTP"

			uci set firewall.pptpcwan1_1=forwarding
			uci set firewall.pptpcwan1_1.src="PPTP"
			uci set firewall.pptpcwan1_1.dest="CWAN1_1"

			uci set firewall.cwan1_1pptp=forwarding
			uci set firewall.cwan1_1pptp.src="CWAN1_1"
			uci set firewall.cwan1_1pptp.dest="PPTP"

			if [ "$InternetoverSwLan" = "1" ]
			then
				uci set firewall.swlanpptp=forwarding
				uci set firewall.swlanpptp.src="$SwlanInterfaceName"
				uci set firewall.swlanpptp.dest="PPTP"

				uci set firewall.pptpswlan=forwarding
				uci set firewall.pptpswlan.src="PPTP"
				uci set firewall.pptpswlan.dest="$SwlanInterfaceName"
			fi
			if [ "$Port1InternetOverLan" = "1" ] && [ "$Port1Mode" = "LAN1" ]
			then 
				uci set firewall.lan1pptp=forwarding
				uci set firewall.lan1pptp.src="$Port1lanInterfaceName"
				uci set firewall.lan1pptp.dest="PPTP"

				uci set firewall.pptplan1=forwarding
				uci set firewall.pptplan1.src="PPTP"
				uci set firewall.pptplan1.dest="$Port1lanInterfaceName"
			fi
			if [ "$Port2InternetOverLan" = "1" ] && [ "$Port2Mode" = "LAN2" ]
			then 
				uci set firewall.lan2pptp=forwarding
				uci set firewall.lan2pptp.src="$Port2lanInterfaceName"
				uci set firewall.lan2pptp.dest="PPTP"

				uci set firewall.pptplan2=forwarding
				uci set firewall.pptplan2.src="PPTP"
				uci set firewall.pptplan2.dest="$Port2lanInterfaceName"
			fi
			if [ "$Port3InternetOverLan" = "1" ] && [ "$Port3Mode" = "LAN3" ]
			then 
				uci set firewall.lan3pptp=forwarding
				uci set firewall.lan3pptp.src="$Port3lanInterfaceName"
				uci set firewall.lan3pptp.dest="PPTP"

				uci set firewall.pptplan3=forwarding
				uci set firewall.pptplan3.src="PPTP"
				uci set firewall.pptplan3.dest="$Port3lanInterfaceName"
			fi
			if [ "$Port4InternetOverLan" = "1" ] && [ "$Port4Mode" = "LAN4" ]
				then 
				uci set firewall.lan4pptp=forwarding
				uci set firewall.lan4pptp.src="$Port4lanInterfaceName"
				uci set firewall.lan4pptp.dest="PPTP"

				uci set firewall.pptplan4=forwarding
				uci set firewall.pptplan4.src="PPTP"
				uci set firewall.pptplan4.dest="$Port4lanInterfaceName"
			fi
			if [ "$InternetOverWifi" = "1" ]
			then
				if [ "$wifi1enable" = "1" ]
				then
					uci set firewall.wifipptp=forwarding
					uci set firewall.wifipptp.src="$wifiinterface"
					uci set firewall.wifipptp.dest="PPTP"
					
					uci set firewall.wifi5pptp=forwarding
					uci set firewall.wifi5pptp.src="$wifi5interface"
					uci set firewall.wifi5pptp.dest="PPTP"
				fi 
			fi  
		fi

		if [ "$EthernetProtocolPort5wan" = "l2tp" ]
		then 
			uci set firewall.l2tp=zone
			uci set firewall.l2tp.name="l2tp"
			uci set firewall.l2tp.input="ACCEPT"
			uci set firewall.l2tp.output="ACCEPT"
			uci set firewall.l2tp.mtu_fix="1"
			uci set firewall.l2tp.forward="ACCEPT"
			uci set firewall.l2tp.network="l2tp"
			uci set firewall.l2tp.masq="1"
			uci set firewall.l2tp.extra_src '-m policy --dir in --pol ipsec --proto esp'
			uci set firewall.l2tp.extra_dest '-m policy --dir out --pol ipsec --proto esp'

			uci set firewall.l2tpcwan1_0=forwarding
			uci set firewall.l2tpcwan1_0.src="l2tp"
			uci set firewall.l2tpcwan1_0.dest="CWAN1_0"

			uci set firewall.cwan1_0l2tp=forwarding
			uci set firewall.cwan1_0l2tp.src="CWAN1_0"
			uci set firewall.cwan1_0l2tp.dest="l2tp"

			uci set firewall.l2tpewan5=forwarding
			uci set firewall.l2tpewan5.src="l2tp"
			uci set firewall.l2tpewan5.dest="EWAN5"

			uci set firewall.ewan5l2tp=forwarding
			uci set firewall.ewan5l2tp.src="EWAN5"
			uci set firewall.ewan5l2tp.dest="l2tp"

			uci set firewall.l2tpcwan1_1=forwarding
			uci set firewall.l2tpcwan1_1.src="l2tp"
			uci set firewall.l2tpcwan1_1.dest="CWAN1_1"

			uci set firewall.cwan1_1l2tp=forwarding
			uci set firewall.cwan1_1l2tp.src="CWAN1_1"
			uci set firewall.cwan1_1l2tp.dest="l2tp"

			if [ "$InternetoverSwLan" = "1" ]
			then
				uci set firewall.swlanl2tp=forwarding
				uci set firewall.swlanl2tp.src="$SwlanInterfaceName"
				uci set firewall.swlanl2tp.dest="l2tp"

				uci set firewall.l2tpswlan=forwarding
				uci set firewall.l2tpswlan.src="l2tp"
				uci set firewall.l2tpswlan.dest="$SwlanInterfaceName"
			fi
			if [ "$Port1InternetOverLan" = "1" ] && [ "$Port1Mode" = "LAN1" ]
			then 
				uci set firewall.lan1l2tp=forwarding
				uci set firewall.lan1l2tp.src="$Port1lanInterfaceName"
				uci set firewall.lan1l2tp.dest="l2tp"

				uci set firewall.l2tplan1=forwarding
				uci set firewall.l2tplan1.src="l2tp"
				uci set firewall.l2tplan1.dest="$Port1lanInterfaceName"
			fi
			if [ "$Port2InternetOverLan" = "1" ] && [ "$Port2Mode" = "LAN2" ]
			then 
				uci set firewall.lan2l2tp=forwarding
				uci set firewall.lan2l2tp.src="$Port2lanInterfaceName"
				uci set firewall.lan2l2tp.dest="l2tp"

				uci set firewall.l2tplan2=forwarding
				uci set firewall.l2tplan2.src="l2tp"
				uci set firewall.l2tplan2.dest="$Port2lanInterfaceName"
			fi
			if [ "$Port3InternetOverLan" = "1" ] && [ "$Port3Mode" = "LAN3" ]
			then 
				uci set firewall.lan3l2tp=forwarding
				uci set firewall.lan3l2tp.src="$Port3lanInterfaceName"
				uci set firewall.lan3l2tp.dest="l2tp"

				uci set firewall.l2tplan3=forwarding
				uci set firewall.l2tplan3.src="l2tp"
				uci set firewall.l2tplan3.dest="$Port3lanInterfaceName"
			fi
			if [ "$Port4InternetOverLan" = "1" ] && [ "$Port4Mode" = "LAN4" ]
			then 
				uci set firewall.lan4l2tp=forwarding
				uci set firewall.lan4l2tp.src="$Port4lanInterfaceName"
				uci set firewall.lan4l2tp.dest="l2tp"

				uci set firewall.l2tplan4=forwarding
				uci set firewall.l2tplan4.src="l2tp"
				uci set firewall.l2tplan4.dest="$Port4lanInterfaceName"
			fi
			if [ "$InternetOverWifi" = "1" ]
			then
				if [ "$wifi1enable" = "1" ]
				then
					uci set firewall.wifil2tp=forwarding
					uci set firewall.wifil2tp.src="$wifiinterface"
					uci set firewall.wifil2tp.dest="l2tp"
					
					uci set firewall.wifi5l2tp=forwarding
					uci set firewall.wifi5l2tp.src="$wifi5interface"
					uci set firewall.wifi5l2tp.dest="l2tp"

				fi 
			fi 
		fi
			
		if [ "$InternetoverSwLan" = "1" ]
		then
			uci set firewall.swlanewan5=forwarding
			uci set firewall.swlanewan5.src="$SwlanInterfaceName"
			uci set firewall.swlanewan5.dest="$Port5WaninterfaceName"
		fi
		if [ "$Port1InternetOverLan" = "1" ] && [ "$Port1Mode" = "LAN1" ]
		then 
			uci set firewall.lan1ewan5=forwarding
			uci set firewall.lan1ewan5.src="$Port1lanInterfaceName"
			uci set firewall.lan1ewan5.dest="$Port5WaninterfaceName"
		fi
		if [ "$Port2InternetOverLan" = "1" ] && [ "$Port2Mode" = "LAN2" ]
		then 
			uci set firewall.lan2ewan5=forwarding
			uci set firewall.lan2ewan5.src="$Port2lanInterfaceName"
			uci set firewall.lan2ewan5.dest="$Port5WaninterfaceName"
		fi
		if [ "$Port3InternetOverLan" = "1" ] && [ "$Port3Mode" = "LAN3" ]
		then 
			uci set firewall.lan3ewan5=forwarding
			uci set firewall.lan3ewan5.src="$Port3lanInterfaceName"
			uci set firewall.lan3ewan5.dest="$Port5WaninterfaceName"
		fi
		if [ "$Port4InternetOverLan" = "1" ] && [ "$Port4Mode" = "LAN4" ]
		then 
			uci set firewall.lan4ewan5=forwarding
			uci set firewall.lan4ewan5.src="$Port4lanInterfaceName"
			uci set firewall.lan4ewan5.dest="$Port5WaninterfaceName"
		fi
		if [ "$InternetOverWifi" = "1" ]
		then
			if [ "$wifi1enable" = "1" ]
			then
				uci set firewall.wifiewan5=forwarding
				uci set firewall.wifiewan5.src="$wifiinterface"
				uci set firewall.wifiewan5.dest="$Port5WaninterfaceName"
				
				uci set firewall.wifi5ewan5=forwarding
				uci set firewall.wifi5ewan5.src="$wifi5interface"
				uci set firewall.wifi5ewan5.dest="$Port5WaninterfaceName"
			fi 
		fi 
    fi
	
	#if [ "$Port1Mode" = "SW_LAN" ]
	if [ "$Port1Mode" = "SW_LAN" ] || [ "$Port2Mode" = "SW_LAN" ] || [ "$Port3Mode" = "SW_LAN" ] || [ "$Port4Mode" = "SW_LAN" ] || [ "$Port5Mode" = "SW_LAN" ] 
	then
		uci set firewall.SW_LAN=zone
		uci set firewall.SW_LAN.name="$SwlanInterfaceName"
		uci set firewall.SW_LAN.input="ACCEPT"
		uci set firewall.SW_LAN.output="ACCEPT"
		uci set firewall.SW_LAN.forward="ACCEPT"
		uci set firewall.SW_LAN.network="$SwlanInterfaceName"
		uci set firewall.SW_LAN.masq="1"
		uci set firewall.SW_LAN.mtu_fix="1"
		#uci set firewall.SW_LAN.extra_src="-m policy --dir in --pol none"
		#uci set firewall.SW_LAN.extra_dest="-m policy --dir out --pol none"
		if [ "$Port1Mode" = "SW_LAN" ]; then
			uci delete firewall.lan1wifi > /dev/null 2>&1
			uci delete firewall.lan1ewan1 > /dev/null 2>&1
			uci delete firewall.lan1ewan2 > /dev/null 2>&1
			uci delete firewall.lan1ewan3 > /dev/null 2>&1
			uci delete firewall.lan1ewan4 > /dev/null 2>&1
			uci delete firewall.lan1ewan5 > /dev/null 2>&1
			uci delete firewall.lan1cwan1 > /dev/null 2>&1
			uci delete firewall.lan1cwan1_0 > /dev/null 2>&1
			uci delete firewall.lan1cwan1_1 > /dev/null 2>&1
			uci delete firewall.lan1cwan2 > /dev/null 2>&1
			uci delete firewall.lan1 > /dev/null 2>&1
			uci delete firewall.ewan1 > /dev/null 2>&1
		fi
		if [ "$Port2Mode" = "SW_LAN" ]; then
			uci delete firewall.lan2wifi > /dev/null 2>&1
			uci delete firewall.lan2ewan1 > /dev/null 2>&1
			uci delete firewall.lan2ewan2 > /dev/null 2>&1
			uci delete firewall.lan2ewan3 > /dev/null 2>&1
			uci delete firewall.lan2ewan4 > /dev/null 2>&1
			uci delete firewall.lan2ewan5 > /dev/null 2>&1
			uci delete firewall.lan2cwan1 > /dev/null 2>&1
			uci delete firewall.lan2cwan1_0 > /dev/null 2>&1
			uci delete firewall.lan2cwan1_1 > /dev/null 2>&1
			uci delete firewall.lan2cwan2 > /dev/null 2>&1
			uci delete firewall.lan2 > /dev/null 2>&1
			uci delete firewall.ewan2 > /dev/null 2>&1
		fi
		if [ "$Port3Mode" = "SW_LAN" ]; then
			uci delete firewall.lan3wifi > /dev/null 2>&1
			uci delete firewall.lan3ewan1 > /dev/null 2>&1
			uci delete firewall.lan3ewan2 > /dev/null 2>&1
			uci delete firewall.lan3ewan3 > /dev/null 2>&1
			uci delete firewall.lan3ewan4 > /dev/null 2>&1
			uci delete firewall.lan3ewan5 > /dev/null 2>&1
			uci delete firewall.lan3cwan1 > /dev/null 2>&1
			uci delete firewall.lan3cwan1_0 > /dev/null 2>&1
			uci delete firewall.lan3cwan1_1 > /dev/null 2>&1
			uci delete firewall.lan3cwan2 > /dev/null 2>&1
			uci delete firewall.lan3 > /dev/null 2>&1
			uci delete firewall.ewan3 > /dev/null 2>&1
		fi
		if [ "$Port4Mode" = "SW_LAN" ]; then
			uci delete firewall.lan4wifi > /dev/null 2>&1
			uci delete firewall.lan4ewan1 > /dev/null 2>&1
			uci delete firewall.lan4ewan2 > /dev/null 2>&1
			uci delete firewall.lan4ewan3 > /dev/null 2>&1
			uci delete firewall.lan4ewan4 > /dev/null 2>&1
			uci delete firewall.lan4ewan5 > /dev/null 2>&1
			uci delete firewall.lan4cwan1 > /dev/null 2>&1
			uci delete firewall.lan4cwan1_0 > /dev/null 2>&1
			uci delete firewall.lan4cwan1_1 > /dev/null 2>&1
			uci delete firewall.lan4cwan2 > /dev/null 2>&1
			uci delete firewall.lan4 > /dev/null 2>&1
			uci delete firewall.ewan4 > /dev/null 2>&1
		fi
		if [ "$Port5Mode" = "SW_LAN" ]; then
			uci delete firewall.lan5wifi > /dev/null 2>&1
			uci delete firewall.lan5ewan1 > /dev/null 2>&1
			uci delete firewall.lan5ewan2 > /dev/null 2>&1
			uci delete firewall.lan5ewan3 > /dev/null 2>&1
			uci delete firewall.lan5ewan4 > /dev/null 2>&1
			uci delete firewall.lan5ewan5 > /dev/null 2>&1
			uci delete firewall.lan5cwan1 > /dev/null 2>&1
			uci delete firewall.lan5cwan1_0 > /dev/null 2>&1
			uci delete firewall.lan5cwan1_1 > /dev/null 2>&1
			uci delete firewall.lan5cwan2 > /dev/null 2>&1
			uci delete firewall.lan5 > /dev/null 2>&1
			uci delete firewall.ewan5 > /dev/null 2>&1
		fi
	else
		uci delete firewall.SW_LAN > /dev/null 2>&1
    fi

	if [ "$EnableCellular" = "1" ]
    then
		if [ "$CellularOperationModelocal" = "dualcellularsinglesim" ]
		then
			uci delete firewall.cwan1_0 > /dev/null 2>&1
			uci delete firewall.cwan1_1 > /dev/null 2>&1
			uci delete firewall.udp_DHCPv6_replies > /dev/null 2>&1
			uci delete firewall.wan6c1 > /dev/null 2>&1
			uci delete firewall.wan6c2 > /dev/null 2>&1
			uci set firewall.cwan1=zone
			uci set firewall.cwan1.name="$cellularwan1interface"
			uci set firewall.cwan1.input="ACCEPT"
			uci set firewall.cwan1.output="ACCEPT"
			uci set firewall.cwan1.forward="ACCEPT"
			uci set firewall.cwan1.network="$cellularwan1interface"
			uci set firewall.cwan1.masq="1"
			uci set firewall.cwan1.mtu_fix="1"
			#uci set firewall.cwan1.extra_src="-m policy --dir in --pol none"
			#uci set firewall.cwan1.extra_dest="-m policy --dir out --pol none"
			uci set firewall.cwan2=zone
			uci set firewall.cwan2.name="$cellularwan2interface"
			uci set firewall.cwan2.input="ACCEPT"
			uci set firewall.cwan2.output="ACCEPT"
			uci set firewall.cwan2.forward="ACCEPT"
			uci set firewall.cwan2.network="$cellularwan2interface"
			uci set firewall.cwan2.masq="1"
			uci set firewall.cwan2.mtu_fix="1"
			#uci set firewall.cwan2.extra_src="-m policy --dir in --pol none"
			#uci set firewall.cwan2.extra_dest="-m policy --dir out --pol none" 
			
			if [ "$Pdp1" = "2" ] || [ "$Pdp1" = "3" ] 
			then
				uci set firewall.$cellular1wan6interface=zone
				uci set firewall.$cellular1wan6interface.name="$cellular1wan6interface"
				uci set firewall.$cellular1wan6interface.input="ACCEPT"
				uci set firewall.$cellular1wan6interface.output="ACCEPT"
				uci set firewall.$cellular1wan6interface.forward="ACCEPT"
				uci set firewall.$cellular1wan6interface.network="$cellular1wan6interface"
				uci set firewall.$cellular1wan6interface.masq="1"
				uci set firewall.$cellular1wan6interface.mtu_fix="1"

				uci set firewall.udp_DHCPv6_replies=rule
				uci set firewall.udp_DHCPv6_replies.target='ACCEPT'
				uci set firewall.udp_DHCPv6_replies.src="$cellular1wan6interface"
				uci set firewall.udp_DHCPv6_replies.proto='udp'
				uci set firewall.udp_DHCPv6_replies.dest_port='546'
				uci set firewall.udp_DHCPv6_replies.name='Allow DHCPv6 replies'
				uci set firewall.udp_DHCPv6_replies.family='ipv6'
				uci set firewall.udp_DHCPv6_replies.src_port='547'  
			fi       
			if [ "$sim2pdp" = "2" ] || [ "$sim2pdp" = "3" ]
			then
				uci set firewall.$cellular2wan6interface=zone
				uci set firewall.$cellular2wan6interface.name="$cellular2wan6interface"
				uci set firewall.$cellular2wan6interface.input="ACCEPT"
				uci set firewall.$cellular2wan6interface.output="ACCEPT"
				uci set firewall.$cellular2wan6interface.forward="ACCEPT"
				uci set firewall.$cellular2wan6interface.network="$cellular2wan6interface"
				uci set firewall.$cellular2wan6interface.masq="1"
				uci set firewall.$cellular2wan6interface.mtu_fix="1"

				uci set firewall.udp_DHCPv6_replies=rule
				uci set firewall.udp_DHCPv6_replies.target='ACCEPT'
				uci set firewall.udp_DHCPv6_replies.src="$cellular2wan6interface"
				uci set firewall.udp_DHCPv6_replies.proto='udp'
				uci set firewall.udp_DHCPv6_replies.dest_port='546'
				uci set firewall.udp_DHCPv6_replies.name='Allow DHCPv6 replies'
				uci set firewall.udp_DHCPv6_replies.family='ipv6'
				uci set firewall.udp_DHCPv6_replies.src_port='547'      
			fi
			                                               
			uci delete firewall.swlancwan1_0 > /dev/null 2>&1
			uci delete firewall.swlancwan1_1 > /dev/null 2>&1
			uci delete firewall.lan1cwan1_0 > /dev/null 2>&1
			uci delete firewall.lan1cwan1_1 > /dev/null 2>&1
			uci delete firewall.lan2cwan1_0 > /dev/null 2>&1
			uci delete firewall.lan2cwan1_1 > /dev/null 2>&1
			uci delete firewall.lan3cwan1_0 > /dev/null 2>&1
			uci delete firewall.lan3cwan1_1 > /dev/null 2>&1
			uci delete firewall.lan4cwan1_0 > /dev/null 2>&1
			uci delete firewall.lan4cwan1_1 > /dev/null 2>&1
			uci delete firewall.lan5cwan1_0 > /dev/null 2>&1
			uci delete firewall.lan5cwan1_1 > /dev/null 2>&1
			uci delete firewall.wificwan1_0 > /dev/null 2>&1
			uci delete firewall.wificwan1_1 > /dev/null 2>&1
			uci delete firewall.wifi5cwan1_0 > /dev/null 2>&1
			uci delete firewall.wifi5cwan1_1 > /dev/null 2>&1
			if [ "$InternetoverSwLan" = "1" ]
			then
				uci set firewall.swlancwan1=forwarding
				uci set firewall.swlancwan1.src="$SwlanInterfaceName"
				uci set firewall.swlancwan1.dest="$cellularwan1interface"
				uci set firewall.swlancwan2=forwarding
				uci set firewall.swlancwan2.src="$SwlanInterfaceName"
				uci set firewall.swlancwan2.dest="$cellularwan2interface"
			fi
			if [ "$Port1InternetOverLan" = "1" ] && [ "$Port1Mode" = "LAN1" ]
			then 
				uci set firewall.lan1cwan1=forwarding
				uci set firewall.lan1cwan1.src="$Port1lanInterfaceName"
				uci set firewall.lan1cwan1.dest="$cellularwan1interface"
				uci set firewall.lan1cwan2=forwarding
				uci set firewall.lan1cwan2.src="$Port1lanInterfaceName"
				uci set firewall.lan1cwan2.dest="$cellularwan2interface"
			fi
			if [ "$Port2InternetOverLan" = "1" ] && [ "$Port2Mode" = "LAN2" ]
			then 
				uci set firewall.lan2cwan1=forwarding
				uci set firewall.lan2cwan1.src="$Port2lanInterfaceName"
				uci set firewall.lan2cwan1.dest="$cellularwan1interface"
				uci set firewall.lan2cwan2=forwarding
				uci set firewall.lan2cwan2.src="$Port2lanInterfaceName"
				uci set firewall.lan2cwan2.dest="$cellularwan2interface"
			fi
			if [ "$Port3InternetOverLan" = "1" ] && [ "$Port3Mode" = "LAN3" ]
			then 
				uci set firewall.lan3cwan1=forwarding
				uci set firewall.lan3cwan1.src="$Port3lanInterfaceName"
				uci set firewall.lan3cwan1.dest="$cellularwan1interface"
				uci set firewall.lan3cwan2=forwarding
				uci set firewall.lan3cwan2.src="$Port3lanInterfaceName"
				uci set firewall.lan3cwan2.dest="$cellularwan2interface"
			fi
			if [ "$Port4InternetOverLan" = "1" ] && [ "$Port4Mode" = "LAN4" ]
			then 
				uci set firewall.lan4cwan1=forwarding
				uci set firewall.lan4cwan1.src="$Port4lanInterfaceName"
				uci set firewall.lan4cwan1.dest="$cellularwan1interface"
				uci set firewall.lan4cwan2=forwarding
				uci set firewall.lan4cwan2.src="$Port4lanInterfaceName"
				uci set firewall.lan4cwan2.dest="$cellularwan2interface"
			fi
			if [ "$Port5InternetOverLan" = "1" ] && [ "$Port5Mode" = "LAN5" ]
			then 
				uci set firewall.lan5cwan1=forwarding
				uci set firewall.lan5cwan1.src="$Port5lanInterfaceName"
				uci set firewall.lan5cwan1.dest="$cellularwan1interface"
				uci set firewall.lan5cwan2=forwarding
				uci set firewall.lan5cwan2.src="$Port5lanInterfaceName"
				uci set firewall.lan5cwan2.dest="$cellularwan2interface"
			fi
			if [ "$InternetOverWifi" = "1" ]
			then
				if [ "$wifi1enable" = "1" ]
				then
					uci set firewall.wificwan1=forwarding
					uci set firewall.wificwan1.src="$wifiinterface"
					uci set firewall.wificwan1.dest="$cellularwan1interface"
					uci set firewall.wificwan2=forwarding
					uci set firewall.wificwan2.src="$wifiinterface"
					uci set firewall.wificwan2.dest="$cellularwan2interface"
					
					uci set firewall.wifi5cwan1=forwarding
					uci set firewall.wifi5cwan1.src="$wifi5interface"
					uci set firewall.wifi5cwan1.dest="$cellularwan1interface"
					uci set firewall.wifi5cwan2=forwarding
					uci set firewall.wifi5cwan2.src="$wifi5interface"
					uci set firewall.wifi5cwan2.dest="$cellularwan2interface"
				fi 
			fi
		elif [ "$CellularOperationModelocal" = "singlecellulardualsim" ]
		then
			uci delete firewall.cwan1 > /dev/null 2>&1
			uci delete firewall.cwan2 > /dev/null 2>&1
			uci delete firewall.udp_DHCPv6_replies > /dev/null 2>&1
			uci delete firewall.wan6c1 > /dev/null 2>&1
			uci delete firewall.wan6c2 > /dev/null 2>&1
			uci set firewall.cwan1_0=zone
			uci set firewall.cwan1_0.name="$cellularwan1sim1interface"
			uci set firewall.cwan1_0.input="ACCEPT"
			uci set firewall.cwan1_0.output="ACCEPT"
			uci set firewall.cwan1_0.forward="ACCEPT"
			uci set firewall.cwan1_0.network="$cellularwan1sim1interface"
			uci set firewall.cwan1_0.masq="1"
			uci set firewall.cwan1_0.mtu_fix="1"
			#uci set firewall.cwan1_0.extra_src="-m policy --dir in --pol none"
			#uci set firewall.cwan1_0.extra_dest="-m policy --dir out --pol none"
			uci set firewall.cwan1_1=zone
			uci set firewall.cwan1_1.name="$cellularwan1sim2interface"
			uci set firewall.cwan1_1.input="ACCEPT"
			uci set firewall.cwan1_1.output="ACCEPT"
			uci set firewall.cwan1_1.forward="ACCEPT"
			uci set firewall.cwan1_1.network="$cellularwan1sim2interface"
			uci set firewall.cwan1_1.masq="1"
			uci set firewall.cwan1_1.mtu_fix="1"
			#uci set firewall.cwan1_1.extra_src="-m policy --dir in --pol none"
			#uci set firewall.cwan1_1.extra_dest="-m policy --dir out --pol none" 
			
			if [ "$Pdp1" = "2" ] || [ "$Pdp1" = "3" ] 
			then
				uci set firewall.$cellular1wan6interface=zone
				uci set firewall.$cellular1wan6interface.name="$cellular1wan6interface"
				uci set firewall.$cellular1wan6interface.input="ACCEPT"
				uci set firewall.$cellular1wan6interface.output="ACCEPT"
				uci set firewall.$cellular1wan6interface.forward="ACCEPT"
				uci set firewall.$cellular1wan6interface.network="$cellular1wan6interface"
				uci set firewall.$cellular1wan6interface.masq="1"
				uci set firewall.$cellular1wan6interface.mtu_fix="1"

				uci set firewall.udp_DHCPv6_replies=rule
				uci set firewall.udp_DHCPv6_replies.target='ACCEPT'
				uci set firewall.udp_DHCPv6_replies.src="$cellular1wan6interface"
				uci set firewall.udp_DHCPv6_replies.proto='udp'
				uci set firewall.udp_DHCPv6_replies.dest_port='546'
				uci set firewall.udp_DHCPv6_replies.name='Allow DHCPv6 replies'
				uci set firewall.udp_DHCPv6_replies.family='ipv6'
				uci set firewall.udp_DHCPv6_replies.src_port='547'  
			fi       
			if [ "$sim2pdp" = "2" ] || [ "$sim2pdp" = "3" ]
			then
				uci set firewall.$cellular2wan6interface=zone
				uci set firewall.$cellular2wan6interface.name="$cellular2wan6interface"
				uci set firewall.$cellular2wan6interface.input="ACCEPT"
				uci set firewall.$cellular2wan6interface.output="ACCEPT"
				uci set firewall.$cellular2wan6interface.forward="ACCEPT"
				uci set firewall.$cellular2wan6interface.network="$cellular2wan6interface"
				uci set firewall.$cellular2wan6interface.masq="1"
				uci set firewall.$cellular2wan6interface.mtu_fix="1"

				uci set firewall.udp_DHCPv6_replies=rule
				uci set firewall.udp_DHCPv6_replies.target='ACCEPT'
				uci set firewall.udp_DHCPv6_replies.src="$cellular2wan6interface"
				uci set firewall.udp_DHCPv6_replies.proto='udp'
				uci set firewall.udp_DHCPv6_replies.dest_port='546'
				uci set firewall.udp_DHCPv6_replies.name='Allow DHCPv6 replies'
				uci set firewall.udp_DHCPv6_replies.family='ipv6'
				uci set firewall.udp_DHCPv6_replies.src_port='547'      
			fi
			  
			uci delete firewall.swlancwan1 > /dev/null 2>&1
			uci delete firewall.swlancwan2 > /dev/null 2>&1
			uci delete firewall.lan1cwan1 > /dev/null 2>&1
			uci delete firewall.lan1cwan2 > /dev/null 2>&1
			uci delete firewall.lan2cwan1 > /dev/null 2>&1
			uci delete firewall.lan2cwan2 > /dev/null 2>&1
			uci delete firewall.lan3cwan1 > /dev/null 2>&1
			uci delete firewall.lan3cwan2 > /dev/null 2>&1
			uci delete firewall.lan4cwan1 > /dev/null 2>&1
			uci delete firewall.lan4cwan2 > /dev/null 2>&1
			uci delete firewall.lan5cwan1 > /dev/null 2>&1
			uci delete firewall.lan5cwan2 > /dev/null 2>&1
			uci delete firewall.wificwan1 > /dev/null 2>&1
			uci delete firewall.wificwan2 > /dev/null 2>&1
			uci delete firewall.wifi5cwan1 > /dev/null 2>&1
			uci delete firewall.wifi5cwan2 > /dev/null 2>&1
			if [ "$InternetoverSwLan" = "1" ]
			then
				uci set firewall.swlancwan1_0=forwarding
				uci set firewall.swlancwan1_0.src="$SwlanInterfaceName"
				uci set firewall.swlancwan1_0.dest="$cellularwan1sim1interface"
				uci set firewall.swlancwan1_1=forwarding
				uci set firewall.swlancwan1_1.src="$SwlanInterfaceName"
				uci set firewall.swlancwan1_1.dest="$cellularwan1sim2interface"
			fi
			if [ "$Port1InternetOverLan" = "1" ] && [ "$Port1Mode" = "LAN1" ]
			then 
				uci set firewall.lan1cwan1_0=forwarding
				uci set firewall.lan1cwan1_0.src="$Port1lanInterfaceName"
				uci set firewall.lan1cwan1_0.dest="$cellularwan1sim1interface"
				uci set firewall.lan1cwan1_1=forwarding
				uci set firewall.lan1cwan1_1.src="$Port1lanInterfaceName"
				uci set firewall.lan1cwan1_1.dest="$cellularwan1sim2interface"
			fi
			if [ "$Port2InternetOverLan" = "1" ] && [ "$Port2Mode" = "LAN2" ]
			then 
				uci set firewall.lan2cwan1_0=forwarding
				uci set firewall.lan2cwan1_0.src="$Port2lanInterfaceName"
				uci set firewall.lan2cwan1_0.dest="$cellularwan1sim1interface"
				uci set firewall.lan2cwan1_1=forwarding
				uci set firewall.lan2cwan1_1.src="$Port2lanInterfaceName"
				uci set firewall.lan2cwan1_1.dest="$cellularwan1sim2interface"
			fi
			if [ "$Port3InternetOverLan" = "1" ] && [ "$Port3Mode" = "LAN3" ]
			then 
				uci set firewall.lan3cwan1_0=forwarding
				uci set firewall.lan3cwan1_0.src="$Port3lanInterfaceName"
				uci set firewall.lan3cwan1_0.dest="$cellularwan1sim1interface"
				uci set firewall.lan3cwan1_1=forwarding
				uci set firewall.lan3cwan1_1.src="$Port3lanInterfaceName"
				uci set firewall.lan3cwan1_1.dest="$cellularwan1sim2interface"
			fi
			if [ "$Port4InternetOverLan" = "1" ] && [ "$Port4Mode" = "LAN4" ]
			then 
				uci set firewall.lan4cwan1_0=forwarding
				uci set firewall.lan4cwan1_0.src="$Port4lanInterfaceName"
				uci set firewall.lan4cwan1_0.dest="$cellularwan1sim1interface"
				uci set firewall.lan4cwan1_1=forwarding
				uci set firewall.lan4cwan1_1.src="$Port4lanInterfaceName"
				uci set firewall.lan4cwan1_1.dest="$cellularwan1sim2interface"
			fi
			if [ "$Port5InternetOverLan" = "1" ] && [ "$Port5Mode" = "LAN5" ]
			then 
				uci set firewall.lan5cwan1_0=forwarding
				uci set firewall.lan5cwan1_0.src="$Port5lanInterfaceName"
				uci set firewall.lan5cwan1_0.dest="$cellularwan1sim1interface"
				uci set firewall.lan5cwan1_1=forwarding
				uci set firewall.lan5cwan1_1.src="$Port5lanInterfaceName"
				uci set firewall.lan5cwan1_1.dest="$cellularwan1sim2interface"
			fi
			if [ "$InternetOverWifi" = "1" ]
			then
				if [ "$wifi1enable" = "1" ]
				then
					uci set firewall.wificwan1_0=forwarding
					uci set firewall.wificwan1_0.src="$wifiinterface"
					uci set firewall.wificwan1_0.dest="$cellularwan1sim1interface"
					uci set firewall.wificwan1_1=forwarding
					uci set firewall.wificwan1_1.src="$wifiinterface"
					uci set firewall.wificwan1_1.dest="$cellularwan1sim2interface"
					
					uci set firewall.wifi5cwan1_0=forwarding
					uci set firewall.wifi5cwan1_0.src="$wifi5interface"
					uci set firewall.wifi5cwan1_0.dest="$cellularwan1sim1interface"
					uci set firewall.wifi5cwan1_1=forwarding
					uci set firewall.wifi5cwan1_1.src="$wifi5interface"
					uci set firewall.wifi5cwan1_1.dest="$cellularwan1sim2interface"
				fi 
			fi 
		else
			uci delete firewall.cwan1_0 > /dev/null 2>&1
			uci delete firewall.cwan1_1 > /dev/null 2>&1
			uci delete firewall.cwan2 > /dev/null 2>&1
			uci delete firewall.udp_DHCPv6_replies > /dev/null 2>&1
			uci delete firewall.wan6c1 > /dev/null 2>&1
			uci set firewall.cwan1=zone
			uci set firewall.cwan1.name="$cellularwan1interface"
			uci set firewall.cwan1.input="ACCEPT"
			uci set firewall.cwan1.output="ACCEPT"
			uci set firewall.cwan1.forward="ACCEPT"
			uci set firewall.cwan1.network="$cellularwan1interface"
			uci set firewall.cwan1.masq="1"
			uci set firewall.cwan1.mtu_fix="1"
			#uci set firewall.cwan1.extra_src="-m policy --dir in --pol none"
			#uci set firewall.cwan1.extra_dest="-m policy --dir out --pol none"
			
			if [ "$Pdp1" = "2" ] || [ "$Pdp1" = "3" ] 
			then
				uci set firewall.$cellular1wan6interface=zone
				uci set firewall.$cellular1wan6interface.name="$cellular1wan6interface"
				uci set firewall.$cellular1wan6interface.input="ACCEPT"
				uci set firewall.$cellular1wan6interface.output="ACCEPT"
				uci set firewall.$cellular1wan6interface.forward="ACCEPT"
				uci set firewall.$cellular1wan6interface.network="$cellular1wan6interface"
				uci set firewall.$cellular1wan6interface.masq="1"
				uci set firewall.$cellular1wan6interface.mtu_fix="1"

				uci set firewall.udp_DHCPv6_replies=rule
				uci set firewall.udp_DHCPv6_replies.target='ACCEPT'
				uci set firewall.udp_DHCPv6_replies.src="$cellular1wan6interface"
				uci set firewall.udp_DHCPv6_replies.proto='udp'
				uci set firewall.udp_DHCPv6_replies.dest_port='546'
				uci set firewall.udp_DHCPv6_replies.name='Allow DHCPv6 replies'
				uci set firewall.udp_DHCPv6_replies.family='ipv6'
				uci set firewall.udp_DHCPv6_replies.src_port='547'  
			fi 
			
			uci delete firewall.swlancwan1_0 > /dev/null 2>&1
			uci delete firewall.swlancwan1_1 > /dev/null 2>&1
			uci delete firewall.swlancwan2 > /dev/null 2>&1
			uci delete firewall.lan1cwan1_0 > /dev/null 2>&1
			uci delete firewall.lan1cwan1_1 > /dev/null 2>&1
			uci delete firewall.lan1cwan2 > /dev/null 2>&1
			uci delete firewall.lan2cwan1_0 > /dev/null 2>&1
			uci delete firewall.lan2cwan1_1 > /dev/null 2>&1
			uci delete firewall.lan2cwan2 > /dev/null 2>&1
			uci delete firewall.lan3cwan1_0 > /dev/null 2>&1
			uci delete firewall.lan3cwan1_1 > /dev/null 2>&1
			uci delete firewall.lan3cwan2 > /dev/null 2>&1
			uci delete firewall.lan4cwan1_0 > /dev/null 2>&1
			uci delete firewall.lan4cwan1_1 > /dev/null 2>&1
			uci delete firewall.lan4cwan2 > /dev/null 2>&1
			uci delete firewall.lan5cwan1_0 > /dev/null 2>&1
			uci delete firewall.lan5cwan1_1 > /dev/null 2>&1
			uci delete firewall.lan5cwan2 > /dev/null 2>&1
			uci delete firewall.wificwan1_0 > /dev/null 2>&1
			uci delete firewall.wificwan1_1 > /dev/null 2>&1
			uci delete firewall.wificwan2 > /dev/null 2>&1
			uci delete firewall.wifi5cwan1_0 > /dev/null 2>&1
			uci delete firewall.wifi5cwan1_1 > /dev/null 2>&1
			uci delete firewall.wifi5cwan2 > /dev/null 2>&1
			if [ "$InternetoverSwLan" = "1" ]
			then
				uci set firewall.swlancwan1=forwarding
				uci set firewall.swlancwan1.src="$SwlanInterfaceName"
				uci set firewall.swlancwan1.dest="$cellularwan1interface"
			fi
			if [ "$Port1InternetOverLan" = "1" ] && [ "$Port1Mode" = "LAN1" ]
			then 
				uci set firewall.lan1cwan1=forwarding
				uci set firewall.lan1cwan1.src="$Port1lanInterfaceName"
				uci set firewall.lan1cwan1.dest="$cellularwan1interface"
			fi
			if [ "$Port2InternetOverLan" = "1" ] && [ "$Port2Mode" = "LAN2" ]
			then 
				uci set firewall.lan2cwan1=forwarding
				uci set firewall.lan2cwan1.src="$Port2lanInterfaceName"
				uci set firewall.lan2cwan1.dest="$cellularwan1interface"
			fi
			if [ "$Port3InternetOverLan" = "1" ] && [ "$Port3Mode" = "LAN3" ]
			then 
				uci set firewall.lan3cwan1=forwarding
				uci set firewall.lan3cwan1.src="$Port3lanInterfaceName"
				uci set firewall.lan3cwan1.dest="$cellularwan1interface"
			fi
			if [ "$Port4InternetOverLan" = "1" ] && [ "$Port4Mode" = "LAN4" ]
			then 
				uci set firewall.lan4cwan1=forwarding
				uci set firewall.lan4cwan1.src="$Port4lanInterfaceName"
				uci set firewall.lan4cwan1.dest="$cellularwan1interface"
			fi
			if [ "$Port5InternetOverLan" = "1" ] && [ "$Port5Mode" = "LAN5" ]
			then 
				uci set firewall.lan5cwan1=forwarding
				uci set firewall.lan5cwan1.src="$Port5lanInterfaceName"
				uci set firewall.lan5cwan1.dest="$cellularwan1interface"
			fi
			if [ "$InternetOverWifi" = "1" ]
			then
				if [ "$wifi1enable" = "1" ]
				then
					uci set firewall.wificwan1=forwarding
					uci set firewall.wificwan1.src="$wifiinterface"
					uci set firewall.wificwan1.dest="$cellularwan1interface"
					
					uci set firewall.wifi5cwan1=forwarding
					uci set firewall.wifi5cwan1.src="$wifi5interface"
					uci set firewall.wifi5cwan1.dest="$cellularwan1interface"
				fi 
			fi 
		fi
	else
		uci delete firewall.cwan1 > /dev/null 2>&1
		uci delete firewall.cwan2 > /dev/null 2>&1
		uci delete firewall.cwan1_0 > /dev/null 2>&1
		uci delete firewall.cwan1_1 > /dev/null 2>&1
		uci delete firewall.swlancwan1 > /dev/null 2>&1
		uci delete firewall.swlancwan2 > /dev/null 2>&1
		uci delete firewall.swlancwan1_0 > /dev/null 2>&1
		uci delete firewall.swlancwan1_1 > /dev/null 2>&1
		uci delete firewall.lan1cwan1 > /dev/null 2>&1
		uci delete firewall.lan1cwan2 > /dev/null 2>&1
		uci delete firewall.lan1cwan1_0 > /dev/null 2>&1
		uci delete firewall.lan1cwan1_1 > /dev/null 2>&1
		uci delete firewall.lan2cwan1 > /dev/null 2>&1
		uci delete firewall.lan2cwan2 > /dev/null 2>&1
		uci delete firewall.lan2cwan1_0 > /dev/null 2>&1
		uci delete firewall.lan2cwan1_1 > /dev/null 2>&1
		uci delete firewall.lan3cwan1 > /dev/null 2>&1
		uci delete firewall.lan3cwan2 > /dev/null 2>&1
		uci delete firewall.lan3cwan1_0 > /dev/null 2>&1
		uci delete firewall.lan3cwan1_1 > /dev/null 2>&1
		uci delete firewall.lan4cwan1 > /dev/null 2>&1
		uci delete firewall.lan4cwan2 > /dev/null 2>&1
		uci delete firewall.lan4cwan1_0 > /dev/null 2>&1
		uci delete firewall.lan4cwan1_1 > /dev/null 2>&1
		uci delete firewall.lan5cwan1 > /dev/null 2>&1
		uci delete firewall.lan5cwan2 > /dev/null 2>&1
		uci delete firewall.lan5cwan1_0 > /dev/null 2>&1
		uci delete firewall.lan5cwan1_1 > /dev/null 2>&1
		uci delete firewall.wificwan1 > /dev/null 2>&1
		uci delete firewall.wificwan2 > /dev/null 2>&1
		uci delete firewall.wificwan1_0 > /dev/null 2>&1
		uci delete firewall.wificwan1_1 > /dev/null 2>&1
		uci delete firewall.wifi5cwan1 > /dev/null 2>&1
		uci delete firewall.wifi5cwan2 > /dev/null 2>&1
		uci delete firewall.wifi5cwan1_0 > /dev/null 2>&1
		uci delete firewall.wifi5cwan1_1 > /dev/null 2>&1
	fi
	
	if [ "$InternetoverSwLan" = "0" ]
	then
		uci delete firewall.swlanwifi > /dev/null 2>&1
		uci delete firewall.swlanewan1 > /dev/null 2>&1
		uci delete firewall.swlanewan2 > /dev/null 2>&1
		uci delete firewall.swlanewan3 > /dev/null 2>&1
		uci delete firewall.swlanewan4 > /dev/null 2>&1
		uci delete firewall.swlanewan5 > /dev/null 2>&1
		uci delete firewall.swlancwan1 > /dev/null 2>&1
		uci delete firewall.swlancwan1_0 > /dev/null 2>&1
		uci delete firewall.swlancwan1_1 > /dev/null 2>&1
		uci delete firewall.swlancwan2 > /dev/null 2>&1
	fi
	if [ "$Port1InternetOverLan" = "0" ]
	then
		uci delete firewall.lan1wifi > /dev/null 2>&1
		uci delete firewall.lan1ewan2 > /dev/null 2>&1
		uci delete firewall.lan1ewan3 > /dev/null 2>&1
		uci delete firewall.lan1ewan4 > /dev/null 2>&1
		uci delete firewall.lan1ewan5 > /dev/null 2>&1
		uci delete firewall.lan1cwan1 > /dev/null 2>&1
		uci delete firewall.lan1cwan1_0 > /dev/null 2>&1
		uci delete firewall.lan1cwan1_1 > /dev/null 2>&1
		uci delete firewall.lan1cwan2 > /dev/null 2>&1
	fi
	if [ "$Port2InternetOverLan" = "0" ]
	then
		uci delete firewall.lan2wifi > /dev/null 2>&1
		uci delete firewall.lan2ewan1 > /dev/null 2>&1
		uci delete firewall.lan2ewan3 > /dev/null 2>&1
		uci delete firewall.lan2ewan4 > /dev/null 2>&1
		uci delete firewall.lan2ewan5 > /dev/null 2>&1
		uci delete firewall.lan2cwan1 > /dev/null 2>&1
		uci delete firewall.lan2cwan1_0 > /dev/null 2>&1
		uci delete firewall.lan2cwan1_1 > /dev/null 2>&1
		uci delete firewall.lan2cwan2 > /dev/null 2>&1
	fi
	if [ "$Port3InternetOverLan" = "0" ]
	then
		uci delete firewall.lan3wifi > /dev/null 2>&1
		uci delete firewall.lan3ewan1 > /dev/null 2>&1
		uci delete firewall.lan3ewan2 > /dev/null 2>&1
		uci delete firewall.lan3ewan4 > /dev/null 2>&1
		uci delete firewall.lan3ewan5 > /dev/null 2>&1
		uci delete firewall.lan3cwan1 > /dev/null 2>&1
		uci delete firewall.lan3cwan1_0 > /dev/null 2>&1
		uci delete firewall.lan3cwan1_1 > /dev/null 2>&1
		uci delete firewall.lan3cwan2 > /dev/null 2>&1
	fi
	if [ "$Port4InternetOverLan" = "0" ]
	then
		uci delete firewall.lan4wifi > /dev/null 2>&1
		uci delete firewall.lan4ewan1 > /dev/null 2>&1
		uci delete firewall.lan4ewan2 > /dev/null 2>&1
		uci delete firewall.lan4ewan3 > /dev/null 2>&1
		uci delete firewall.lan4ewan5 > /dev/null 2>&1
		uci delete firewall.lan4cwan1 > /dev/null 2>&1
		uci delete firewall.lan4cwan1_0 > /dev/null 2>&1
		uci delete firewall.lan4cwan1_1 > /dev/null 2>&1
		uci delete firewall.lan4cwan2 > /dev/null 2>&1
	fi
	if [ "$Port5InternetOverLan" = "0" ]
	then
		uci delete firewall.lan4wifi > /dev/null 2>&1
		uci delete firewall.lan4ewan1 > /dev/null 2>&1
		uci delete firewall.lan4ewan2 > /dev/null 2>&1
		uci delete firewall.lan4ewan3 > /dev/null 2>&1
		uci delete firewall.lan4ewan4 > /dev/null 2>&1
		uci delete firewall.lan4cwan1 > /dev/null 2>&1
		uci delete firewall.lan4cwan1_0 > /dev/null 2>&1
		uci delete firewall.lan4cwan1_1 > /dev/null 2>&1
		uci delete firewall.lan4cwan2 > /dev/null 2>&1
	fi
	if [ "$InternetOverWifi" = "0" ]
	then
		uci delete firewall.wifiewan1 > /dev/null 2>&1
		uci delete firewall.wifiewan2 > /dev/null 2>&1
		uci delete firewall.wifiewan3 > /dev/null 2>&1
		uci delete firewall.wifiewan4 > /dev/null 2>&1
		uci delete firewall.wifiewan5 > /dev/null 2>&1
		uci delete firewall.wificwan1 > /dev/null 2>&1
		uci delete firewall.wificwan1_0 > /dev/null 2>&1
		uci delete firewall.wificwan1_1 > /dev/null 2>&1
		uci delete firewall.wificwan2 > /dev/null 2>&1
		uci delete firewall.wifi5ewan1 > /dev/null 2>&1
		uci delete firewall.wifi5ewan2 > /dev/null 2>&1
		uci delete firewall.wifi5ewan3 > /dev/null 2>&1
		uci delete firewall.wifi5ewan4 > /dev/null 2>&1
		uci delete firewall.wifi5ewan5 > /dev/null 2>&1
		uci delete firewall.wifi5cwan1 > /dev/null 2>&1
		uci delete firewall.wifi5cwan1_0 > /dev/null 2>&1
		uci delete firewall.wifi5cwan1_1 > /dev/null 2>&1
		uci delete firewall.wifi5cwan2 > /dev/null 2>&1
	fi
	if [ "$wifi1enable" = "0" ]
	then
		uci delete firewall.wifiewan1 > /dev/null 2>&1
		uci delete firewall.wifiewan2 > /dev/null 2>&1
		uci delete firewall.wifiewan3 > /dev/null 2>&1
		uci delete firewall.wifiewan4 > /dev/null 2>&1
		uci delete firewall.wifiewan5 > /dev/null 2>&1
		uci delete firewall.wificwan1 > /dev/null 2>&1
		uci delete firewall.wificwan1_0 > /dev/null 2>&1
		uci delete firewall.wificwan1_1 > /dev/null 2>&1
		uci delete firewall.wificwan2 > /dev/null 2>&1
		uci delete firewall.wifi5ewan1 > /dev/null 2>&1
		uci delete firewall.wifi5ewan2 > /dev/null 2>&1
		uci delete firewall.wifi5ewan3 > /dev/null 2>&1
		uci delete firewall.wifi5ewan4 > /dev/null 2>&1
		uci delete firewall.wifi5ewan5 > /dev/null 2>&1
		uci delete firewall.wifi5cwan1 > /dev/null 2>&1
		uci delete firewall.wifi5cwan1_0 > /dev/null 2>&1
		uci delete firewall.wifi5cwan1_1 > /dev/null 2>&1
		uci delete firewall.wifi5cwan2 > /dev/null 2>&1
	fi
	uci commit firewall
	ubus call firewall reload
}

UpdateInternetOverInterface()
{
	if [ "$InternetoverSwLan" = "0" ]                                                                         
	then                                                                                                           
		if [ "$Port1Mode" = "EWAN1" ]
		then
			uci set firewall.block_sw_lan_ewan1=rule > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan1.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan1.proto='all' > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan1.src='SW_LAN' > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan1.target='DROP' > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan1.dest='EWAN1' > /dev/null 2>&1
		else
			uci delete firewall.block_sw_lan_ewan1 > /dev/null 2>&1
		fi
		if [ "$Port2Mode" = "EWAN2" ]
		then
			uci set firewall.block_sw_lan_ewan2=rule > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan2.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan2.proto='all' > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan2.src='SW_LAN' > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan2.target='DROP' > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan2.dest='EWAN2' > /dev/null 2>&1
		else
			uci delete firewall.block_sw_lan_ewan2 > /dev/null 2>&1
		fi 
		if [ "$Port3Mode" = "EWAN3" ]
		then
			uci set firewall.block_sw_lan_ewan3=rule > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan3.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan3.proto='all' > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan3.src='SW_LAN' > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan3.target='DROP' > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan3.dest='EWAN3' > /dev/null 2>&1
		else
			uci delete firewall.block_sw_lan_ewan3 > /dev/null 2>&1
		fi 
		if [ "$Port4Mode" = "EWAN4" ]
		then
			uci set firewall.block_sw_lan_ewan4=rule > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan4.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan4.proto='all' > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan4.src='SW_LAN' > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan4.target='DROP' > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan4.dest='EWAN4' > /dev/null 2>&1
		else
			uci delete firewall.block_sw_lan_ewan4 > /dev/null 2>&1
		fi 
		if [ "$Port5Mode" = "EWAN5" ]
		then
			uci set firewall.block_sw_lan_ewan5=rule > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan5.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan5.proto='all' > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan5.src='SW_LAN' > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan5.target='DROP' > /dev/null 2>&1
			uci set firewall.block_sw_lan_ewan5.dest='EWAN5' > /dev/null 2>&1
		else
			uci delete firewall.block_sw_lan_ewan5 > /dev/null 2>&1
		fi                                        
		if [ "$EnableCellular" = "1" ]
		then
			if [ "$CellularOperationModelocal" = "dualcellularsinglesim" ]
			then 
				uci set firewall.block_sw_lan_cwan1=rule > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan1.family='ipv4' > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan1.proto='all' > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan1.src='SW_LAN' > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan1.target='DROP' > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan1.dest='CWAN1' > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan2=rule > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan2.family='ipv4' > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan2.proto='all' > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan2.src='SW_LAN' > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan2.target='DROP' > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan2.dest='CWAN2' > /dev/null 2>&1
			else
				uci delete firewall.block_sw_lan_cwan1 > /dev/null 2>&1
				uci delete firewall.block_sw_lan_cwan2 > /dev/null 2>&1
			fi    
			if [ "$CellularOperationModelocal" = "singlecellulardualsim" ]
			then
				uci set firewall.block_sw_lan_cwan1_0=rule > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan1_0.family='ipv4' > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan1_0.proto='all' > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan1_0.src='SW_LAN' > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan1_0.target='DROP' > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan1_0.dest='CWAN1_0' > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan1_1=rule > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan1_1.family='ipv4' > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan1_1.proto='all' > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan1_1.src='SW_LAN' > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan1_1.target='DROP' > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan1_1.dest='CWAN1_1' > /dev/null 2>&1
			else
				uci delete firewall.block_sw_lan_cwan1_0 > /dev/null 2>&1
				uci delete firewall.block_sw_lan_cwan1_1 > /dev/null 2>&1		
			fi
			if [ "$CellularOperationModelocal" = "singlecellularsinglesim" ]
			then
				uci set firewall.block_sw_lan_cwan1=rule > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan1.family='ipv4' > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan1.proto='all' > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan1.src='SW_LAN' > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan1.target='DROP' > /dev/null 2>&1
				uci set firewall.block_sw_lan_cwan1.dest='CWAN1' > /dev/null 2>&1
			fi
		else
			uci delete firewall.block_sw_lan_cwan1 > /dev/null 2>&1
			uci delete firewall.block_sw_lan_cwan2 > /dev/null 2>&1    
			uci delete firewall.block_sw_lan_cwan1_0 > /dev/null 2>&1
			uci delete firewall.block_sw_lan_cwan1_1 > /dev/null 2>&1	    
		fi
	else
		uci delete firewall.block_sw_lan_ewan1 > /dev/null 2>&1
		uci delete firewall.block_sw_lan_ewan2 > /dev/null 2>&1  
		uci delete firewall.block_sw_lan_ewan3 > /dev/null 2>&1  
		uci delete firewall.block_sw_lan_ewan4 > /dev/null 2>&1  
		uci delete firewall.block_sw_lan_ewan5 > /dev/null 2>&1  
		uci delete firewall.block_sw_lan_cwan1 > /dev/null 2>&1
		uci delete firewall.block_sw_lan_cwan2 > /dev/null 2>&1    
		uci delete firewall.block_sw_lan_cwan1_0 > /dev/null 2>&1
		uci delete firewall.block_sw_lan_cwan1_1 > /dev/null 2>&1
	fi

	if [ "$Port1InternetOverLan" = "0" ]                                                                         
	then                                                                                                           
		if [ "$Port2Mode" = "EWAN2" ]
		then
			uci set firewall.block_lan1_ewan2=rule > /dev/null 2>&1
			uci set firewall.block_lan1_ewan2.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_lan1_ewan2.proto='all' > /dev/null 2>&1
			uci set firewall.block_lan1_ewan2.src='LAN1' > /dev/null 2>&1
			uci set firewall.block_lan1_ewan2.target='DROP' > /dev/null 2>&1
			uci set firewall.block_lan1_ewan2.dest='EWAN2' > /dev/null 2>&1
		else
			uci delete firewall.block_lan1_ewan2 > /dev/null 2>&1
		fi
		if [ "$Port3Mode" = "EWAN3" ]
		then
			uci set firewall.block_lan1_ewan3=rule > /dev/null 2>&1
			uci set firewall.block_lan1_ewan3.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_lan1_ewan3.proto='all' > /dev/null 2>&1
			uci set firewall.block_lan1_ewan3.src='LAN1' > /dev/null 2>&1
			uci set firewall.block_lan1_ewan3.target='DROP' > /dev/null 2>&1
			uci set firewall.block_lan1_ewan3.dest='EWAN3' > /dev/null 2>&1
		else
			uci delete firewall.block_lan1_ewan3 > /dev/null 2>&1
		fi     
		if [ "$Port4Mode" = "EWAN4" ]
		then
			uci set firewall.block_lan1_ewan4=rule > /dev/null 2>&1
			uci set firewall.block_lan1_ewan4.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_lan1_ewan4.proto='all' > /dev/null 2>&1
			uci set firewall.block_lan1_ewan4.src='LAN1' > /dev/null 2>&1
			uci set firewall.block_lan1_ewan4.target='DROP' > /dev/null 2>&1
			uci set firewall.block_lan1_ewan4.dest='EWAN4' > /dev/null 2>&1
		else
			uci delete firewall.block_lan1_ewan4 > /dev/null 2>&1
		fi     
		if [ "$Port5Mode" = "EWAN5" ]
		then
			uci set firewall.block_lan1_ewan5=rule > /dev/null 2>&1
			uci set firewall.block_lan1_ewan5.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_lan1_ewan5.proto='all' > /dev/null 2>&1
			uci set firewall.block_lan1_ewan5.src='LAN1' > /dev/null 2>&1
			uci set firewall.block_lan1_ewan5.target='DROP' > /dev/null 2>&1
			uci set firewall.block_lan1_ewan5.dest='EWAN5' > /dev/null 2>&1
		else
			uci delete firewall.block_lan1_ewan5 > /dev/null 2>&1
		fi                                        
		if [ "$EnableCellular" = "1" ]
		then
			if [ "$CellularOperationModelocal" = "dualcellularsinglesim" ]
			then 
				uci set firewall.block_lan1_cwan1=rule > /dev/null 2>&1
				uci set firewall.block_lan1_cwan1.family='ipv4' > /dev/null 2>&1
				uci set firewall.block_lan1_cwan1.proto='all' > /dev/null 2>&1
				uci set firewall.block_lan1_cwan1.src='LAN1' > /dev/null 2>&1
				uci set firewall.block_lan1_cwan1.target='DROP' > /dev/null 2>&1
				uci set firewall.block_lan1_cwan1.dest='CWAN1' > /dev/null 2>&1
				uci set firewall.block_lan1_cwan2=rule > /dev/null 2>&1
				uci set firewall.block_lan1_cwan2.family='ipv4' > /dev/null 2>&1
				uci set firewall.block_lan1_cwan2.proto='all' > /dev/null 2>&1
				uci set firewall.block_lan1_cwan2.src='LAN1' > /dev/null 2>&1
				uci set firewall.block_lan1_cwan2.target='DROP' > /dev/null 2>&1
				uci set firewall.block_lan1_cwan2.dest='CWAN2' > /dev/null 2>&1
			else
				uci delete firewall.block_lan1_cwan1 > /dev/null 2>&1
				uci delete firewall.block_lan1_cwan2 > /dev/null 2>&1
			fi    
			if [ "$CellularOperationModelocal" = "singlecellulardualsim" ]
			then
				uci set firewall.block_lan1_cwan1_0=rule > /dev/null 2>&1
				uci set firewall.block_lan1_cwan1_0.family='ipv4' > /dev/null 2>&1
				uci set firewall.block_lan1_cwan1_0.proto='all' > /dev/null 2>&1
				uci set firewall.block_lan1_cwan1_0.src='LAN1' > /dev/null 2>&1
				uci set firewall.block_lan1_cwan1_0.target='DROP' > /dev/null 2>&1
				uci set firewall.block_lan1_cwan1_0.dest='CWAN1_0' > /dev/null 2>&1
				uci set firewall.block_lan1_cwan1_1=rule > /dev/null 2>&1
				uci set firewall.block_lan1_cwan1_1.family='ipv4' > /dev/null 2>&1
				uci set firewall.block_lan1_cwan1_1.proto='all' > /dev/null 2>&1
				uci set firewall.block_lan1_cwan1_1.src='LAN1' > /dev/null 2>&1
				uci set firewall.block_lan1_cwan1_1.target='DROP' > /dev/null 2>&1
				uci set firewall.block_lan1_cwan1_1.dest='CWAN1_1' > /dev/null 2>&1
			else
				uci delete firewall.block_lan1_cwan1_0 > /dev/null 2>&1
				uci delete firewall.block_lan1_cwan1_1 > /dev/null 2>&1		
			fi
			if [ "$CellularOperationModelocal" = "singlecellularsinglesim" ]
			then
				uci set firewall.block_lan1_cwan1=rule > /dev/null 2>&1
				uci set firewall.block_lan1_cwan1.family='ipv4' > /dev/null 2>&1
				uci set firewall.block_lan1_cwan1.proto='all' > /dev/null 2>&1
				uci set firewall.block_lan1_cwan1.src='LAN1' > /dev/null 2>&1
				uci set firewall.block_lan1_cwan1.target='DROP' > /dev/null 2>&1
				uci set firewall.block_lan1_cwan1.dest='CWAN1' > /dev/null 2>&1
			fi
		else
			uci delete firewall.block_lan1_cwan1 > /dev/null 2>&1
			uci delete firewall.block_lan1_cwan2 > /dev/null 2>&1    
			uci delete firewall.block_lan1_cwan1_0 > /dev/null 2>&1
			uci delete firewall.block_lan1_cwan1_1 > /dev/null 2>&1	   
		fi
	else
		uci delete firewall.block_lan1_ewan2 > /dev/null 2>&1  
		uci delete firewall.block_lan1_ewan3 > /dev/null 2>&1  
		uci delete firewall.block_lan1_ewan4 > /dev/null 2>&1  
		uci delete firewall.block_lan1_ewan5 > /dev/null 2>&1  
		uci delete firewall.block_lan1_cwan1 > /dev/null 2>&1
		uci delete firewall.block_lan1_cwan2 > /dev/null 2>&1    
		uci delete firewall.block_lan1_cwan1_0 > /dev/null 2>&1
		uci delete firewall.block_lan1_cwan1_1 > /dev/null 2>&1
	fi 
  
	if [ "$Port2InternetOverLan" = "0" ]                                                                         
	then                                                                                                           
		if [ "$Port1Mode" = "EWAN1" ]
		then
			uci set firewall.block_lan2_ewan1=rule > /dev/null 2>&1
			uci set firewall.block_lan2_ewan1.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_lan2_ewan1.proto='all' > /dev/null 2>&1
			uci set firewall.block_lan2_ewan1.src='LAN2' > /dev/null 2>&1
			uci set firewall.block_lan2_ewan1.target='DROP' > /dev/null 2>&1
			uci set firewall.block_lan2_ewan1.dest='EWAN1' > /dev/null 2>&1
		else
			uci delete firewall.block_lan2_ewan1 > /dev/null 2>&1
		fi
		if [ "$Port3Mode" = "EWAN3" ]
		then
			uci set firewall.block_lan2_ewan3=rule > /dev/null 2>&1
			uci set firewall.block_lan2_ewan3.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_lan2_ewan3.proto='all' > /dev/null 2>&1
			uci set firewall.block_lan2_ewan3.src='LAN2' > /dev/null 2>&1
			uci set firewall.block_lan2_ewan3.target='DROP' > /dev/null 2>&1
			uci set firewall.block_lan2_ewan3.dest='EWAN3' > /dev/null 2>&1
		else
			uci delete firewall.block_lan2_ewan3 > /dev/null 2>&1
		fi     
		if [ "$Port4Mode" = "EWAN4" ]
		then
			uci set firewall.block_lan2_ewan4=rule > /dev/null 2>&1
			uci set firewall.block_lan2_ewan4.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_lan2_ewan4.proto='all' > /dev/null 2>&1
			uci set firewall.block_lan2_ewan4.src='LAN2' > /dev/null 2>&1
			uci set firewall.block_lan2_ewan4.target='DROP' > /dev/null 2>&1
			uci set firewall.block_lan2_ewan4.dest='EWAN4' > /dev/null 2>&1
		else
			uci delete firewall.block_lan2_ewan4 > /dev/null 2>&1
		fi     
		if [ "$Port5Mode" = "EWAN5" ]
		then
			uci set firewall.block_lan2_ewan5=rule > /dev/null 2>&1
			uci set firewall.block_lan2_ewan5.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_lan2_ewan5.proto='all' > /dev/null 2>&1
			uci set firewall.block_lan2_ewan5.src='LAN2' > /dev/null 2>&1
			uci set firewall.block_lan2_ewan5.target='DROP' > /dev/null 2>&1
			uci set firewall.block_lan2_ewan5.dest='EWAN5' > /dev/null 2>&1
		else
			uci delete firewall.block_lan2_ewan5 > /dev/null 2>&1
		fi                                         
	if [ "$EnableCellular" = "1" ]
    then
		if [ "$CellularOperationModelocal" = "dualcellularsinglesim" ]
		then 
		   uci set firewall.block_lan2_cwan1=rule > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan1.family='ipv4' > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan1.proto='all' > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan1.src='LAN2' > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan1.target='DROP' > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan1.dest='CWAN1' > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan2=rule > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan2.family='ipv4' > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan2.proto='all' > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan2.src='LAN2' > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan2.target='DROP' > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan2.dest='CWAN2' > /dev/null 2>&1
		else
		   uci delete firewall.block_lan2_cwan1 > /dev/null 2>&1
		   uci delete firewall.block_lan2_cwan2 > /dev/null 2>&1
		fi    
	    if [ "$CellularOperationModelocal" = "singlecellulardualsim" ]
		then
		   uci set firewall.block_lan2_cwan1_0=rule > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan1_0.family='ipv4' > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan1_0.proto='all' > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan1_0.src='LAN2' > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan1_0.target='DROP' > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan1_0.dest='CWAN1_0' > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan1_1=rule > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan1_1.family='ipv4' > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan1_1.proto='all' > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan1_1.src='LAN2' > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan1_1.target='DROP' > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan1_1.dest='CWAN1_1' > /dev/null 2>&1
		else
		   uci delete firewall.block_lan2_cwan1_0 > /dev/null 2>&1
		   uci delete firewall.block_lan2_cwan1_1 > /dev/null 2>&1		
		fi
	    if [ "$CellularOperationModelocal" = "singlecellularsinglesim" ]
		then
		   uci set firewall.block_lan2_cwan1=rule > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan1.family='ipv4' > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan1.proto='all' > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan1.src='LAN2' > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan1.target='DROP' > /dev/null 2>&1
		   uci set firewall.block_lan2_cwan1.dest='CWAN1' > /dev/null 2>&1
		fi
	else
	  uci delete firewall.block_lan2_cwan1 > /dev/null 2>&1
	  uci delete firewall.block_lan2_cwan2 > /dev/null 2>&1    
	  uci delete firewall.block_lan2_cwan1_0 > /dev/null 2>&1
	  uci delete firewall.block_lan2_cwan1_1 > /dev/null 2>&1	   
	fi
   else
      uci delete firewall.block_lan2_ewan1 > /dev/null 2>&1  
      uci delete firewall.block_lan2_ewan3 > /dev/null 2>&1  
      uci delete firewall.block_lan2_ewan4 > /dev/null 2>&1  
      uci delete firewall.block_lan2_ewan5 > /dev/null 2>&1  
	  uci delete firewall.block_lan2_cwan1 > /dev/null 2>&1
	  uci delete firewall.block_lan2_cwan2 > /dev/null 2>&1    
	  uci delete firewall.block_lan2_cwan1_0 > /dev/null 2>&1
	  uci delete firewall.block_lan2_cwan1_1 > /dev/null 2>&1
   fi 
  
	if [ "$Port3InternetOverLan" = "0" ]                                                                         
	then
		if [ "$Port1Mode" = "EWAN1" ]
		then
			uci set firewall.block_lan3_ewan1=rule > /dev/null 2>&1
			uci set firewall.block_lan3_ewan1.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_lan3_ewan1.proto='all' > /dev/null 2>&1
			uci set firewall.block_lan3_ewan1.src='LAN3' > /dev/null 2>&1
			uci set firewall.block_lan3_ewan1.target='DROP' > /dev/null 2>&1
			uci set firewall.block_lan3_ewan1.dest='EWAN1' > /dev/null 2>&1
		else
			uci delete firewall.block_lan3_ewan1 > /dev/null 2>&1
		fi                                                                                                           
		if [ "$Port2Mode" = "EWAN2" ]
		then
			uci set firewall.block_lan3_ewan2=rule > /dev/null 2>&1
			uci set firewall.block_lan3_ewan2.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_lan3_ewan2.proto='all' > /dev/null 2>&1
			uci set firewall.block_lan3_ewan2.src='LAN3' > /dev/null 2>&1
			uci set firewall.block_lan3_ewan2.target='DROP' > /dev/null 2>&1
			uci set firewall.block_lan3_ewan2.dest='EWAN2' > /dev/null 2>&1
		else
			uci delete firewall.block_lan3_ewan2 > /dev/null 2>&1
		fi    
		if [ "$Port4Mode" = "EWAN4" ]
		then
			uci set firewall.block_lan3_ewan4=rule > /dev/null 2>&1
			uci set firewall.block_lan3_ewan4.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_lan3_ewan4.proto='all' > /dev/null 2>&1
			uci set firewall.block_lan3_ewan4.src='LAN3' > /dev/null 2>&1
			uci set firewall.block_lan3_ewan4.target='DROP' > /dev/null 2>&1
			uci set firewall.block_lan3_ewan4.dest='EWAN4' > /dev/null 2>&1
		else
			uci delete firewall.block_lan3_ewan4 > /dev/null 2>&1
		fi     
		if [ "$Port5Mode" = "EWAN5" ]
		then
			uci set firewall.block_lan3_ewan5=rule > /dev/null 2>&1
			uci set firewall.block_lan3_ewan5.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_lan3_ewan5.proto='all' > /dev/null 2>&1
			uci set firewall.block_lan3_ewan5.src='LAN3' > /dev/null 2>&1
			uci set firewall.block_lan3_ewan5.target='DROP' > /dev/null 2>&1
			uci set firewall.block_lan3_ewan5.dest='EWAN5' > /dev/null 2>&1
		else
			uci delete firewall.block_lan3_ewan5 > /dev/null 2>&1
		fi                                        
	if [ "$EnableCellular" = "1" ]
    then
		if [ "$CellularOperationModelocal" = "dualcellularsinglesim" ]
		then 
		   uci set firewall.block_lan3_cwan1=rule > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan1.family='ipv4' > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan1.proto='all' > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan1.src='LAN3' > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan1.target='DROP' > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan1.dest='CWAN1' > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan2=rule > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan2.family='ipv4' > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan2.proto='all' > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan2.src='LAN3' > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan2.target='DROP' > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan2.dest='CWAN2' > /dev/null 2>&1
		else
		   uci delete firewall.block_lan3_cwan1 > /dev/null 2>&1
		   uci delete firewall.block_lan3_cwan2 > /dev/null 2>&1
		fi    
	    if [ "$CellularOperationModelocal" = "singlecellulardualsim" ]
		then
		   uci set firewall.block_lan3_cwan1_0=rule > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan1_0.family='ipv4' > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan1_0.proto='all' > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan1_0.src='LAN3' > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan1_0.target='DROP' > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan1_0.dest='CWAN1_0' > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan1_1=rule > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan1_1.family='ipv4' > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan1_1.proto='all' > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan1_1.src='LAN3' > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan1_1.target='DROP' > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan1_1.dest='CWAN1_1' > /dev/null 2>&1
		else
		   uci delete firewall.block_lan3_cwan1_0 > /dev/null 2>&1
		   uci delete firewall.block_lan3_cwan1_1 > /dev/null 2>&1		
		fi
	    if [ "$CellularOperationModelocal" = "singlecellularsinglesim" ]
		then
		   uci set firewall.block_lan3_cwan1=rule > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan1.family='ipv4' > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan1.proto='all' > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan1.src='LAN3' > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan1.target='DROP' > /dev/null 2>&1
		   uci set firewall.block_lan3_cwan1.dest='CWAN1' > /dev/null 2>&1
		fi
	else
	  uci delete firewall.block_lan3_cwan1 > /dev/null 2>&1
	  uci delete firewall.block_lan3_cwan2 > /dev/null 2>&1    
	  uci delete firewall.block_lan3_cwan1_0 > /dev/null 2>&1
	  uci delete firewall.block_lan3_cwan1_1 > /dev/null 2>&1	   
	fi
   else
      uci delete firewall.block_lan3_ewan1 > /dev/null 2>&1
      uci delete firewall.block_lan3_ewan2 > /dev/null 2>&1    
      uci delete firewall.block_lan3_ewan4 > /dev/null 2>&1  
      uci delete firewall.block_lan3_ewan5 > /dev/null 2>&1  
	  uci delete firewall.block_lan3_cwan1 > /dev/null 2>&1
	  uci delete firewall.block_lan3_cwan2 > /dev/null 2>&1    
	  uci delete firewall.block_lan3_cwan1_0 > /dev/null 2>&1
	  uci delete firewall.block_lan3_cwan1_1 > /dev/null 2>&1
   fi 
  
	if [ "$Port4InternetOverLan" = "0" ]                                                                         
	then 
		if [ "$Port1Mode" = "EWAN1" ]
		then
			uci set firewall.block_lan4_ewan1=rule > /dev/null 2>&1
			uci set firewall.block_lan4_ewan1.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_lan4_ewan1.proto='all' > /dev/null 2>&1
			uci set firewall.block_lan4_ewan1.src='LAN3' > /dev/null 2>&1
			uci set firewall.block_lan4_ewan1.target='DROP' > /dev/null 2>&1
			uci set firewall.block_lan4_ewan1.dest='EWAN1' > /dev/null 2>&1
		else
			uci delete firewall.block_lan3_ewan1 > /dev/null 2>&1
		fi                                                                                                          
		if [ "$Port2Mode" = "EWAN2" ]
		then
			uci set firewall.block_lan4_ewan2=rule > /dev/null 2>&1
			uci set firewall.block_lan4_ewan2.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_lan4_ewan2.proto='all' > /dev/null 2>&1
			uci set firewall.block_lan4_ewan2.src='LAN4' > /dev/null 2>&1
			uci set firewall.block_lan4_ewan2.target='DROP' > /dev/null 2>&1
			uci set firewall.block_lan4_ewan2.dest='EWAN2' > /dev/null 2>&1
		else
			uci delete firewall.block_lan4_ewan2 > /dev/null 2>&1
		fi
		if [ "$Port3Mode" = "EWAN3" ]
		then
			uci set firewall.block_lan4_ewan3=rule > /dev/null 2>&1
			uci set firewall.block_lan4_ewan3.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_lan4_ewan3.proto='all' > /dev/null 2>&1
			uci set firewall.block_lan4_ewan3.src='LAN4' > /dev/null 2>&1
			uci set firewall.block_lan4_ewan3.target='DROP' > /dev/null 2>&1
			uci set firewall.block_lan4_ewan3.dest='EWAN3' > /dev/null 2>&1
		else
			uci delete firewall.block_lan4_ewan3 > /dev/null 2>&1
		fi       
		if [ "$Port5Mode" = "EWAN5" ]
		then
			uci set firewall.block_lan4_ewan5=rule > /dev/null 2>&1
			uci set firewall.block_lan4_ewan5.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_lan4_ewan5.proto='all' > /dev/null 2>&1
			uci set firewall.block_lan4_ewan5.src='LAN4' > /dev/null 2>&1
			uci set firewall.block_lan4_ewan5.target='DROP' > /dev/null 2>&1
			uci set firewall.block_lan4_ewan5.dest='EWAN5' > /dev/null 2>&1
		else
			uci delete firewall.block_lan4_ewan5 > /dev/null 2>&1
		fi                                          
		if [ "$EnableCellular" = "1" ]
		then
			if [ "$CellularOperationModelocal" = "dualcellularsinglesim" ]
			then 
			   uci set firewall.block_lan4_cwan1=rule > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan1.family='ipv4' > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan1.proto='all' > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan1.src='LAN4' > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan1.target='DROP' > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan1.dest='CWAN1' > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan2=rule > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan2.family='ipv4' > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan2.proto='all' > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan2.src='LAN4' > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan2.target='DROP' > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan2.dest='CWAN2' > /dev/null 2>&1
			else
			   uci delete firewall.block_lan4_cwan1 > /dev/null 2>&1
			   uci delete firewall.block_lan4_cwan2 > /dev/null 2>&1
			fi    
			if [ "$CellularOperationModelocal" = "singlecellulardualsim" ]
			then
			   uci set firewall.block_lan4_cwan1_0=rule > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan1_0.family='ipv4' > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan1_0.proto='all' > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan1_0.src='LAN4' > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan1_0.target='DROP' > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan1_0.dest='CWAN1_0' > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan1_1=rule > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan1_1.family='ipv4' > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan1_1.proto='all' > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan1_1.src='LAN4' > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan1_1.target='DROP' > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan1_1.dest='CWAN1_1' > /dev/null 2>&1
			else
			   uci delete firewall.block_lan4_cwan1_0 > /dev/null 2>&1
			   uci delete firewall.block_lan4_cwan1_1 > /dev/null 2>&1		
			fi
			if [ "$CellularOperationModelocal" = "singlecellularsinglesim" ]
			then
			   uci set firewall.block_lan4_cwan1=rule > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan1.family='ipv4' > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan1.proto='all' > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan1.src='LAN4' > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan1.target='DROP' > /dev/null 2>&1
			   uci set firewall.block_lan4_cwan1.dest='CWAN1' > /dev/null 2>&1
			fi
		else
			uci delete firewall.block_lan4_cwan1 > /dev/null 2>&1
			uci delete firewall.block_lan4_cwan2 > /dev/null 2>&1    
			uci delete firewall.block_lan4_cwan1_0 > /dev/null 2>&1
			uci delete firewall.block_lan4_cwan1_1 > /dev/null 2>&1	   
		fi
   else
      uci delete firewall.block_lan4_ewan1 > /dev/null 2>&1
      uci delete firewall.block_lan4_ewan2 > /dev/null 2>&1  
      uci delete firewall.block_lan4_ewan3 > /dev/null 2>&1  
      uci delete firewall.block_lan4_ewan5 > /dev/null 2>&1  
	  uci delete firewall.block_lan4_cwan1 > /dev/null 2>&1
	  uci delete firewall.block_lan4_cwan2 > /dev/null 2>&1    
	  uci delete firewall.block_lan4_cwan1_0 > /dev/null 2>&1
	  uci delete firewall.block_lan4_cwan1_1 > /dev/null 2>&1
   fi 
  
	if [ "$Port5InternetOverLan" = "0" ]                                                                         
	then
		if [ "$Port1Mode" = "EWAN1" ]
		then
			uci set firewall.block_lan5_ewan1=rule > /dev/null 2>&1
			uci set firewall.block_lan5_ewan1.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_lan5_ewan1.proto='all' > /dev/null 2>&1
			uci set firewall.block_lan5_ewan1.src='LAN5' > /dev/null 2>&1
			uci set firewall.block_lan5_ewan1.target='DROP' > /dev/null 2>&1
			uci set firewall.block_lan5_ewan1.dest='EWAN1' > /dev/null 2>&1
		else
			uci delete firewall.block_lan3_ewan1 > /dev/null 2>&1
		fi                                                                                                           
		if [ "$Port2Mode" = "EWAN2" ]
		then
			uci set firewall.block_lan5_ewan2=rule > /dev/null 2>&1
			uci set firewall.block_lan5_ewan2.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_lan5_ewan2.proto='all' > /dev/null 2>&1
			uci set firewall.block_lan5_ewan2.src='LAN5' > /dev/null 2>&1
			uci set firewall.block_lan5_ewan2.target='DROP' > /dev/null 2>&1
			uci set firewall.block_lan5_ewan2.dest='EWAN2' > /dev/null 2>&1
		else
			uci delete firewall.block_lan5_ewan2 > /dev/null 2>&1
		fi
		if [ "$Port3Mode" = "EWAN3" ]
		then
			uci set firewall.block_lan5_ewan3=rule > /dev/null 2>&1
			uci set firewall.block_lan5_ewan3.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_lan5_ewan3.proto='all' > /dev/null 2>&1
			uci set firewall.block_lan5_ewan3.src='LAN5' > /dev/null 2>&1
			uci set firewall.block_lan5_ewan3.target='DROP' > /dev/null 2>&1
			uci set firewall.block_lan5_ewan3.dest='EWAN3' > /dev/null 2>&1
		else
			uci delete firewall.block_lan5_ewan3 > /dev/null 2>&1
		fi     
		if [ "$Port4Mode" = "EWAN4" ]
		then
			uci set firewall.block_lan5_ewan4=rule > /dev/null 2>&1
			uci set firewall.block_lan5_ewan4.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_lan5_ewan4.proto='all' > /dev/null 2>&1
			uci set firewall.block_lan5_ewan4.src='LAN5' > /dev/null 2>&1
			uci set firewall.block_lan5_ewan4.target='DROP' > /dev/null 2>&1
			uci set firewall.block_lan5_ewan4.dest='EWAN4' > /dev/null 2>&1
		else
			uci delete firewall.block_lan5_ewan4 > /dev/null 2>&1
		fi                                            
		if [ "$EnableCellular" = "1" ]
		then
			if [ "$CellularOperationModelocal" = "dualcellularsinglesim" ]
			then 
			   uci set firewall.block_lan5_cwan1=rule > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan1.family='ipv4' > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan1.proto='all' > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan1.src='LAN5' > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan1.target='DROP' > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan1.dest='CWAN1' > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan2=rule > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan2.family='ipv4' > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan2.proto='all' > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan2.src='LAN5' > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan2.target='DROP' > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan2.dest='CWAN2' > /dev/null 2>&1
			else
			   uci delete firewall.block_lan5_cwan1 > /dev/null 2>&1
			   uci delete firewall.block_lan5_cwan2 > /dev/null 2>&1
			fi    
			if [ "$CellularOperationModelocal" = "singlecellulardualsim" ]
			then
			   uci set firewall.block_lan5_cwan1_0=rule > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan1_0.family='ipv4' > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan1_0.proto='all' > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan1_0.src='LAN5' > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan1_0.target='DROP' > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan1_0.dest='CWAN1_0' > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan1_1=rule > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan1_1.family='ipv4' > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan1_1.proto='all' > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan1_1.src='LAN5' > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan1_1.target='DROP' > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan1_1.dest='CWAN1_1' > /dev/null 2>&1
			else
			   uci delete firewall.block_lan5_cwan1_0 > /dev/null 2>&1
			   uci delete firewall.block_lan5_cwan1_1 > /dev/null 2>&1		
			fi
			if [ "$CellularOperationModelocal" = "singlecellularsinglesim" ]
			then
			   uci set firewall.block_lan5_cwan1=rule > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan1.family='ipv4' > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan1.proto='all' > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan1.src='LAN5' > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan1.target='DROP' > /dev/null 2>&1
			   uci set firewall.block_lan5_cwan1.dest='CWAN1' > /dev/null 2>&1
			fi
		else
		  uci delete firewall.block_lan5_cwan1 > /dev/null 2>&1
		  uci delete firewall.block_lan5_cwan2 > /dev/null 2>&1    
		  uci delete firewall.block_lan5_cwan1_0 > /dev/null 2>&1
		  uci delete firewall.block_lan5_cwan1_1 > /dev/null 2>&1	   
		fi
   else
      uci delete firewall.block_lan5_ewan1 > /dev/null 2>&1
      uci delete firewall.block_lan5_ewan2 > /dev/null 2>&1  
      uci delete firewall.block_lan5_ewan3 > /dev/null 2>&1  
      uci delete firewall.block_lan5_ewan4 > /dev/null 2>&1  
	  uci delete firewall.block_lan5_cwan1 > /dev/null 2>&1
	  uci delete firewall.block_lan5_cwan2 > /dev/null 2>&1    
	  uci delete firewall.block_lan5_cwan1_0 > /dev/null 2>&1
	  uci delete firewall.block_lan5_cwan1_1 > /dev/null 2>&1
   fi 
   
	if [ "$InternetOverWifi" = "0" ]                                                                         
	then 
		if [ "$Port1Mode" = "EWAN1" ]
		then
			uci set firewall.block_wifi_ewan1=rule > /dev/null 2>&1
			uci set firewall.block_wifi_ewan1.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_wifi_ewan1.proto='all' > /dev/null 2>&1
			uci set firewall.block_wifi_ewan1.src='wifi' > /dev/null 2>&1
			uci set firewall.block_wifi_ewan1.target='DROP' > /dev/null 2>&1
			uci set firewall.block_wifi_ewan1.dest='EWAN1' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan1=rule > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan1.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan1.proto='all' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan1.src='wifi5' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan1.target='DROP' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan1.dest='EWAN1' > /dev/null 2>&1
		else
			uci delete firewall.block_wifi_ewan1 > /dev/null 2>&1
			uci delete firewall.block_wifi5_ewan1 > /dev/null 2>&1
		fi                                                                                                           
		if [ "$Port2Mode" = "EWAN2" ]
		then
			uci set firewall.block_wifi_ewan2=rule > /dev/null 2>&1
			uci set firewall.block_wifi_ewan2.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_wifi_ewan2.proto='all' > /dev/null 2>&1
			uci set firewall.block_wifi_ewan2.src='wifi' > /dev/null 2>&1
			uci set firewall.block_wifi_ewan2.target='DROP' > /dev/null 2>&1
			uci set firewall.block_wifi_ewan2.dest='EWAN2' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan2=rule > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan2.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan2.proto='all' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan2.src='wifi5' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan2.target='DROP' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan2.dest='EWAN2' > /dev/null 2>&1
		else
			uci delete firewall.block_wifi_ewan2 > /dev/null 2>&1
			uci delete firewall.block_wifi5_ewan2 > /dev/null 2>&1
		fi
		if [ "$Port3Mode" = "EWAN3" ]
		then
			uci set firewall.block_wifi_ewan3=rule > /dev/null 2>&1
			uci set firewall.block_wifi_ewan3.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_wifi_ewan3.proto='all' > /dev/null 2>&1
			uci set firewall.block_wifi_ewan3.src='wifi' > /dev/null 2>&1
			uci set firewall.block_wifi_ewan3.target='DROP' > /dev/null 2>&1
			uci set firewall.block_wifi_ewan3.dest='EWAN3' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan3=rule > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan3.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan3.proto='all' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan3.src='wifi5' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan3.target='DROP' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan3.dest='EWAN3' > /dev/null 2>&1
		else
			uci delete firewall.block_wifi_ewan3 > /dev/null 2>&1
			uci delete firewall.block_wifi5_ewan3 > /dev/null 2>&1
		fi     
		if [ "$Port4Mode" = "EWAN4" ]
		then
			uci set firewall.block_wifi_ewan4=rule > /dev/null 2>&1
			uci set firewall.block_wifi_ewan4.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_wifi_ewan4.proto='all' > /dev/null 2>&1
			uci set firewall.block_wifi_ewan4.src='wifi' > /dev/null 2>&1
			uci set firewall.block_wifi_ewan4.target='DROP' > /dev/null 2>&1
			uci set firewall.block_wifi_ewan4.dest='EWAN4' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan4=rule > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan4.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan4.proto='all' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan4.src='wifi5' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan4.target='DROP' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan4.dest='EWAN4' > /dev/null 2>&1
		else
			uci delete firewall.block_wifi_ewan4 > /dev/null 2>&1
			uci delete firewall.block_wifi5_ewan4 > /dev/null 2>&1
		fi 
		if [ "$Port5Mode" = "EWAN5" ]
		then
			uci set firewall.block_wifi_ewan5=rule > /dev/null 2>&1
			uci set firewall.block_wifi_ewan5.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_wifi_ewan5.proto='all' > /dev/null 2>&1
			uci set firewall.block_wifi_ewan5.src='wifi' > /dev/null 2>&1
			uci set firewall.block_wifi_ewan5.target='DROP' > /dev/null 2>&1
			uci set firewall.block_wifi_ewan5.dest='EWAN5' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan5=rule > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan5.family='ipv4' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan5.proto='all' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan5.src='wifi5' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan5.target='DROP' > /dev/null 2>&1
			uci set firewall.block_wifi5_ewan5.dest='EWAN5' > /dev/null 2>&1
		else
			uci delete firewall.block_wifi_ewan5 > /dev/null 2>&1
			uci delete firewall.block_wifi5_ewan5 > /dev/null 2>&1
		fi                                       
		if [ "$EnableCellular" = "1" ]
		then
			if [ "$CellularOperationModelocal" = "dualcellularsinglesim" ]
			then 
				uci set firewall.block_wifi_cwan1=rule > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1.family='ipv4' > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1.proto='all' > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1.src='ra0' > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1.target='DROP' > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1.dest='CWAN1' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan2=rule > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan2.family='ipv4' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan2.proto='all' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan2.src='ra0' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan2.target='DROP' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan2.dest='CWAN2' > /dev/null 2>&1
				
				uci set firewall.block_wifi_cwan1=rule > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1.family='ipv4' > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1.proto='all' > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1.src='rai0' > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1.target='DROP' > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1.dest='CWAN1' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan2=rule > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan2.family='ipv4' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan2.proto='all' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan2.src='rai0' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan2.target='DROP' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan2.dest='CWAN2' > /dev/null 2>&1
			else
				uci delete firewall.block_wifi_cwan1 > /dev/null 2>&1
				uci delete firewall.block_wifi5_cwan1 > /dev/null 2>&1
				uci delete firewall.block_wifi_cwan2 > /dev/null 2>&1
				uci delete firewall.block_wifi5_cwan2 > /dev/null 2>&1
			fi    
			if [ "$CellularOperationModelocal" = "singlecellulardualsim" ]
			then
				uci set firewall.block_wifi_cwan1_0=rule > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1_0.family='ipv4' > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1_0.proto='all' > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1_0.src='ra0' > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1_0.target='DROP' > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1_0.dest='CWAN1_0' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan1_1=rule > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan1_1.family='ipv4' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan1_1.proto='all' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan1_1.src='ra0' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan1_1.target='DROP' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan1_1.dest='CWAN1_1' > /dev/null 2>&1
				
				uci set firewall.block_wifi_cwan1_0=rule > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1_0.family='ipv4' > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1_0.proto='all' > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1_0.src='rai0' > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1_0.target='DROP' > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1_0.dest='CWAN1_0' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan1_1=rule > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan1_1.family='ipv4' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan1_1.proto='all' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan1_1.src='rai0' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan1_1.target='DROP' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan1_1.dest='CWAN1_1' > /dev/null 2>&1
			else
				uci delete firewall.block_wifi_cwan1_0 > /dev/null 2>&1
				uci delete firewall.block_wifi5_cwan1_0 > /dev/null 2>&1
				uci delete firewall.block_wifi_cwan1_1 > /dev/null 2>&1		
				uci delete firewall.block_wifi5_cwan1_1 > /dev/null 2>&1		
			fi
			if [ "$CellularOperationModelocal" = "singlecellularsinglesim" ]
			then
				uci set firewall.block_wifi_cwan1=rule > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1.family='ipv4' > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1.proto='all' > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1.src='ra0' > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1.target='DROP' > /dev/null 2>&1
				uci set firewall.block_wifi_cwan1.dest='CWAN1' > /dev/null 2>&1
				
				uci set firewall.block_wifi5_cwan1=rule > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan1.family='ipv4' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan1.proto='all' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan1.src='rai0' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan1.target='DROP' > /dev/null 2>&1
				uci set firewall.block_wifi5_cwan1.dest='CWAN1' > /dev/null 2>&1
			fi
		else
			uci delete firewall.block_wifi_cwan1 > /dev/null 2>&1
			uci delete firewall.block_wifi_cwan2 > /dev/null 2>&1    
			uci delete firewall.block_wifi_cwan1_0 > /dev/null 2>&1
			uci delete firewall.block_wifi_cwan1_1 > /dev/null 2>&1	
			uci delete firewall.block_wifi5_cwan1 > /dev/null 2>&1
			uci delete firewall.block_wifi5_cwan2 > /dev/null 2>&1    
			uci delete firewall.block_wifi5_cwan1_0 > /dev/null 2>&1
			uci delete firewall.block_wifi5_cwan1_1 > /dev/null 2>&1	
		fi
	else
		uci delete firewall.block_wifi_ewan1 > /dev/null 2>&1
		uci delete firewall.block_wifi_ewan2 > /dev/null 2>&1  
		uci delete firewall.block_wifi_cwan1 > /dev/null 2>&1
		uci delete firewall.block_wifi_cwan2 > /dev/null 2>&1    
		uci delete firewall.block_wifi_cwan1_0 > /dev/null 2>&1
		uci delete firewall.block_wifi_cwan1_1 > /dev/null 2>&1
		uci delete firewall.block_wifi5_ewan1 > /dev/null 2>&1
		uci delete firewall.block_wifi5_ewan2 > /dev/null 2>&1  
		uci delete firewall.block_wifi5_cwan1 > /dev/null 2>&1
		uci delete firewall.block_wifi5_cwan2 > /dev/null 2>&1    
		uci delete firewall.block_wifi5_cwan1_0 > /dev/null 2>&1
		uci delete firewall.block_wifi5_cwan1_1 > /dev/null 2>&1
	fi 
   uci commit firewall
}

Settings_5G()
{

#Settings_5G $autoconfigsim1 $ComPortSymLink1 $networkingmode1 $rattype1 $nsa_bands1 $sa_bands1
#Settings_5G $autoconfigsim2 $ComPortSymLink2 $networkingmode2 $rattype2 $nsa_bands2 $sa_bands2

#autoconfigsim
if [ "$1" = "1" ]
then
	#Set "mode_pref" as AUTO
	gcom -d $2 -s $mode_pref
	
	#Set all the NSA bands 1:2:3:5:7:8:12:20:25:28:38:40:41:48:66:71:77:78:79
	gcom -d $2 -s $nsa_bands
	
	#Set all the SA bands 1:2:3:5:7:8:12:20:25:28:38:40:41:48:66:71:77:78:79
	gcom -d $2 -s $sa_bands
	
	#Set "nr5g_disable_mode" as 0. It means, modem supports both SA & NSA.
	gcom -d $2 -s $nr5g_disable_mode
else
	#Set "nr5g_disable_mode"
	
	{
		echo "opengt"
		echo -e "\tset com 115200n81"
		echo -e "\tset comecho off"
		echo -e "\tset senddelay 0.02"
		echo -e "\twaitquiet 0.2 0.2"
		echo -e "\tflash 0.1"
		echo -e "\n"
		echo ":start"
		echo -e "\tsend \"AT+QNWPREFCFG=\"nr5g_disable_mode\",$3^m\""
		echo -e "\tget 1 \"\" $s"
		echo -e "\tprint \$s"
		echo -e "\n"
		echo ":continue"
		echo -e "\texit 0"
	} > ${set_nr5g_disable_mode}
	
	sleep 1
	gcom -d $2 -s $set_nr5g_disable_mode
	
	#Set "mode_pref". This is also called "rattype".
	{
		echo "opengt"
		echo -e "\tset com 115200n81"
		echo -e "\tset comecho off"
		echo -e "\tset senddelay 0.02"
		echo -e "\twaitquiet 0.2 0.2"
		echo -e "\tflash 0.1"
		echo -e "\n"
		echo ":start"
		echo -e "\tsend \"AT+QNWPREFCFG=\"mode_pref\",$4^m\""
		echo -e "\tget 1 \"\" $s"
		echo -e "\tprint \$s"
		echo -e "\n"
		echo ":continue"
		echo -e "\texit 0"
	} > ${set_mode_pref}
	
	sleep 1
	gcom -d $2 -s $set_mode_pref
	
	#Set nsabands
	{
		echo "opengt"
		echo -e "\tset com 115200n81"
		echo -e "\tset comecho off"
		echo -e "\tset senddelay 0.02"
		echo -e "\twaitquiet 0.2 0.2"
		echo -e "\tflash 0.1"
		echo -e "\n"
		echo ":start"
		echo -e "\tsend \"AT+QNWPREFCFG=\"nsa_nr5g_band\",$5^m\""
		echo -e "\tget 1 \"\" $s"
		echo -e "\tprint \$s"
		echo -e "\n"
		echo ":continue"
		echo -e "\texit 0"
	} > ${set_nsabands}
	
	sleep 1
	gcom -d $2 -s $set_nsabands
		
	#sabands
	{
		echo "opengt"
		echo -e "\tset com 115200n81"
		echo -e "\tset comecho off"
		echo -e "\tset senddelay 0.02"
		echo -e "\twaitquiet 0.2 0.2"
		echo -e "\tflash 0.1"
		echo -e "\n"
		echo ":start"
		echo -e "\tsend \"AT+QNWPREFCFG=\"nsa_nr5g_band\",$6^m\""
		echo -e "\tget 1 \"\" $s"
		echo -e "\tprint \$s"
		echo -e "\n"
		echo ":continue"
		echo -e "\texit 0"
	} > ${set_sa_bands}
	
	sleep 1
	gcom -d $2 -s $set_sa_bands
fi
}

SystemConfigFile="/etc/config/sysconfig"
MwanConfigFile="/etc/config/mwan3config"
simtmpfile="/tmp/simnumfile"
wirelessdatfile="/etc/wireless/mt7603e/mt7603e.dat"
wirelessdatfile1="/etc/wireless/mt7663/mt7663.dat"

/etc/init.d/mwan3 stop 2>&1


set_nr5g_disable_mode="/etc/gcom/set_nr5g_disable_mode.gcom"
set_mode_pref="/etc/gcom/set_mode_pref.gcom"
set_nsa_bands="/etc/gcom/set_nsa_bands.gcom"
set_sa_bands="/etc/gcom/set_sa_bands.gcom"
nr5g_disable_mode="/etc/gcom/nr5g_disable_mode.gcom"
mode_pref="/etc/gcom/mode_pref.gcom"
nsa_bands="/etc/gcom/nsa_bands.gcom"
sa_bands="/etc/gcom/sa_bands.gcom"

SimNumFile="/tmp/simnumfile"

ReadSystemConfigFile
ReadMwanConfigFile
UpdateWirelessConfig
UpdateNetworkConfig
UpdateMwanConfig
UpdateScheduledWifiOnOff
if [ "$EnableCellular" = "1" ]
then
	/etc/init.d/smstools3 stop
	UpdateModemConfig
	/etc/init.d/smstools3 start
else
	uci set modem."${cellularwan1interface}".modemenable="0"
	uci set modem."${cellularwan1sim1interface}".modemenable="0"
	uci set modem."${cellularwan1sim2interface}".modemenable="0"
	uci set modem."${cellularwan2interface}".modemenable="0"
	uci set modem."${cellularwan3interface}".modemenable="0"
fi
UpdateFirewallConfig
UpdateInternetOverInterface

/root/InterfaceManager/script/SystemRestart.sh > /dev/null 2>&1 & 

exit 0
