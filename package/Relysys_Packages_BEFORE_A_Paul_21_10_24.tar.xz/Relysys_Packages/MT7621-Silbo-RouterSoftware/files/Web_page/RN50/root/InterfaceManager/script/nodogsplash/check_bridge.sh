#!/bin/sh

bridge_check=$(uci get networkinterfaces.EWAN1.enable_bridge)

if [ "$bridge_check" = "1" ]
then

	bridge_interface=$(ifconfig | awk '/^(br-EWAN1)/{print $1}')

	if [ -z "$bridge_interface" ]; then

		hostapd_pid=$(pidof hostapd)
		wpa_supplicant_pid=$(pidof wpa_supplicant)
		
		kill -9 $hostapd_pid $wpa_supplicant_pid
		
		rm /var/run/hostapd-phy0.conf
		wifi reload
		/etc/init.d/network restart
		
		sleep 60
		
		/root/InterfaceManager/script/nodogsplash/nodogsplash.sh

	else
		
		ip=$(ifconfig br-EWAN1 | awk '/inet addr/{split($2, a, ":"); print a[2]}' | awk -F. '{print $NF}')
		
		#Check if the host part of the bridge ip is 2. That is, 192.168.190.2.
		if [ "$ip" = "2" ]
		then
			sleep 5
			
			/root/InterfaceManager/script/nodogsplash/nodogsplash.sh
		fi
	fi
fi
