#!/bin/sh

check_relay=$(uci get networkinterfaces.EWAN1.enable_relay)

if [ "$check_relay" = "1" ]
then

	#Get the dhcp-relay server ip address.
	relay_server_ip=$(uci get networkinterfaces.EWAN1.relay_serverip)
	
	# Modify the last digit(host portion) in the ip address, since that is fixed.
	bridgeIP="${relay_server_ip%.*}.2"
	
	uci set networkinterfaces.SW_LAN.enable_dhcpserver="0"
	uci set networkinterfaces.SW_LAN.enable_dns="0"
	uci set networkinterfaces.SW_LAN.enable_relay='0'
	uci set networkinterfaces.SW_LAN.enable_bridge='0'	
	
	uci set networkinterfaces.EWAN1.protocol='static'
	uci set networkinterfaces.EWAN1.enable_bridge='1'
	uci delete networkinterfaces.EWAN1.bridge_interfaces
	uci add_list networkinterfaces.EWAN1.bridge_interfaces='eth0.1'
	uci add_list networkinterfaces.EWAN1.bridge_interfaces='ra0'
	uci add_list networkinterfaces.EWAN1.bridge_interfaces='wlan0'
	uci set networkinterfaces.EWAN1.staticIP="$bridgeIP"
	uci set networkinterfaces.EWAN1.staticgateway="$bridgeIP"
	uci set networkinterfaces.EWAN1.staticnetmask='255.255.255.0'
	uci set networkinterfaces.EWAN1.enable_relay='1'
	uci set networkinterfaces.EWAN1.relay_serverip="$relay_server_ip"
	
	uci commit networkinterfaces
	
	#uci set nodogsplash.nodogsplash.enabled='1'
	#uci set nodogsplash.nodogsplash.redirect_enabled='1'
	#uci set nodogsplash.nodogsplash.redirect_url="$relay_server_ip"
	
	#uci commit nodogsplash
	
fi

#Check if captive portal is enabled.
cp_check=$(uci get nodogsplash.nodogsplash.enabled)

if [ "$cp_check" = "1" ]
then
	echo "do nothing"
else
	echo -n > /etc/dnsmasq.conf
	
	/etc/init.d/nodogsplash stop
fi
