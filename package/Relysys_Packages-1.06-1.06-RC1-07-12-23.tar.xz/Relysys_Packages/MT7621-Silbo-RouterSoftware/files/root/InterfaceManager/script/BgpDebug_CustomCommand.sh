#!/bin/sh

. /lib/functions.sh

command_to_execute="$1"
output_file="/tmp/bgpcommandoutput.txt"

if [ -n "$command_to_execute" ]; then
    # Use eval to execute the command and redirect output to a file
    eval "$command_to_execute" > "$output_file"  2>/dev/null
    
fi


exit 0
