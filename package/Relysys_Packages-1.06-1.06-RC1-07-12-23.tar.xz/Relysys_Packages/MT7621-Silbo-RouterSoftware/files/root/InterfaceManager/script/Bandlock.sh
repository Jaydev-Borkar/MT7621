#!/bin/sh
. /lib/functions.sh

enable_cellular=$(uci get sysconfig.sysconfig.enablecellular)

if [ $enable_cellular = 0 ]
then 
	exit 0
fi

LogrotateConfigFile1="/etc/logrotate.d/alllogsmod1"
Logfile1="/root/ConfigFiles/Logs/all_logs_mod1.txt"

LogrotateConfigFile2="/etc/logrotate.d/alllogsmod2"
Logfile2="/root/ConfigFiles/Logs/all_logs_mod2.txt"

echo "------------BANDLOCKING-------------" >> $Logfile1
echo "------------BANDLOCKING-------------" >> $Logfile2

#Here, we take ComportSymlink1 value...for ex- comport_1=/dev/CWAN1_0_2 and check_comport1=CWAN1_0_2... 
comport_1=$(uci get sysconfig.sysconfig.ComPortSymLink1)
check_comport1=$(echo "$comport_1" | cut -d'/' -f3)
echo "$check_comport1"

#Here, we check that this ComportSymlink1 value is OK or not...
at=$(/bin/at-cmd /dev/$check_comport1 at | awk 'NR==2 {print $1}')
echo "$at"

#Here, we take Alternate AltComportSymlink1 value...for ex- altcomport_1=/dev/CWAN1_0_3 and check_altcomport1=CWAN1_0_3... 
altcomport_1=$(uci get sysconfig.sysconfig.AltComPortSymLink1)
check_altcomport1=$(echo "$altcomport_1" | cut -d'/' -f3)
echo "$check_altcomport1"

#Here, we check that this AltComportSymlink1 value is OK or not...
alt=$(/bin/at-cmd /dev/$check_altcomport1 at | awk 'NR==2 {print $1}')
echo "$alt"

#Here, we Check which comport is working ...
if [ $at = "OK" ]; then
comport1="$check_comport1"
elif [ $alt = "OK" ]; then
comport1="$check_altcomport1"
else
	exit 0
fi

cellular=$(uci get sysconfig.sysconfig.CellularOperationMode)
#Here, we check operation mode i.e if it is singlecellulardualsim then we use only one modem either RM500U or 
#EC200A and if it is dualcellularsinglesim then we use two modem , first one is RM500U or EC200A and second one 
#is EC200A.
if [ "$cellular" = "singlecellulardualsim" ]; then

#EC200A has no NR5G support, kindly do not enable NR5G bands in the web page

echo "******************************Band locking started*****************************************"

#Network1 Mode selected by the user in Webpage either AUTOMATIC,LTE,NR5G and NR5G+LTE...
Network1=$(awk -F"'" '/bandselectenable1/ {print $2}' /etc/config/sysconfig)
echo "User Selected Network1 is \"$Network1\""  
#Modem1 selected automatically when you insert in board (EC200A or RM500U)
Modem1=$(awk -F"'" '/model1/ {print $2}' /etc/config/sysconfig)
i=0

echo "The Operation Mode is: $cellular"  >> $Logfile1
echo "The Modem1 is \"$Modem1\"" >> $Logfile1
echo "The Network1 is \"$Network1\"" >> $Logfile1
#Selecting Auto bands
	if [ "$Network1" = "auto" ]; then
	echo "*******************************Band locking Automatic******************************************"
#Selecting Auto band in EC200A
		if [ "$Modem1" = "EC200A" ]; then
			while [[ $i -lt 5 ]]; do
				Network1latch=$(/bin/at-cmd /dev/$comport1 at+qcfg=\"nwscanmode\",0 | awk 'NR==2 {print $1}')
				sleep 0
				Auto1=$(/bin/at-cmd /dev/$comport1 at+qcfg=\"band\",0,0 | awk 'NR==2 {print $1}')
				sleep 1
				if [ "$Auto1" = "OK" ]; then
					sleep 0
					Band1latched=$(/bin/at-cmd /dev/$comport1 at+qnwinfo | awk -F'"' '{print $6}')
					echo "Band 1 latched :"$Band1latched""
					break
				else
					i=$((i+1))
					echo "Waiting for proper band latching"
				fi
			done
		fi
#Selecting Auto band in RM500U
		if [ "$Modem1" = "RM500U" ]; then
			while [[ $i -lt 5 ]]; do
				Network1latch=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"mode_pref\",AUTO)	
				sleep 0
				Auto1=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"all_band_reset\")
				sleep 1
				
				if [ "$Network1latch" = "OK" ]; then
					sleep 0
					Band1latched=$(/bin/at-cmd /dev/$comport1 at+qnwinfo | awk -F'"' 'NR==2 {print $6}')
					echo "Band 1 latched :"$Band1latched""
					break
				else
					echo $i
					i=$((i+1))
					echo "Waiting for proper band latching"
				fi
			done
		fi
	fi	

#Selecting NR5G:LTE band in RM500U model
	if [ "$Network1" = "5g4g" ]; then
		while [[ $i -lt 5 ]]; do
			Network1latch=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"mode_pref\",NR5G:LTE)	
			sleep 0
			Auto1=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"all_band_reset\")
			sleep 1
				    
		    if [ "$Network1latch" = "OK" ]; then
					sleep 0
					Band1latched=$(/bin/at-cmd /dev/$comport1 at+qnwinfo | awk -F'"' 'NR==2 {print $6}')
					echo "Band 1 latched :"$Band1latched""
					break
			else
					echo $i
					i=$((i+1))
					echo "Waiting for proper band latching"
			fi
		done
	fi
		
#Selecting NR5G bands in RM500U model
	if [ "$Network1" = "5g" ]; then
	
		echo "********************************Band locking NR5G*******************************************"
		Fetching user enabled 5G bands from the sysconfig file
		enabled_5g_bands=$(awk -F"'" '/list 5g/ {print $2}' /etc/config/sysconfig)
		Band=0
echo "The band is $enabled_5g_bands" >> $Logfile1

#For loop is to extract the bands selected by the user from array "enabled_5g_bands"
		for band in $enabled_5g_bands; do
			band_num=$(echo $band | sed 's/[^0-9]*//g')

			echo "selected bands $band_num"
			
			if [[ -z  $band_num ]] 
			then
              	var=$band_num
			else
               	var="$var:$band_num"
			fi
		done
			sleep 0
			      	
			while [[ $i -lt 5 ]]; do
				Network1latch=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"mode_pref\",NR5G)
				sleep 0
				Bandlock1=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"nr5g_band\",$var)
				sleep 1
					if [ "$Bandlock1" = "OK" ]; then
						sleep 0
						Band1latched=$(/bin/at-cmd /dev/$comport1 at+qnwinfo | awk -F'"' 'NR==2 {print $6}')
						echo "Band 1 latched :"$Band1latched""
					break
					else
						i=$((i+1))
						echo $i
						echo "Waiting for proper band to latch"
					fi
			done
	fi

#Selecting LTE Bands		
	if [ "$Network1" = "lte" ]; then
		if [ "$Modem1" = "RM500U" ]; then	
			echo "********************************Band locking LTE*******************************************"
			#Fetching user enabled LTE bands from the sysconfig file
			enabled_lte_bands=$(awk -F"'" '/list lte/ {print $2}' /etc/config/sysconfig)
			Band=0
echo "The band is $enabled_lte_bands" >> $Logfile1

#For loop is to extract the bands selected by the user from array "enabled_lte_bands"
			for band in $enabled_lte_bands; do
				band_num=$(echo $band | sed 's/[^0-9]*//g')
				
				echo "selected bands $band_num"
			
				if [[ -z  $band_num ]] 
				then
               		var=$band_num
				else
               		var="$var:$band_num"
				fi
        	done
        	
				sleep 0
				while [[ $i -lt 5 ]]; do
					Network1latch=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"mode_pref\",LTE)
					sleep 0
					Bandlock1=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"lte_band\",$var)
					sleep 1
					if [ "$Bandlock1" = "OK" ]; then
						sleep 0
						Bandlatched=$(/bin/at-cmd /dev/$comport1 at+qnwinfo | awk -F'"' 'NR==2 {print $6}')
						echo "Band 1 latched :"$Band1latched""
					break
					else
						i=$((i+1))
						echo $i
						echo "Waiting for proper band to latch"
					fi
				done
		else
	
#BANDLOCKINGLTE(EC200A)
	
			echo "********************************Band locking LTE*******************************************"
			#Fetching user enabled LTE bands from the sysconfig file
			enabled_lte_bands=$(awk -F"'" '/list lte/ {print $2}' /etc/config/sysconfig)
			Band=0
echo "The band is $enabled_lte_bands" >> $Logfile1

#For loop is to extract the bands selected by the user from array "enabled_lte_bands"
			for band in $enabled_lte_bands; do
				band_num=$(echo $band | sed 's/[^0-9]*//g')
				echo "selected bands $band_num"
#Finding the band value
				bit_pos=$((band_num - 1))
				band_val=$((2**(bit_pos)))
				hex_val=$(printf '%x\n' $band_val)
				Band=$((Band+hex_val))
			done
				echo "hexadecimal value = $Band"
				sleep 0
				while [[ $i -lt 5 ]]; do
					Network1latch=$(/bin/at-cmd /dev/$comport1 at+qcfg=\"nwscanmode\",3 | awk 'NR==2 {print $1}')
					sleep 0
					Bandlock1=$(/bin/at-cmd /dev/$comport1 at+qcfg=\"band\",0,$Band | awk 'NR==2 {print $1}')
					sleep 1
					if [ "$Bandlock1" = "OK" ]; then
						sleep 0
						Band1latched=$(/bin/at-cmd /dev/$comport1 at+qnwinfo | awk -F'"' 'NR==2 {print $6}')
						echo "Band 1 latched :"$Band1latched""
					break
					else
						i=$((i+1))
						echo $i
						echo "Waiting for proper band to latch"
					fi
				done
		fi
	fi
	
#Here, we check operation mode i.e  dualcellularsinglesim then we use two modem , first one is RM500U or EC200A 
#and second one is EC200A.	
elif [ "$cellular" = "dualcellularsinglesim" ]; then

#Here,same code for First Modem...
#Here, we take ComportSymlink1 value...for ex- comport_1=/dev/CWAN1_2 and check_comport1=CWAN1_2

#EC200A has no NR5G support, kindly do not enable NR5G bands in the web page

echo "******************************Band locking started*****************************************"

#Network1 Mode selected by the user in Webpage either AUTOMATIC,LTE,NR5G and NR5G+LTE...
Network1=$(awk -F"'" '/bandselectenable1/ {print $2}' /etc/config/sysconfig)
echo "User Selected Network1 is \"$Network1\""
#Modem1 selected automatically when you insert in board (EC200A or RM500U)
Modem1=$(awk -F"'" '/model1/ {print $2}' /etc/config/sysconfig)
i=0

echo "The Operation Mode is: $cellular"  >> $Logfile1
echo "The Modem1 is \"$Modem1\"" >> $Logfile1
echo "The Network1 is \"$Network1\"" >> $Logfile1
#Selecting Auto bands
	if [ "$Network1" = "auto" ]; then
	echo "*******************************Band locking Automatic******************************************"
#Selecting Auto band in EC200A
		if [ "$Modem1" = "EC200A" ]; then
			while [[ $i -lt 5 ]]; do
				Network1latch=$(/bin/at-cmd /dev/$comport1 at+qcfg=\"nwscanmode\",0 | awk 'NR==2 {print $1}')
				sleep 0
				Auto1=$(/bin/at-cmd /dev/$comport1 at+qcfg=\"band\",0,0 | awk 'NR==2 {print $1}')
				sleep 1
				if [ "$Auto1" = "OK" ]; then
					sleep 0
					Band1latched=$(/bin/at-cmd /dev/$comport1 at+qnwinfo | awk -F'"' '{print $6}')
					echo "Band 1 latched :"$Band1latched""
					break
				else
					i=$((i+1))
					echo "Waiting for proper band latching"
				fi
			done
		fi
#Selecting Auto band in RM500U
		if [ "$Modem1" = "RM500U" ]; then
			while [[ $i -lt 5 ]]; do
				Network1latch=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"mode_pref\",AUTO)	
				sleep 0
				Auto1=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"all_band_reset\")
				sleep 1
				
				if [ "$Network1latch" = "OK" ]; then
					sleep 0
					Band1latched=$(/bin/at-cmd /dev/$comport1 at+qnwinfo | awk -F'"' 'NR==2 {print $6}')
					echo "Band 1 latched :"$Band1latched""
					break
				else
					echo $i
					i=$((i+1))
					echo "Waiting for proper band latching"
				fi
			done
		fi
	fi	
uci get sysconfig.sysconfig.ComPortSymLink2
#Selecting NR5G:LTE band in RM500U model
	if [ "$Network1" = "5g4g" ]; then
		while [[ $i -lt 5 ]]; do
			Network1latch=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"mode_pref\",NR5G:LTE)	
			sleep 0
			Auto1=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"all_band_reset\")
			sleep 1
				    
		    if [ "$Network1latch" = "OK" ]; then
					sleep 0
					Band1latched=$(/bin/at-cmd /dev/$comport1 at+qnwinfo | awk -F'"' 'NR==2 {print $6}')
					echo "Band 1 latched :"$Band1latched""
					break
			else
					echo $i
					i=$((i+1))
					echo "Waiting for proper band latching"
			fi
		done
	fi
		
#Selecting NR5G bands in RM500U model
	if [ "$Network1" = "5g" ]; then
	
		echo "********************************Band locking NR5G*******************************************"
		Fetching user enabled 5G bands from the sysconfig file
		enabled_5g_bands=$(awk -F"'" '/list 5g/ {print $2}' /etc/config/sysconfig)
		Band=0
echo "The band is $enabled_5g_bands" >> $Logfile1

#For loop is to extract the bands selected by the user from array "enabled_5g_bands"
		for band in $enabled_5g_bands; do
			band_num=$(echo $band | sed 's/[^0-9]*//g')

			echo "selected bands $band_num"
			
			if [[ -z  $band_num ]] 
			then
              	var=$band_num
			else
               	var="$var:$band_num"
			fi
		done
			sleep 0
			while [[ $i -lt 5 ]]; do
				Network1latch=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"mode_pref\",NR5G)
				sleep 0
				Bandlock1=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"nr5g_band\",$var)
				sleep 1
					if [ "$Bandlock1" = "OK" ]; then
						sleep 0
						Band1latched=$(/bin/at-cmd /dev/$comport1 at+qnwinfo | awk -F'"' 'NR==2 {print $6}')
						echo "Band 1 latched :"$Band1latched""
					break
					else
						i=$((i+1))
						echo $i
						echo "Waiting for proper band to latch"
					fi
			done
	fi

#Selecting LTE Bands		
	if [ "$Network1" = "lte" ]; then
		if [ "$Modem1" = "RM500U" ]; then	
			echo "********************************Band locking LTE*******************************************"
			#Fetching user enabled LTE bands from the sysconfig file
			enabled_lte_bands=$(awk -F"'" '/list lte/ {print $2}' /etc/config/sysconfig)
			Band=0
echo "The band is $enabled_lte_bands" >> $Logfile1

#For loop is to extract the bands selected by the user from array "enabled_lte_bands"
			for band in $enabled_lte_bands; do
				band_num=$(echo $band | sed 's/[^0-9]*//g')
				echo "selected bands $band_num"
				
				if [[ -z  $band_num ]] 
				then
               		var=$band_num
				else
               		var="$var:$band_num"
				fi
			done
				sleep 0
				while [[ $i -lt 5 ]]; do
					Network1latch=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"mode_pref\",LTE)
					sleep 0
					Bandlock1=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"lte_band\",$var)
					sleep 1
					if [ "$Bandlock1" = "OK" ]; then
						sleep 0
						Bandlatched=$(/bin/at-cmd /dev/$comport1 at+qnwinfo | awk -F'"' 'NR==2 {print $6}')
						echo "Band 1 latched :"$Band1latched""
					break
					else
						i=$((i+1))
						echo $i
						echo "Waiting for proper band to latch"
					fi
				done
		else
	
#BANDLOCKINGLTE(EC200A)
	
			echo "********************************Band locking LTE*******************************************"
			#Fetching user enabled LTE bands from the sysconfig file
			enabled_lte_bands=$(awk -F"'" '/list lte/ {print $2}' /etc/config/sysconfig)
			Band=0
echo "The band is $enabled_lte_bands" >> $Logfile1

#For loop is to extract the bands selected by the user from array "enabled_lte_bands"
			for band in $enabled_lte_bands; do
				band_num=$(echo $band | sed 's/[^0-9]*//g')
				echo "selected bands $band_num"
#Finding the band value
				bit_pos=$((band_num - 1))
				band_val=$((2**(bit_pos)))
				hex_val=$(printf '%x\n' $band_val)
				Band=$((Band+hex_val))
			done
				echo "hexadecimal value = $Band"
				sleep 0
				while [[ $i -lt 5 ]]; do
					Network1latch=$(/bin/at-cmd /dev/$comport1 at+qcfg=\"nwscanmode\",3 | awk 'NR==2 {print $1}')
					sleep 0
					Bandlock1=$(/bin/at-cmd /dev/$comport1 at+qcfg=\"band\",0,$Band | awk 'NR==2 {print $1}')
					sleep 1
					if [ "$Bandlock1" = "OK" ]; then
						sleep 0
						Band1latched=$(/bin/at-cmd /dev/$comport1 at+qnwinfo | awk -F'"' 'NR==2 {print $6}')
						echo "Band 1 latched :"$Band1latched""
					break
					else
						i=$((i+1))
						echo $i
						echo "Waiting for proper band to latch"
					fi
				done
		fi
	fi
	
#Here, we write code for second modem in dualcellularsinglesim where we use ComPortSymLink2 value...
#for ex- comport_2=/dev/CWAN2_1 and check_comport2=CWAN2_1
comport_2=$(uci get sysconfig.sysconfig.ComPortSymLink2)
check_comport2=$(echo "$comport_2" | cut -d'/' -f3)
echo "$check_comport2"

#Here, we check that this ComportSymlink2 value is OK or not...
at2=$(/bin/at-cmd /dev/$check_comport2 at | awk 'NR==2 {print $1}')
echo "$at2"

#Here, we take Alternate AltComportSymlink2 value...for ex- altcomport_2=/dev/CWAN2_0 and check_altcomport2=CWAN2_0... 
altcomport_2=$(uci get sysconfig.sysconfig.AltComPortSymLink2)
check_altcomport2=$(echo "$altcomport_2" | cut -d'/' -f3)
echo "$check_altcomport2"

#Here, we check that this AltComportSymlink2 value is OK or not...
alt2=$(/bin/at-cmd /dev/$check_altcomport2 at | awk 'NR==2 {print $1}')
echo "$alt2"

#Here, we Check which comport is working ...
if [ $at2 = "OK" ]; then
comport2="$check_comport2"
elif [ $alt2 = "OK" ]; then
comport2="$check_altcomport2"
else 
	exit 0
fi	

echo "******************************Band locking started*****************************************"

#Network2 Mode selected by the user
Network2=$(awk -F"'" '/bandselectenable2/ {print $2}' /etc/config/sysconfig)
echo "User Selected Network2 is \"$Network2\""
#Modem2 selected automatically when you insert in board (EC200A)
Modem2=$(awk -F"'" '/model2/ {print $2}' /etc/config/sysconfig)
i=0

echo "The Operation Mode is: $cellular"  >> $Logfile2
echo "The Modem2 is \"$Modem2\"" >> $Logfile2
echo "The Network2 is \"$Network2\"" >> $Logfile2
#Selecting Auto bands
	if [ "$Network2" = "auto2" ]; then
	echo "*******************************Band locking Automatic******************************************"
#Selecting Auto band in EC200A
		if [ "$Modem2" = "EC200A" ]; then
			while [[ $i -lt 5 ]]; do
				Network2latch=$(/bin/at-cmd /dev/$comport2 at+qcfg=\"nwscanmode\",0 | awk 'NR==2 {print $1}')
				sleep 0
				Auto2=$(/bin/at-cmd /dev/$comport2 at+qcfg=\"band\",0,0 | awk 'NR==2 {print $1}')
				sleep 1
				if [ "$Auto2" = "OK" ]; then
					sleep 0
					Band2latched=$(/bin/at-cmd /dev/$comport2 at+qnwinfo | awk -F'"' '{print $6}')
					echo "Band 2 latched :"$Band2latched""
				break
				else
					i=$((i+1))
					echo "Waiting for proper band latching"
				fi
			done
		fi
	fi

#Selecting LTE Bands	

	if [ "$Network2" = "lte2" ]; then
	
		echo "********************************Band locking LTE*******************************************"
#Fetching user enabled LTE bands from the sysconfig file
		enabled_lte_bands=$(awk -F"'" '/list 4g/ {print $2}' /etc/config/sysconfig)
		Band=0
echo "The band is $enabled_lte_bands" >> $Logfile1

#For loop is to extract the bands selected by the user from array "enabled_lte_bands"
		for band in $enabled_lte_bands; do
			band_num=$(echo $band | sed 's/[^0-9]*//g')
			echo "selected bands $band_num"
#Finding the band value
			bit_pos=$((band_num - 1))
			band_val=$((2**(bit_pos)))
			hex_val=$(printf '%x\n' $band_val)
			Band=$((Band+hex_val))
		done
			echo "hexadecimal value = $Band"
			sleep 0
			while [[ $i -lt 5 ]]; do
				Network2latch=$(/bin/at-cmd /dev/$comport2 at+qcfg=\"nwscanmode\",3 | awk 'NR==2 {print $1}')
				sleep 0
				Bandlock2=$(/bin/at-cmd /dev/$comport2 at+qcfg=\"band\",0,$Band | awk 'NR==2 {print $1}')
				sleep 1
				if [ "$Bandlock2" = "OK" ]; then
					sleep 0
					Band2latched=$(/bin/at-cmd /dev/$comport2 at+qnwinfo | awk -F'"' 'NR==2 {print $6}')
					echo "Band 2 latched :"$Band2latched""
				break
				else
					i=$((i+1))
					echo $i
					echo "Waiting for proper band to latch"
				fi
			done
	fi

# If operation mode is neither singlecellulardualsim nor dualcellularsinglesim then it is singlecellularsinglesim...
else
    #Here,same code for First Modem...
#Here, we take ComportSymlink1 value...for ex- comport_1=/dev/CWAN1_2 and check_comport1=CWAN1_2

#EC200A has no NR5G support, kindly do not enable NR5G bands in the web page

echo "******************************Band locking started*****************************************"

#Network1 Mode selected by the user in Webpage either AUTOMATIC,LTE,NR5G and NR5G+LTE...
Network1=$(awk -F"'" '/bandselectenable1/ {print $2}' /etc/config/sysconfig)
echo "User Selected Network1 is \"$Network1\""
#Modem1 selected automatically when you insert in board (EC200A or RM500U)
Modem1=$(awk -F"'" '/model1/ {print $2}' /etc/config/sysconfig)
i=0

echo "The Operation Mode is: $cellular"  >> $Logfile1
echo "The Modem1 is \"$Modem1\"" >> $Logfile1
echo "The Network1 is \"$Network1\"" >> $Logfile1
#Selecting Auto bands
	if [ "$Network1" = "auto" ]; then
	echo "*******************************Band locking Automatic******************************************"
#Selecting Auto band in EC200A
		if [ "$Modem1" = "EC200A" ]; then
			while [[ $i -lt 5 ]]; do
				Network1latch=$(/bin/at-cmd /dev/$comport1 at+qcfg=\"nwscanmode\",0 | awk 'NR==2 {print $1}')
				sleep 0
				Auto1=$(/bin/at-cmd /dev/$comport1 at+qcfg=\"band\",0,0 | awk 'NR==2 {print $1}')
				sleep 1
				if [ "$Auto1" = "OK" ]; then
					sleep 0
					Band1latched=$(/bin/at-cmd /dev/$comport1 at+qnwinfo | awk -F'"' '{print $6}')
					echo "Band 1 latched :"$Band1latched""
					break
				else
					i=$((i+1))
					echo "Waiting for proper band latching"
				fi
			done
		fi
#Selecting Auto band in RM500U
		if [ "$Modem1" = "RM500U" ]; then
			while [[ $i -lt 5 ]]; do
				Network1latch=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"mode_pref\",AUTO)	
				sleep 0
				Auto1=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"all_band_reset\")
				sleep 1
				
				if [ "$Network1latch" = "OK" ]; then
					sleep 0
					Band1latched=$(/bin/at-cmd /dev/$comport1 at+qnwinfo | awk -F'"' 'NR==2 {print $6}')
					echo "Band 1 latched :"$Band1latched""
					break
				else
					echo $i
					i=$((i+1))
					echo "Waiting for proper band latching"
				fi
			done
		fi
	fi	
uci get sysconfig.sysconfig.ComPortSymLink2
#Selecting NR5G:LTE band in RM500U model
	if [ "$Network1" = "5g4g" ]; then
		while [[ $i -lt 5 ]]; do
			Network1latch=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"mode_pref\",NR5G:LTE)	
			sleep 0
			Auto1=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"all_band_reset\")
			sleep 1
				    
		    if [ "$Network1latch" = "OK" ]; then
					sleep 0
					Band1latched=$(/bin/at-cmd /dev/$comport1 at+qnwinfo | awk -F'"' 'NR==2 {print $6}')
					echo "Band 1 latched :"$Band1latched""
					break
			else
					echo $i
					i=$((i+1))
					echo "Waiting for proper band latching"
			fi
		done
	fi
		
#Selecting NR5G bands in RM500U model
	if [ "$Network1" = "5g" ]; then
	
		echo "********************************Band locking NR5G*******************************************"
		Fetching user enabled 5G bands from the sysconfig file
		enabled_5g_bands=$(awk -F"'" '/list 5g/ {print $2}' /etc/config/sysconfig)
		Band=0
echo "The band is $enabled_5g_bands" >> $Logfile1

#For loop is to extract the bands selected by the user from array "enabled_5g_bands"
		for band in $enabled_5g_bands; do
			band_num=$(echo $band | sed 's/[^0-9]*//g')

			echo "selected bands $band_num"
			
			if [[ -z  $band_num ]] 
			then
              	var=$band_num
			else
               	var="$var:$band_num"
			fi
		done
			sleep 0
			while [[ $i -lt 5 ]]; do
				Network1latch=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"mode_pref\",NR5G)
				sleep 0
				Bandlock1=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"nr5g_band\",$var)
				sleep 1
					if [ "$Bandlock1" = "OK" ]; then
						sleep 0
						Band1latched=$(/bin/at-cmd /dev/$comport1 at+qnwinfo | awk -F'"' 'NR==2 {print $6}')
						echo "Band 1 latched :"$Band1latched""
					break
					else
						i=$((i+1))
						echo $i
						echo "Waiting for proper band to latch"
					fi
			done
	fi

#Selecting LTE Bands		
	if [ "$Network1" = "lte" ]; then
		if [ "$Modem1" = "RM500U" ]; then	
			echo "********************************Band locking LTE*******************************************"
			#Fetching user enabled LTE bands from the sysconfig file
			enabled_lte_bands=$(awk -F"'" '/list lte/ {print $2}' /etc/config/sysconfig)
			Band=0
echo "The band is $enabled_lte_bands" >> $Logfile1

#For loop is to extract the bands selected by the user from array "enabled_lte_bands"
			for band in $enabled_lte_bands; do
				band_num=$(echo $band | sed 's/[^0-9]*//g')
				echo "selected bands $band_num"
				
				if [[ -z  $band_num ]] 
				then
               		var=$band_num
				else
               		var="$var:$band_num"
				fi
			done
				sleep 0
				while [[ $i -lt 5 ]]; do
					Network1latch=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"mode_pref\",LTE)
					sleep 0
					Bandlock1=$(/bin/at-cmd /dev/$comport1 at+qnwprefcfg=\"lte_band\",$var)
					sleep 1
					if [ "$Bandlock1" = "OK" ]; then
						sleep 0
						Bandlatched=$(/bin/at-cmd /dev/$comport1 at+qnwinfo | awk -F'"' 'NR==2 {print $6}')
						echo "Band 1 latched :"$Band1latched""
					break
					else
						i=$((i+1))
						echo $i
						echo "Waiting for proper band to latch"
					fi
				done
		else
	
#BANDLOCKINGLTE(EC200A)
	
			echo "********************************Band locking LTE*******************************************"
			#Fetching user enabled LTE bands from the sysconfig file
			enabled_lte_bands=$(awk -F"'" '/list lte/ {print $2}' /etc/config/sysconfig)
			Band=0
echo "The band is $enabled_lte_bands" >> $Logfile1

#For loop is to extract the bands selected by the user from array "enabled_lte_bands"
			for band in $enabled_lte_bands; do
				band_num=$(echo $band | sed 's/[^0-9]*//g')
				echo "selected bands $band_num"
#Finding the band value
				bit_pos=$((band_num - 1))
				band_val=$((2**(bit_pos)))
				hex_val=$(printf '%x\n' $band_val)
				Band=$((Band+hex_val))
			done
				echo "hexadecimal value = $Band"
				sleep 0
				while [[ $i -lt 5 ]]; do
					Network1latch=$(/bin/at-cmd /dev/$comport1 at+qcfg=\"nwscanmode\",3 | awk 'NR==2 {print $1}')
					sleep 0
					Bandlock1=$(/bin/at-cmd /dev/$comport1 at+qcfg=\"band\",0,$Band | awk 'NR==2 {print $1}')
					sleep 1
					if [ "$Bandlock1" = "OK" ]; then
						sleep 0
						Band1latched=$(/bin/at-cmd /dev/$comport1 at+qnwinfo | awk -F'"' 'NR==2 {print $6}')
						echo "Band 1 latched :"$Band1latched""
					break
					else
						i=$((i+1))
						echo $i
						echo "Waiting for proper band to latch"
					fi
				done
		fi
	fi
fi     

logrotate "$LogrotateConfigFile1"												
logrotate "$LogrotateConfigFile2"												
