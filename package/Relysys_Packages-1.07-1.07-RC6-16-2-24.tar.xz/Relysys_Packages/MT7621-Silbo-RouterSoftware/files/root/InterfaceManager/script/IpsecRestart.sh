#!/bin/sh

. /lib/functions.sh

IpsecEnable=$(uci get vpnconfig1.general.enableipsecgeneral)

upstatus=$(ipsec status | grep connecting | awk NR==1 | awk '{ print $3 }' | cut -d "(" -f 2)

if [ "$upstatus" -gt "0" ]
then
    echo "Ipsec is Up"
else
   
   interfac=$(route -n | awk NR==3 | awk '{print $8}')

	#Ethernet                                                                 
	if [ "$interfac" = "eth0.1" ]                                                                                                 
	then                                                                                                                          
		uci set ipsec.general.interface="EWAN1"                                                                                     
		uci set firewall.ipsec_rule1.src="EWAN1"                                                                                     
		uci set firewall.ipsec_rule2.src="EWAN1"                                                                                     
		uci set firewall.ipsec_rule3.src="EWAN1"                                                                                     
	elif [ "$interfac" = "eth0.2" ]                                                                                               
	then                                                                                                                          
		uci set ipsec.general.interface="EWAN2" 
		uci set firewall.ipsec_rule1.src="EWAN2"                                                                                     
		uci set firewall.ipsec_rule2.src="EWAN2"                                                                                     
		uci set firewall.ipsec_rule3.src="EWAN2" 
	elif [ "$interfac" = "eth0.3" ]                                                                                               
	then                                                                                                                          
		uci set ipsec.general.interface="EWAN3" 
		uci set firewall.ipsec_rule1.src="EWAN3"                                                                                     
		uci set firewall.ipsec_rule2.src="EWAN3"                                                                                     
		uci set firewall.ipsec_rule3.src="EWAN3" 
	elif [ "$interfac" = "eth0.4" ]                                                                                               
	then                                                                                                                          
		uci set ipsec.general.interface="EWAN4" 
		uci set firewall.ipsec_rule1.src="EWAN4"                                                                                     
		uci set firewall.ipsec_rule2.src="EWAN4"                                                                                     
		uci set firewall.ipsec_rule3.src="EWAN4" 
	elif [ "$interfac" = "eth0.5" ]                                                                                               
	then                                                                                                                          
		uci set ipsec.general.interface="EWAN5" 
		uci set firewall.ipsec_rule1.src="EWAN5"                                                                                     
		uci set firewall.ipsec_rule2.src="EWAN5"                                                                                     
		uci set firewall.ipsec_rule3.src="EWAN5"
	elif [ "$interfac" = "apcli0" ]                                                                                               
	then                                                                                                                          
		uci set ipsec.general.interface="WIFI_WAN" 
		uci set firewall.ipsec_rule1.src="WIFI_WAN"                                                                                     
		uci set firewall.ipsec_rule2.src="WIFI_WAN"                                                                                     
		uci set firewall.ipsec_rule3.src="WIFI_WAN"     
	fi

	#Cellular
	if [ "$CellularOperationModelocal" = "dualcellularsinglesim" ]                                                          
	then
		if [ "$interfac" = "usb0" ] || [ "$interfac" = "wwan0" ]
		then
			uci set ipsec.general.interface="CWAN1"
			uci set firewall.ipsec_rule1.src="CWAN1"                                                                                     
			uci set firewall.ipsec_rule2.src="CWAN1"                                                                                     
			uci set firewall.ipsec_rule3.src="CWAN1"
		fi
		if [ "$interfac" = "usb1" ] || [ "$interfac" = "wwan1" ]
		then
			uci set ipsec.general.interface="CWAN2"
			uci set firewall.ipsec_rule1.src="CWAN2"                                                                                     
			uci set firewall.ipsec_rule2.src="CWAN2"                                                                                     
			uci set firewall.ipsec_rule3.src="CWAN2"
		fi
	elif [ "$CellularOperationModelocal" = "singlecellulardualsim" ]                                                          
	then
		if [ "$interfac" = "usb0" ] || [ "$interfac" = "wwan0" ] || [ "$interfac" = "usb1" ] || [ "$interfac" = "wwan1" ]
		then
			simnum=$(cat /tmp/simnumfile)                                                                                         
			if [ "$simnum" = "1" ]                                                                                                
			then 
				uci set ipsec.general.interface="CWAN1_0"
				uci set firewall.ipsec_rule1.src="CWAN1_0"                                                                                     
				uci set firewall.ipsec_rule2.src="CWAN1_0"                                                                                     
				uci set firewall.ipsec_rule3.src="CWAN1_0"
			else
				uci set ipsec.general.interface="CWAN1_1"
				uci set firewall.ipsec_rule1.src="CWAN1_1"                                                                                     
				uci set firewall.ipsec_rule2.src="CWAN1_1"                                                                                     
				uci set firewall.ipsec_rule3.src="CWAN1_1"
			fi
		fi
	else
		if [ "$interfac" = "usb0" ] || [ "$interfac" = "wwan0" ] || [ "$interfac" = "usb1" ] || [ "$interfac" = "wwan1" ]
		then
			uci set ipsec.general.interface="CWAN1"
			uci set firewall.ipsec_rule1.src="CWAN1"                                                                                     
			uci set firewall.ipsec_rule2.src="CWAN1"                                                                                     
			uci set firewall.ipsec_rule3.src="CWAN1"
		fi
	fi
                                                                                                                              
    uci commit ipsec
    uci commit firewall
    sleep 1
    /etc/init.d/firewall reload                                                                                                               
    if [ "$IpsecEnable" = "1" ] ; then
   /etc/init.d/ipsec stop
   /bin/sleep 2                                                                                              
   /etc/init.d/ipsec start                                                                                                          
   /bin/sleep 4                                                                                                                     
   /usr/sbin/ipsec restart                                                                                                          
   fi  
fi
