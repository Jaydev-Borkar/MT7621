#!/bin/sh

. /lib/functions.sh

OpenvpnUCIPath=/etc/config/openvpn 

ReadOpenvpnUCIConfig() 
{
    config_load "$OpenvpnUCIPath"
    config_foreach OpenvpnConfigParameters openvpn1
}
OpenvpnConfigParameters() 
{
    local OpenvpnConfigSection="$1"
    config_get Mode "$OpenvpnConfigSection" mode                                                                   
    config_get Name "$OpenvpnConfigSection" name      
                                                                                                                                                       
underscore="_"   
                                                                                               
certificate_name="$Name"                       

if [[ $Mode == "TAP" ]]; then                                                                                 
                                                                                                                
   base_name="tap" 
name="${base_name}${underscore}${certificate_name}"                                                                                                                   
                                                                     
fi
}

ReadOpenvpnUCIConfig 

swlanifname=eth0.1
tapname=$name
SwlanInterfaceName=SW_LAN
uci set network."${SwlanInterfaceName}".type=bridge
uci set network."${SwlanInterfaceName}".ifname="$swlanifname $tapname"

uci commit network

