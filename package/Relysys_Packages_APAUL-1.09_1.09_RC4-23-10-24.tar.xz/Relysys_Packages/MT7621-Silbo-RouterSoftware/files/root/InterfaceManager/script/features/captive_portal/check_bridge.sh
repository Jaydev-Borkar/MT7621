#!/bin/sh

. /lib/functions.sh

NetworkInterfacesFile="/etc/config/networkinterfaces"

ReadNetworkinterfaceConfigFile()
{
	config_load "$NetworkInterfacesFile"
	config_foreach Bridge_Check_Eth redirect
}

Bridge_Check_Eth()
{
	readnetint="$1"
	config_get Interfacename "$readnetint" interface
	config_get enable_bridge "$readnetint" enable_bridge
	
	if [ "$enable_bridge" = "1" ]
	then
		
		#Check if bridged interface is there in ifconfig.
		bridge_interface=$(ifconfig | awk -v iface="br-$Interfacename" '$1 == iface {print $1}')
		
		#When no br interface is up, do the following.
		if [ -z "$bridge_interface" ]; then

			hostapd_pid=$(pidof hostapd)
			wpa_supplicant_pid=$(pidof wpa_supplicant)
			
			kill -9 $hostapd_pid $wpa_supplicant_pid
			
			rm /var/run/hostapd-phy0.conf
			wifi reload
			/etc/init.d/network restart
			
			sleep 60
			
			#Once network restart is done, run the nodogsplash script.
			/root/InterfaceManager/script/features/captive_portal/nodogsplash.sh
		
		#If the br-interface is up with the ip, run the nodogsplash script.
		else	
			sleep 5
			
			/root/InterfaceManager/script/features/captive_portal/nodogsplash.sh
		fi
	fi
}

Bridge_Check_Wifi()
{
	Interfacename="$1"
	
	#Check if bridged interface is there in ifconfig.
	bridge_interface=$(ifconfig | awk -v iface="br-$Interfacename" '$1 == iface {print $1}')
	
	#When no br interface is up, do the following.
	if [ -z "$bridge_interface" ]; then

		hostapd_pid=$(pidof hostapd)
		wpa_supplicant_pid=$(pidof wpa_supplicant)
		
		kill -9 $hostapd_pid $wpa_supplicant_pid
		
		rm /var/run/hostapd-phy0.conf
		wifi reload
		/etc/init.d/network restart
		
		sleep 60
		
		#Once network restart is done, run the nodogsplash script.
		/root/InterfaceManager/script/features/captive_portal/nodogsplash.sh

	fi
}

#For ethernet
ReadNetworkinterfaceConfigFile

#For Wifi
check_wifi_bridge=$(uci get sysconfig.wificonfig.wifienable_bridge)

if [ "$check_wifi_bridge" = "1" ]
then
	Bridge_Check_Wifi ra0
fi
