#!/bin/sh

. /lib/functions.sh


########################################################################
#  Description:This script basically drives GPIO497 LOW for 5 seconds
#              before turning it HIGH again. This turns OFF the mini-PCIe 
#              2G/3G/4G modem in slot J2 (USB4) OFF for 5 seconds
########################################################################
ComPort="$1"

ReadSystemGpioFile()                               
{                                                    
        config_load "$SystemGpioConfig"              
        config_get Modem2PowerGpio gpio modem2powergpio
        config_get Modem2PowerOnValue gpio modem2poweronvalue
        config_get Modem2PowerOffValue gpio modem2poweroffvalue
}

SystemGpioConfig="/etc/config/systemgpio"

LogrotateConfigFile1="/etc/logrotate.d/alllogsconfig"
Logfile1="/root/ConfigFiles/Logs/all_logs.txt"
#Logfile1="/tmp/all_logs.txt"

ReadSystemGpioFile

echo " " >> $Logfile1
echo "<Recycle_WAN2_PWR_Script.sh> $ComPortSymLink ..." >> $Logfile1

pid_AddInterface=$(ps w | grep "AddInterface.sh" | grep -v grep | awk '{print $1}')
kill -9 $pid_AddInterface 

status=$(/bin/at-cmd $ComPort at+qpowd)

if [ -z "$status" ]                                                                                                        
then
	echo "<Recycle_WAN2_PWR_Script.sh> REBOOT VIA GPIO ..." >> $Logfile1

	echo "$Modem2PowerOffValue" > /sys/class/gpio/gpio$Modem2PowerGpio/value
	sleep 10
	echo "$Modem2PowerOnValue" > /sys/class/gpio/gpio$Modem2PowerGpio/value
fi
logrotate "$LogrotateConfigFile1"
exit 0


