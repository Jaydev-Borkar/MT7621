L.ui.view.extend({
        title: L.tr('VPN Configuration'),
        description: L.tr(''),
        
        RS485GetUCISections: L.rpc.declare({
                object: 'uci',
                method: 'get',
                params: [ 'config', 'type'],
                expect: { values: {} }
        }),
        
        RS485CreateUCISection:  L.rpc.declare({
                object: 'uci',
                method: 'add',
                params: [ 'config', 'type', 'name', 'values' ]
        }),
        
        RS485CommitUCISection:  L.rpc.declare({
                object: 'uci',
                method: 'commit',
                params: [ 'config' ]
        }),
        
        RS485DeleteUCISection:  L.rpc.declare({
		object: 'uci',
		method: 'delete',
		params: [ 'config','type','section' ]
	}),
	
	    updatefirewallconfig: L.rpc.declare({
        object: 'rpc-updateVPNConfig',
        method: 'configure',
        expect: { output: '' }
    }),
    
       updateopenvpnconfig: L.rpc.declare({
        object: 'rpc-updateVPNConfig',
        method: 'enableopenvpn',
        expect: { output: '' }
    }),
    
        deletecertficates: L.rpc.declare({
		object: 'rpc-updateVPNConfig',
		method: 'delete',
		expect: { output: '' }
	}),
	
	    countcertficates: L.rpc.declare({
		object: 'rpc-updateVPNConfig',
		method: 'countcertfiles',
		expect: { output: '' }
	 }),
    
        startopenvpnservice: L.rpc.declare({
        object: 'rpc-updateVPNConfig',
        method: 'startopenvpn',
        expect: { output: '' }
    }),  
    
     stopopenvpnservice: L.rpc.declare({
        object: 'rpc-updateVPNConfig',
        method: 'stopopenvpn',
        expect: { output: '' }
    }),
    
    
    
      TestArchive: L.rpc.declare({
			object: 'rpc-updateVPNConfig',
			method: 'testarchive',
			params: ['archive'],
	}),
    
    
     handleArchiveUpload : function() {
        var self = this;  
        L.ui.archiveUploadcerts(
            L.tr('Archive Upload'),
            L.tr('Select the archive and click on "%s" button to proceed.').format(L.tr('Apply')), {
			    success: function(info) {
		          self.handleArchiveVerify(info);
		        }
			}
	    );
	},

	handleArchiveVerify : function(info)
	{
		var self = this;
              var archive=$('[name=filename]').val();
        
       // if((checksumval == info.checksum) &&(sizeval == info.size)) {
			L.ui.loading(true);
            self.TestArchive(archive).then(function(TestArchiveOutput) {
			    
		    	L.ui.dialog(
						L.tr('TestArchive'), [
						$('<p />').text(L.tr('Success')),
						$('<pre />')
						.addClass('alert-success')
						.text("file uploaded successfully")	
					],{
							style: 'close',
							
						}
			    );
				L.ui.loading(false);   
		    });
	},
			
        RS485FormCallback: function() 
        {
			    var map = this;
                var RS485ConfigSectionName = map.options.RS485ConfigSection;
                var numericExpression = /^[0-9]+$/;
                
                map.options.caption = L.tr(RS485ConfigSectionName+' Configuration');
                
                var s = map.section(L.cbi.NamedSection, RS485ConfigSectionName, {
                        collabsible: true
                });
                             
        s.option(L.cbi.DummyValue, 'typesettings', {
		  caption: L.tr(''),
		//  caption: L.tr(a),
        }).depends({'ipsecconfig':'1','enableipsec' : '1'})
        .ucivalue=function()
          {
            var id="<h5><b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbspIPSEC Type settings </b> </h3>";
            return id;
          };
          
          s.option(L.cbi.ListValue,'ipsectype',{          
                        caption:L.tr('IPSEC'),                    
                }).depends({'ipsecconfig':'1','enableipsec' : '1'})
                .value("none", L.tr('Please choose')) 
                .value("sitetositevpn", L.tr('Site to Site VPN')); 
                //.value("clienttositevpn", L.tr('Client to site VPN'));    
         
          s.option(L.cbi.ListValue,'ipsecrole',{          
                        caption:L.tr('IPSEC Role'),                    
                }).depends({'ipsecconfig':'1','enableipsec' : '1'})
                .value("none", L.tr('Please choose')) 
                .value("client", L.tr('Client'))
                .value("server", L.tr('Server')); 
                
                
        /*=========================================================================================================
    *  Connection Settings
    *  ====================================================================================================  */
    
              s.option(L.cbi.DummyValue, 'connectionsettings', {
		  caption: L.tr(''),
		//  caption: L.tr(a),
        }).depends({'ipsecconfig':'1','enableipsec' : '1'})
        .ucivalue=function()
          {
            var id="<h5><b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbspIPSEC Connection settings </b> </h3>";
            return id;
          };   
               
       /*  s.option(L.cbi.InputValue, 'connectionname', {
           caption: L.tr('Connection Name'),
        }).depends({'ipsecconfig':'1','enableipsec' : '1'});*/
        
         
        s.option(L.cbi.CheckboxValue, 'connectionenable', {
        caption: L.tr('Connection Enable'),
        optional: true
        }).depends({'ipsecconfig':'1','enableipsec' : '1'});
        
        s.option(L.cbi.ListValue,'connectiontype',{          
                        caption:L.tr('Connection Type'),                    
                }).depends({'ipsecconfig':'1','enableipsec' : '1'})
                .value("none", L.tr('Please choose')) 
                .value("tunnel", L.tr('Tunnel'));
               // .value("transport", L.tr('Transport'));

        s.option(L.cbi.CheckboxValue, 'splitTunnel', {
                caption: L.tr('Enable Split Tunnel'),
                optional: true
                }).depends({'ipsecconfig':'1','enableipsec' : '1'});
        
        s.option(L.cbi.CheckboxValue, 'lanWifiConnectivity', {
                caption: L.tr('Maintain Default route for Lan and Wifi'),
                optional: true
                }).depends({'ipsecconfig':'1','enableipsec' : '1','splitTunnel':'0'});

        s.option(L.cbi.ListValue,'connectionmode',{          
                caption:L.tr('Connection Mode'),
                }).depends({'ipsecconfig':'1','enableipsec' : '1'})
                .value("none", L.tr('Please choose'))
                .value("route", L.tr('route')) 
                .value("add", L.tr('add'))
                .value("start", L.tr('start'))
                .value("trap", L.tr('trap'));
              
          s.option(L.cbi.InputValue, 'remoteserverIP', {
           caption: L.tr('Remote Server IP'),
           datatype: 'ip4addr',
        }).depends({'ipsecconfig':'1','enableipsec' : '1'});
        
          s.option(L.cbi.InputValue, 'localid', {
          caption: L.tr('Local ID'),
          optional: true
        })
        .depends({'ipsecconfig':'1','enableipsec' : '1'});
        
        s.option(L.cbi.ListValue,'nooflocalsubnets',{          
                        caption:L.tr('No. of local subnets'),                    
                }).depends({'ipsecconfig':'1','enableipsec' : '1'})
                .value("none", L.tr('Please choose')) 
                .value("1", L.tr('1')) 
                .value("2", L.tr('2'));       
                
           s.option(L.cbi.InputValue, 'localsubnet1', {
           caption: L.tr('Local Subnet 1'),
			placeholder:'8.8.8.8/24 ', 
			datatype: 'cidr4',
        }).depends({'ipsecconfig':'1','enableipsec' : '1','nooflocalsubnets' : '1'})
		  .depends({'ipsecconfig':'1','enableipsec' : '1','nooflocalsubnets' : '2'});
          
          s.option(L.cbi.InputValue, 'localsubnet2', {
           caption: L.tr('Local Subnet 2'),
			placeholder:'8.8.8.8/24 ',
			datatype: 'cidr4', 
        }).depends({'ipsecconfig':'1','enableipsec' : '1','nooflocalsubnets' : '2'});
        
        
           s.option(L.cbi.InputValue, 'remoteid', {
           caption: L.tr('Remote ID'),
           optional: true

        })
        .depends({'ipsecconfig':'1','enableipsec' : '1'});
                
        s.option(L.cbi.ListValue,'noofremotesubnets',{          
                        caption:L.tr('No. of remote subnets'),                    
                }).depends({'ipsecconfig':'1','enableipsec' : '1','splitTunnel':'1'})
                .value("none", L.tr('Please choose')) 
                .value("1", L.tr('1')) 
                .value("2", L.tr('2'))
                .value("3", L.tr('3')) 
                .value("4", L.tr('4'))
                .value("5", L.tr('5')) 
                .value("6", L.tr('6'))
                .value("7", L.tr('7')) 
                .value("8", L.tr('8'));       
                
        s.option(L.cbi.InputValue, 'remotesubnet1', {
        caption: L.tr('Remote Subnet 1'),  
           			placeholder:'8.8.8.8/24 ', 
           			datatype: 'cidr4withexception',        
        }).depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '1','splitTunnel':'1'})
          .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '2','splitTunnel':'1'})
          .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '3','splitTunnel':'1'})
	.depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '4','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '5','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '6','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '7','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '8','splitTunnel':'1'});
          
          s.option(L.cbi.InputValue, 'remotesubnet2', {
           caption: L.tr('Remote Subnet 3'),
			placeholder:'8.8.8.8/24 ',
			datatype: 'cidr4withexception',  
        }).depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '2','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '3','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '4','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '5','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '6','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '7','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '8','splitTunnel':'1'});
		   
		   s.option(L.cbi.InputValue, 'remotesubnet3', {
           caption: L.tr('Remote Subnet 3'),
			placeholder:'8.8.8.8/24 ',
			datatype: 'cidr4withexception', 
         }).depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '3','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '4','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '5','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '6','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '7','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '8','splitTunnel':'1'});
        
         s.option(L.cbi.InputValue, 'remotesubnet4', {
           caption: L.tr('Remote Subnet 4'),
			placeholder:'8.8.8.8/24 ', 
			datatype: 'cidr4withexception',
         }).depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '4','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '5','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '6','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '7','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '8','splitTunnel':'1'});
		   
		   s.option(L.cbi.InputValue, 'remotesubnet5', {
           caption: L.tr('Remote Subnet 5'),
			placeholder:'8.8.8.8/24 ',
			datatype: 'cidr4withexception', 
         }).depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '5','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '6','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '7','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '8','splitTunnel':'1'});
		   
		    s.option(L.cbi.InputValue, 'remotesubnet6', {
           caption: L.tr('Remote Subnet 6'),
			placeholder:'8.8.8.8/24 ',
			datatype: 'cidr4withexception', 
         }).depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '6','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '7','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '8','splitTunnel':'1'});
		   
		   s.option(L.cbi.InputValue, 'remotesubnet7', {
           caption: L.tr('Remote Subnet 7'),
			placeholder:'8.8.8.8/24 ', 
			datatype: 'cidr4withexception',
         }).depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '7','splitTunnel':'1'})
		   .depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '8','splitTunnel':'1'});
		   
		   s.option(L.cbi.InputValue, 'remotesubnet8', {
           caption: L.tr('Remote Subnet 8'),
			placeholder:'8.8.8.8/24 ', 
			datatype: 'cidr4withexception',
         }).depends({'ipsecconfig':'1','enableipsec' : '1','noofremotesubnets' : '8','splitTunnel':'1'});
        
        
        s.option(L.cbi.ListValue,'keyexchange',{          
        caption:L.tr('Keyexchange'),                    
        }).depends({'ipsecconfig':'1','enableipsec' : '1'})
         .value("none", L.tr('Please choose')) 
        .value("ikev1", L.tr('ikev1')) 
        .value("ikev2", L.tr('ikev2'));
        
		s.option(L.cbi.ListValue,'aggressive',{          
        caption:L.tr('Aggressive'),                    
        }).depends({'ipsecconfig':'1','enableipsec' : '1'})
         .value("none", L.tr('Please choose')) 
        .value("yes", L.tr('YES')) 
        .value("no",L.tr("NO"));
        
        s.option(L.cbi.InputValue,'ikelifetime',{          
        caption:L.tr('IKE Life Time (In Seconds)'),                  
        }).depends({'ipsecconfig':'1','enableipsec' : '1'});
        
        
        s.option(L.cbi.InputValue,'lifetime',{          
        caption:L.tr('Life Time (In Seconds)'),                    
        }).depends({'ipsecconfig':'1','enableipsec' : '1'});

        s.option(L.cbi.CheckboxValue, 'dpddetectionenable', {
        caption: L.tr('Enable DPD Detection'),
        optional: true
        }).depends({'ipsecconfig':'1','enableipsec' : '1'});
        
        s.option(L.cbi.InputValue, 'timeinterval', {
        caption: L.tr('Time Interval (In Seconds)'),
        }).depends({'ipsecconfig':'1','enableipsec' : '1','dpddetectionenable':'1'});
       
       /* s.option(L.cbi.InputValue, 'timeout', {
        caption: L.tr('Time Out (In Seconds)'),
        }).depends({'ipsecconfig':'1','enableipsec' : '1'});*/
        
        s.option(L.cbi.ListValue,'action',{          
        caption:L.tr('Action'),                 
        }).depends({'ipsecconfig':'1','enableipsec' : '1','dpddetectionenable':'1'})
        .value("none", L.tr('Please choose'))
        .value("restart", L.tr('Restart'))
        .value("clear", L.tr('Clear'))
        .value("hold", L.tr('Hold'))
        .value("trap", L.tr('Trap'))
        .value("start", L.tr('Start')); 
        
          /*******************************************************************************************************
          * 
          * Authentication
          * 
          * ****************************************************************************************************/  
          
        s.option(L.cbi.ListValue,'authenticationmethod',{          
        caption:L.tr('Authentication Method'),                    
        }).depends({'ipsecconfig':'1','enableipsec' : '1'})
        .value("none", L.tr('Please choose')) 
        .value("psk", L.tr('PSK'));
        
        s.option(L.cbi.CheckboxValue,'multiplepsk',{          
        caption:L.tr('Multiple Secrets'),
        optional : true                    
        }).depends({'ipsecconfig':'1','enableipsec' : '1','authenticationmethod' : 'psk'});
        
        s.option(L.cbi.PasswordValue,'pskvalue1',{
		caption:L.tr('From remote'),
		optional : true
		}).depends({'ipsecconfig':'1','enableipsec' : '1','authenticationmethod' : 'psk','multiplepsk':'1'});
			
			
		s.option(L.cbi.PasswordValue,'pskvalue2',{
		caption:L.tr('to remote'),
		optional : true
		}).depends({'ipsecconfig':'1','enableipsec' : '1','authenticationmethod' : 'psk','multiplepsk':'1'});
			
         s.option(L.cbi.PasswordValue,'pskvalue',{
         caption: L.tr('PSK Value'),
         optional: true 
        }).depends({'ipsecconfig':'1','enableipsec' : '1','authenticationmethod' : 'psk','multiplepsk':'0'});
        
        /***************************************************************************************
         * Proposal settings Phase I
         * ************************************************************************************/
         
        // var a = '\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0' + 'Proposal Settings Phase I';
         s.option(L.cbi.DummyValue, 'proposalsettingphase1', {
		  caption: L.tr(''),
		//  caption: L.tr(a),
        }).depends({'ipsecconfig':'1','enableipsec' : '1'})
        .ucivalue=function()
          {
            var id="<h5><b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbspProposal Settings Phase I </b> </h3>";
            return id;
          }; 
        
        s.option(L.cbi.ListValue,'p1encrypalgorithm',{          
        caption:L.tr('Encryption Algorithm'),                    
        }).depends({'ipsecconfig':'1','enableipsec' : '1'})
        // .value("none", L.tr('Please choose')) 
        .value("none", L.tr('Please choose')) 
        .value("aes128", L.tr('AES 128'))
        .value("aes192", L.tr('AES 192'))
        .value("aes256", L.tr('AES 256'))
        .value("3des", L.tr('3DES'));
     
        
        s.option(L.cbi.ListValue,'p1authentication',{          
        caption:L.tr('Authentication Phase I'),                    
        }).depends({'ipsecconfig':'1','enableipsec' : '1'})
        // .value("none", L.tr('Please choose')) 
        .value("none", L.tr('Please choose')) 
        .value("sha1", L.tr('SHA1'))
        .value("md5", L.tr('MD5'))
        .value("sha256", L.tr('SHA 256'))
        .value("sha384", L.tr('SHA 384'))
         .value("sha512", L.tr('SHA 512'));
         
         s.option(L.cbi.ListValue,'p1dhgroup',{          
        caption:L.tr('DH Group'),                    
        }).depends({'ipsecconfig':'1','enableipsec' : '1'})
         .value("none", L.tr('Please choose')) 
        .value("modp768", L.tr('MODP768')) 
        .value("modp1024", L.tr('MODP1024'))
        .value("modp1536", L.tr('MODP1536'))
        .value("modp2048", L.tr('MODP2048'))
        .value("modp3072", L.tr('MODP3072'))
         .value("modp4096", L.tr('MODP4096'));
         
        
         /***************************************************************************************
         * Proposal settings Phase II
         * ************************************************************************************/
         s.option(L.cbi.DummyValue, 'proposalsettingphase2', {
           caption: L.tr(''),
        }).depends({'ipsecconfig':'1','enableipsec' : '1'})
           .ucivalue=function()
          {
            var id="<h5><b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbspProposal Settings Phase II </b> </h3>";
            return id;
          };    
        
        s.option(L.cbi.ListValue,'p2encrypalgorithm',{          
        caption:L.tr('Hash Algorithm'),                    
        }).depends({'ipsecconfig':'1','enableipsec' : '1'})
        // .value("none", L.tr('Please choose')) 
        .value("none", L.tr('Please choose')) 
        .value("aes128", L.tr('AES 128'))
        .value("aes192", L.tr('AES 192'))
        .value("aes256", L.tr('AES 256'))
        .value("3des", L.tr('3DES'));
     
        
        s.option(L.cbi.ListValue,'p2authentication',{          
        caption:L.tr('Authentication Phase II'),                    
        }).depends({'ipsecconfig':'1','enableipsec' : '1'})
        // .value("none", L.tr('Please choose')) 
        .value("none", L.tr('Please choose')) 
        .value("sha1", L.tr('SHA1'))
        .value("md5", L.tr('MD5'))
        .value("sha256", L.tr('SHA 256'))
        .value("sha384", L.tr('SHA 384'))
         .value("sha512", L.tr('SHA 512'));
         
         s.option(L.cbi.ListValue,'p2pfs',{          
        caption:L.tr('PFS Group'),                    
        }).depends({'ipsecconfig':'1','enableipsec' : '1'})
         .value("none", L.tr('Please choose')) 
        .value("modp768", L.tr('MODP768')) 
        .value("modp1024", L.tr('MODP1024'))
        .value("modp1536", L.tr('MODP1536'))
        .value("modp2048", L.tr('MODP2048'))
        .value("modp3072", L.tr('MODP3072'))
        .value("modp4096", L.tr('MODP4096'))
        .value("close", L.tr('close'));                                                      
     },
		
        RS485ConfigCreateForm: function(mapwidget,RS485ConfigSectionName) 
        {
                var self = this;
                
                if (!mapwidget)
                        mapwidget = L.cbi.Map;
                
                var map = new mapwidget('vpnconfig1', {
                        prepare: self.RS485FormCallback,
                        RS485ConfigSection: RS485ConfigSectionName
                });
                return map;
        },
        
        RS485RenderContents: function(rv) 
        {
			/*var m = new L.cbi.Map('vpnconfig1', {
			//caption:     L.tr('vpnfig1'),
			//description: L.tr('vpnfig1'),
		});*/
			/*var s = m.section(L.cbi.TypedSection, 'defaults', {
			caption:     L.tr('General Setting'),
                        //collabsible:    true
                });*/
			             
			    var self = this;

                var list = new L.ui.table({
                        columns: [{
                                caption: L.tr('Sl No'),
                                align: 'left',
                                format: function(v, n) {
                                        var div = $('<p />').attr('id', 'RS485DeviceSerialNo_%s'.format(n));
                                        var serialNo=n+1;
								return div.append(serialNo);
                                }
                        },
                        {
                                caption: L.tr('Name'),
                                        width:'30%',
                                align: 'left',
                                format: function(v,n) {
                                        var div = $('<p />').attr('id', 'RS485DeviceEventName_%s'.format(n));
                                        return div.append('<strong>'+v+'</strong>');
                                }
                        },
                        {
                                caption: L.tr('Update'),
                                align: 'left',
                                format: function(v, n) {
                                        return $('<div />')
                                                .addClass('btn-group btn-group-sm')
                                                .append(L.ui.button(L.tr('Edit'),'primary', L.tr('Configure'))
                                                .click({ self: self, RS485ConfigSectionName: v }, self.RS485ConfigSectionEdit))
                                                .append(L.ui.button(L.tr('Delete'), 'danger', L.tr('Delete Event'))
                                                .click({ self: self, RS485ConfigSectionName: v }, self.RS485ConfigSectionRemove));
                                               //  list.appendTo('#section_firewall_general');
                                }
                        }]
                });
                
               //  list.appendTo('#section_firewall_general');
               //  m.insertInto('#section_firewall_general');
                for (var key in rv) 
                {
                        if (rv.hasOwnProperty(key)) 
                        {
                                var obj = rv[key];
                                list.row([key,key,key]); 
                        }
                }
                  
                  
               // $('#map').append(list.render());
                         
               
               $('#section_vpn_ipsec').append(list.render());	
			
			// m.insertInto('#section_vpn_ipsec'); 	
			
			//$('#map').append(list.render());
			  
        },
		
        RS485ConfigSectionAdd: function () 
        {
                var self = this;
                var RS485ConfigSectionName = $('#field_NewEvent_name').val();
                var sensorSectionOptions = {EEnable:0,splitTunnel:1};
               
               // this.RS485GetUCISections("vpnconfog1","RS485Config").then(function(rv) {
               this.RS485GetUCISections("vpnconfig1","vpnconfig1").then(function(rv) {
                        var keys = Object.keys(rv);
                        var keysLength=keys.length;
                       // alert(keysLength);
                        if(keysLength>=5)
                        {
                                alert("Only 5 connections can be configured");
                        }
                        else
                        {
                             //   self.RS485CreateUCISection("vpnconfig1","RS485Config",RS485ConfigSectionName,sensorSectionOptions).then(function(rv){
                                  self.RS485CreateUCISection("vpnconfig1","vpnconfig1",RS485ConfigSectionName,sensorSectionOptions).then(function(rv){
                                        if(rv)
                                        {
                                                if (rv.section)
                                                {
                                                        self.RS485CommitUCISection("vpnconfig1").then(function(res){
                                                              	
								if (res != 0) 
                                                                {
									alert("Error:New Event Configuration");
                                                                }
                                                                else 
                                                                {
                                                                        location.reload();
                                                                }
                                                        });
                                                };
                                        };
                                }); 
                        }
                });
        },
        
        RS485ConfigSectionRemove: function(ev) 
        {
		var self = ev.data.self;
		var RS485ConfigSectionName = ev.data.RS485ConfigSectionName;
		//self.RS485DeleteUCISection("vpnconfig1","RS485Config",RS485ConfigSectionName).then(function(rv){
		self.RS485DeleteUCISection("vpnconfig1","vpnconfig1",RS485ConfigSectionName).then(function(rv){
			if(rv == 0){
				self.RS485CommitUCISection("vpnconfig1").then(function(res){
					if (res != 0)
                    {
						alert("Error: Delete Configuration");
					}
					else 
                                        {
						location.reload();
					}
				});
			};
		});
	},
        
        RS485ConfigSectionEdit: function(ev) 
        {
                var self = ev.data.self;
                var RS485ConfigSectionName = ev.data.RS485ConfigSectionName;
                return self.RS485ConfigCreateForm(L.cbi.Modal,RS485ConfigSectionName).show();
        },
        
        execute:function()
        {
		
	var self = this;
              
        var m = new L.cbi.Map('vpnconfig1', {
					});
	        
        var s = m.section(L.cbi.NamedSection, 'general', {
            caption:L.tr('General Configurations')
        });
        
        
		s.option(L.cbi.CheckboxValue, 'enableipsecgeneral', {
                  caption:        L.tr('Enable IPSEC'),         
				  optional:    true
                });
                
       s.option(L.cbi.CheckboxValue, 'enableopenvpngeneral', {
                  caption:        L.tr('Enable Openvpn'),         
				  optional:    true
                }); 
                
     /* s.option(L.cbi.CheckboxValue, 'enablepptp', {
                  caption:        L.tr('Enable PPTP'),         
				  optional:    true
                });  */              
			           
          
       m.insertInto('#section_vpn_general');  
       
       var m1 = new L.cbi.Map('vpnconfig1', {
					});
       
        var s1 = m1.section(L.cbi.NamedSection, 'pptp', {
            caption:L.tr('PPTP Configurations')
        });
        
        
       //PPTP
       
        s1.option(L.cbi.InputValue, 'pptpserver', {
        caption: L.tr('Server'),
        }).depends({'enablepptp' : '1'});
        
        s1.option(L.cbi.InputValue, 'pptpuser', {
        caption: L.tr('User'),
        }).depends({'enablepptp' : '1'});
        
         s1.option(L.cbi.PasswordValue,'pptppassword',{
         caption: L.tr('Password'),
         optional: true 
        }).depends({'enablepptp' : '1'});
             
       m1.insertInto('#section_pptp');
       
         
          
                 var self = this;
                $('#AddNewconnectionipsec').click(function() {  
                        self.RS485ConfigSectionAdd();
                });
              //  self.RS485GetUCISections("vpnconfig1","RS485Config").then(function(rv) {
              self.RS485GetUCISections("vpnconfig1","vpnconfig1").then(function(rv) {
                        self.RS485RenderContents(rv);
                });           
               
              $('#update_ipsec').click(function() {
            L.ui.loading(true);
            self.updatefirewallconfig('configure').then(function(rv) {
				//alert(rv);
               // L.ui.loading(false);
                    L.ui.dialog(
                        L.tr('update configuration'),[
                            $('<pre />')
                            .addClass('alert alert-success')
                            .text(rv)
                        ],
                       
                        { style: 'close'}
                    );
                    
                   });
                   L.ui.loading(false);
            });
            
       //Openvpn     
                $('#btn_upload').click(function() {
	
                      self.countcertficates().then(function(rv) {
						
					
					
					//alert(rv);
					//var count = '1';
					 if(rv < '1')
					 {
						 self.handleArchiveUpload();
					  }
					  else
					  {
						 L.ui.loading(false);
							L.ui.dialog(

									L.tr('Upload Certificates error'),[
										   $('<p />').text(L.tr('Output')),
											$('<pre />')
													.addClass('alert alert-danger')
													.text("Please click on Delete button to delete existing .ovpn files and then click on Upload button to upload the new .ovpn file."),
									],
									{ style: 'close',
											close:function()
											{
													location.reload();
											}
									}
							); 
						}
						
					});
                });
                
         $('#btn_delete').click(function() {

						self.deletecertficates().then(function(rv) {
																
																L.ui.loading(false);
																L.ui.dialog(

																		L.tr('Delete Openvpn certificates'),[
																			   $('<p />').text(L.tr('Output')),
																				$('<pre />')
																						.addClass('alert alert-info')
																						.text("Openvpn certificates Deleted"),
																		],
																		{ style: 'close',
																				close:function()
																				{
																						location.reload();
																				}
																		}
																);
													 });
				});      
               
          self.RS485GetUCISections("vpnconfig1","genericconfig").then(function(rv) {
				for (var key in rv) 
				{
						if (rv.hasOwnProperty(key)) 
						{
								var obj = rv[key];
								var running = obj.openvpnrunning;
								if(running=='0')
								{
										var AppstartCreateButton=$('<button/>', {
												class: 'btn btn-primary',
												text: 'Start',
												id: 'start',
												title: 'Start the Apps',
												style: 'width:110px',
												on : {
														click: function(e) {
																L.ui.loading(true);
																self.startopenvpnservice().then(function(rv) {
																		L.ui.loading(false);
																		L.ui.dialog(
																		
																				L.tr('Started the openvpn service'),[
																					   $('<p />').text(L.tr('Output')),
																						$('<pre />')
																								.addClass('alert alert-info')
																								.text(rv),
																				],
																				{ style: 'close',
																						close:function()
																						{
																								location.reload();
																						}
																				}
																		);
															 });
														}
												}
										});
										$("#btn-group").append(AppstartCreateButton);
								}
								
								if(running=='1')
								{
										var AppStopCreateButton=$('<button/>', {
												class: 'btn btn-danger',
												text: 'Stop',
												title: 'Stop the Apps',
												style: 'width:110px',
												on : {
														click: function(e) {
																 L.ui.loading(true);
																self.stopopenvpnservice().then(function(rv) {
																		L.ui.loading(false);
																		L.ui.dialog(
																				L.tr('Stopped the openvpn service'),[
																						$('<pre />')
																								.addClass('alert alert-danger')
																								.text(rv),
																				],
																				{ style: 'close',
																						close:function()
																						{
																							
																								location.reload();
																						}
																				}
																		);
															});
														}
												}
										});
										$("#btn-group").append(AppStopCreateButton);
								}
						}
				}
          });
                
                
            //m.insertInto('#map');
          //  m.appendTo('#sectiontab_vpn_general');
          
          s.commit=function(){
			
                 self.updateopenvpnconfig('enableopenvpn').then(function(rv) {
					 //alert("Enabling openvpn");
				               
                });
           }
			                
        }
      
       
            
        
});


