#!/bin/sh

while true
do
/bin/Wifi_restart.sh
sleep 10
done
