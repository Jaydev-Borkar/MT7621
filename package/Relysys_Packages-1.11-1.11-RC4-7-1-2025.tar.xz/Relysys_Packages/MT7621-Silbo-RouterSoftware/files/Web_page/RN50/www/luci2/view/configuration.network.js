L.ui.view.extend({

    title: L.tr('Network Configuration'),
    //description: L.tr('<b>Please click on update after editing or deleting any changes.</b>'),
     
     fGetUCISections: L.rpc.declare({
		object: 'uci',
		method: 'get',
		params: [ 'config', 'type' ],
		expect: { values: {} }
	}),
	
	fCreateUCISection:  L.rpc.declare({
		object: 'uci',
		method: 'add',
		params: [ 'config', 'type', 'name', 'values' ]
	}),
	
	drfCreateUCISection:  L.rpc.declare({
		object: 'uci',
		method: 'add',
		params: [ 'config', 'type', 'values' ]
	}),
	
	
	fDeleteUCISection:  L.rpc.declare({
		object: 'uci',
		method: 'delete',
		params: [ 'config','type','section' ]
	}),
	
	fCommitUCISection:  L.rpc.declare({
		object: 'uci',
		method: 'commit',
		params: [ 'config' ]
	}),
    
    deletefirewallconfig: L.rpc.declare({
        object: 'rpc-updatewanconfig',
        method: 'delete',
        params: [ 'SectionName' ],
        expect: { output: '' }
    }),
    
       updateinterfaceconfig: L.rpc.declare({
        object: 'rpc-updatewanconfig',
        method: 'configure',
        params: ['application','action'],
        expect: { output: '' }
        }),

	
	pbfCreateForm: function(mapwidget, pbfSectionID, pbfSectionType, pbfInterfaceName)
	{
		var self = this;
		
		if (!mapwidget)
			mapwidget = L.cbi.Map;
		
		if(pbfSectionType == "Dredirect") {
			var FormContent = self.pbCreateFormCallback;
		}
		
		var map = new mapwidget('networkinterfaces', {
			prepare:    FormContent,
			pbfSection:   pbfSectionID,
			pbfInterfaceName: pbfInterfaceName
		});
		return map;
	},
	
	
		drfCreateForm: function(mapwidget, drfSectionID, drfSectionType)
	    {
		var self = this;
		
		if (!mapwidget)
			mapwidget = L.cbi.Map;
		
		if(drfSectionType == "relay") {
			var FormContent = self.drCreateFormCallback;
			//~ alert("create form");
		}
		
		var map = new mapwidget('dhcprelayconfig', {
			prepare:    FormContent,
			drfSection:   drfSectionID,
			//fInterfaceName: fInterfaceName
		});
		//~ alert("after create form");
		return map;
	},
	
	pbCreateFormCallback: function()
	{
		var map = this;
		var pbSectionID = map.options.pbfSection;
		var pbfInterfaceName = map.options.pbfInterfaceName;
		
		map.options.caption = L.tr('Network Interfaces');
		
		var s = map.section(L.cbi.NamedSection, pbSectionID, {
			collabsible: true,
			anonymous:   true,
			 tabbed:      true
		});

      s.option(L.cbi.DummyValue, 'connectionsettings', {
         caption: L.tr(''),
         //  caption: L.tr(a),
      }).ucivalue = function () {
         var id = "<h5><b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbspNetwork Configuration Settings </b> </h3>";
         return id;
      };

		
	s.option(L.cbi.DummyValue, 'ifname', {
			caption:     L.tr('Physical device'),
		});
		
	s.option(L.cbi.ListValue, 'type', {
			caption:     L.tr('Type'),
		}).value("LAN",L.tr("LAN"))
	      .value("WAN",L.tr("WAN"));	
		
       s.option(L.cbi.ListValue,'protocol_lan',{          
                 caption:L.tr('Protocol'), 
		}).depends({'type':'LAN'})   
		.value("static_lan", L.tr('Static'));
            
       s.option(L.cbi.ListValue,'protocol',{          
                 caption:L.tr('Protocol'), 
		}).depends({'type':'WAN'}) 
		  .value("static", L.tr('Static'))
          .value("dhcpclient", L.tr('DHCP'))
          .value("pppoe",L.tr("PPPoE"));
         
       s.option(L.cbi.InputValue, 'staticIP', {
           caption: L.tr('IPV4 IP Address'), 
           datatype: 'ip4addr',
           optional: true
        }).depends({'type':'LAN','protocol_lan':'static_lan'})
        .depends({'type':'WAN','protocol':'static'});
          
        s.option(L.cbi.InputValue, 'staticnetmask', {
           caption: L.tr('IPV4 Static Netmask'), 
           datatype: 'ip4addr',
           optional: true
        }).depends({'type':'LAN','protocol_lan':'static_lan'})
        .depends({'type':'WAN','protocol':'static'});
        
        s.option(L.cbi.InputValue, 'staticgateway', {
           caption: L.tr('Static Gateway'), 
           datatype: 'ip4addr',
           optional: true
        }).depends({'type':'WAN','protocol':'static'});
      
      s.option(L.cbi.InputValue, 'dhcpgateway', {
           caption: L.tr('DHCP Gateway'), 
           datatype: 'ip4addr',
           optional: true
        }).depends({'type':'WAN','protocol':'dhcpclient'}); 
          
   		   s.option(L.cbi.DummyValue, 'macaddr', {
           caption: L.tr('Mac Address')
        });
        
   		   s.option(L.cbi.InputValue, 'macaddress', {
           caption: L.tr('Override Mac Address'), 
           datatype: 'macaddr',
           optional: true
        });
        
        s.option(L.cbi.InputValue, 'EthernetClientPppoeUsername', {
           caption: L.tr('Username'), 
        }).depends({'type':'WAN','protocol':'pppoe'});   
        
        s.option(L.cbi.InputValue, 'EthernetClientPppoePassword', {
           caption: L.tr('Password'), 
        }).depends({'type':'WAN','protocol':'pppoe'});  
        
        s.option(L.cbi.InputValue, 'EthernetClientPppoeAccessConcentrator', {
           caption: L.tr('Access Concentrator'), 
        }).depends({'type':'WAN','protocol':'pppoe'});  
        
         s.option(L.cbi.InputValue, 'EthernetClientPppoeServiceName', {
           caption: L.tr('Service Name'), 
        }).depends({'type':'WAN','protocol':'pppoe'}); 
        
         s.option(L.cbi.InputValue, 'pppoegateway', {
           caption: L.tr('Gateway'),
           placeholder: "0.0.0.0", 
           datatype: 'ip4addr',
        }).depends({'type':'WAN','protocol':'pppoe'}); 

         s.option(L.cbi.CheckboxValue, 'enable_dhcpserver', {
           caption: L.tr('Enable DHCP Server'),
        }).depends({'protocol_lan':'static_lan','type':'LAN'});
        
        s.option(L.cbi.InputValue, 'ServerDHCPrange', {
           caption: L.tr('DHCP Start Address'), 
           datatype: 'uinteger',
           optional: true
        }).depends({'protocol_lan':'static_lan','type':'LAN','enable_dhcpserver':'1'});
        
          s.option(L.cbi.InputValue, 'ServerDHCPlimit', {
           caption: L.tr('DHCP Limit'),
           datatype: 'uinteger',
           optional: true 
        }).depends({'protocol_lan':'static_lan','type':'LAN','enable_dhcpserver':'1'});

        s.option(L.cbi.ListValue, 'leasetime_duration', {
          caption: L.tr('Lease Time Duration'),
       }).value("h", L.tr('Hours-(H)'))
          .value("m", L.tr('Minutes-(M)'))
          .value("s", L.tr('Seconds-(S)'))
          .depends({'protocol_lan':'static_lan','type':'LAN','enable_dhcpserver':'1'});
                 
         s.option(L.cbi.InputValue, 'leasetime', {
            caption: L.tr('Lease time'), 
            datatype: 'uinteger',
              placeholder:'12',
            optional: true
         }).depends({'protocol_lan':'static_lan','type':'LAN','enable_dhcpserver':'1'});
         
         	s.option(L.cbi.CheckboxValue, 'custom_DHCP_options', {
           caption: L.tr('Custom DHCP options for LAN clients'),
        }).depends({'protocol_lan':'static_lan','type':'LAN','enable_dhcpserver':'1'}); 
		
		s.option(L.cbi.CheckboxValue, 'enable_dns', {
           caption: L.tr('Custom DNS (Option 6)'),
         }).depends({'protocol_lan':'static_lan','type':'LAN','custom_DHCP_options':'1','enable_dhcpserver':'1'});
        	  
		 s.option(L.cbi.DynamicList, 'ServerStaticDnsServer', {
		   caption:     L.tr('Custom DNS Server Address'),
			datatype: 'ip4addr',
		   placeholder:'8.8.8.8',
		   optional:     true
		 }).depends({'enable_dns':'1','protocol_lan':'static_lan','type':'LAN','custom_DHCP_options':'1','enable_dhcpserver':'1'});
         
        s.option(L.cbi.CheckboxValue, 'enable_zoneforward', {
           caption: L.tr('Create Firewall Zone'),
        });
        
         s.option(L.cbi.CheckboxValue, 'internetoverinterface', {
           caption: 'Internet Over ' + pbfInterfaceName,
        }).depends({'type':'LAN'}); 

		 s.option(L.cbi.CheckboxValue, 'enable_bridge', {
           caption: L.tr('Enable Bridge'),
        });
        
         s.option(L.cbi.NetworkList, 'bridge_interfaces', {
           caption: L.tr('Interfaces'), 
           multiple: true,
            customInput: true,
            labelName: 'device',
           optional: true
        }).depends({'enable_bridge':'1'});
        
        s.option(L.cbi.CheckboxValue, 'enable_relay', {
           caption: L.tr('Enable DHCP Relay'),
        }).depends({'type':'LAN','protocol_lan':'static_lan'})
        .depends({'type':'WAN','protocol':'static'})
           .depends({'type':'WAN','protocol':'dhcpclient'});
        
         s.option(L.cbi.InputValue, 'relay_serverip', {
           caption: L.tr('Relay Server IP'), 
           //optional: true
           datatype: 'ip4addr',
        }).depends({'type':'LAN','protocol_lan':'static_lan','enable_relay':'1'})
        .depends({'type':'WAN','protocol':'static','enable_relay':'1'})
        .depends({'type':'WAN','protocol':'dhcpclient','enable_relay':'1'});
		
        s.option(L.cbi.CheckboxValue, 'advanced_settings', {
           caption: L.tr('Advanced Settings'),
        }); 
       
        //s.option(L.cbi.InputValue, 'gatewaymetric', {
           //caption: L.tr('Gateway Metric'), 
           //optional: true
        //}).depends({'advanced_settings':'1'});
        
        s.option(L.cbi.InputValue, 'broadcast', {
           caption: L.tr('Broadcast'), 
           datatype: 'ip4addr',
           optional: true
        }).depends({'advanced_settings':'1'});
        
         s.option(L.cbi.InputValue, 'mtu', {
           caption: L.tr('Override MTU'),
           placeholder:'1500', 
           optional: true
        }).depends({'advanced_settings':'1'});
		 
        s.option(L.cbi.CheckboxValue, 'delegate', {
           caption: L.tr('Delegate'),
        }).depends({'advanced_settings':'1'});
        
        s.option(L.cbi.CheckboxValue, 'force_link', {
           caption: L.tr('Force Link'),
        }).depends({'advanced_settings':'1'});
                
        s.option(L.cbi.CheckboxValue, 'enableipv4routetable', {
           caption: L.tr('IPV4 Route Table'),  
        }).depends({'advanced_settings':'1'});
        
        s.option(L.cbi.InputValue, 'ip4table', {
           caption: L.tr('Table No'), 
            datatype: 'uinteger',
           optional: true
        }).depends({'advanced_settings':'1','enableipv4routetable':'1'});

   s.option(L.cbi.DummyValue, '', {
    caption: L.tr('')
    }).depends({'type':'WAN'})
    .ucivalue = function() {
    var noteText = "<b>Note:if required, add an interface in Multi-WAN page under Settings</b>";
    return noteText;
    };
 },  
 
      drCreateFormCallback: function()
	  {
		var map = this;
		var drSectionID = map.options.drfSection;
		//var fInterfaceName = map.options.fInterfaceName;
		
		map.options.caption = L.tr('DHCP Relay Server');
		
		var s = map.section(L.cbi.NamedSection, drSectionID, {
			collabsible: true,
			anonymous:   true,
			 tabbed:      true
		});
		
	s.option(L.cbi.ComboBox, 'interface', {
			caption:     L.tr('Interface'),
		}).value("none", L.tr('--please choose--'))
		  .value("ra0",L.tr("ra0"))	
	      .value("rai0",L.tr("rai0"));	
		
     s.option(L.cbi.InputValue, 'startip', {
			caption:     L.tr('Start IP Address'),
			datatype: 'ip4addr',
			optional:      'true'
		}); 
	
     
      s.option(L.cbi.InputValue, 'endip', {
			caption:     L.tr('End IP Address'),
			datatype: 'ip4addr',
			optional:      'true'
			
		}); 
     
      s.option(L.cbi.InputValue, 'netmask', {
			caption:     L.tr('Netmask'),
			datatype: 'ip4addr',
			optional:      'true'
		}); 
		
	s.option(L.cbi.InputValue, 'leasetime', {
			caption:     L.tr('Lease Time'),
			optional:      'true'
		}); 	
		
     
 },  
 
		
	pbRenderContents: function(rv)
	{
		var self = this;

		var list = new L.ui.table({
			columns: [ 
			{ 
				caption: L.tr('Interface Name'),
        width: '10%',
        align: 'left',
				format:  function(v,n) {
					var div = $('<small />').attr('id', 'pbinterface_%s'.format(n));
					return div.append(v);
				}
		    },{ 
				caption: L.tr('Physical Device'),
        width: '10%',
        align: 'center',
				format:  function(v,n) {
					var div = $('<small />').attr('id', 'pbphysicaldevice_%s'.format(n));
					return div.append(v);
				}
		    },{ 
				caption: L.tr('Mac Address'),
        width: '10%',
               align: 'center',
				format:  function(v,n) {
					var div = $('<small />').attr('id', 'pbphysicaldevice_%s'.format(n));
					return div.append(v);
				}
			},{ 
				caption: L.tr('Type'),
        width: '10%',
        align: 'center',
				format:  function(v,n) {
					var div = $('<small />').attr('id', 'pbtype_%s'.format(n));
					return div.append(v);
				}
			},{
				caption: L.tr('Actions'),
        width: '10%',
        align: 'center',
				format:  function(v, n) {
					return $('<div />')
						.addClass('btn-group btn-group-sm')
						.append(L.ui.button(L.tr('Edit'), 'primary', L.tr('Edit Port Forward'))
							.click({ self: self, pbfSectionID: v, pbfSectionType: "Dredirect" ,interfaceName: rv[v].interface}, self.pbfSectionEdit))
						.append(L.ui.button(L.tr('Delete'), 'danger', L.tr('Delete Port Forward'))
							.click({ self: self, pbSectionID: v }, self.pbSectionRemove));
				}
			}]
		});
		
		for (var key in rv) 
                {
                        if (rv.hasOwnProperty(key)) 
                        {
                                var obj = rv[key];
								var Interface = obj.interface
								var PhysicalDevice = obj.ifname
								var Type = obj.type
								var Macaddr = obj.macaddr
			                
                                 list.row([Interface,PhysicalDevice,Macaddr,Type,key]); 
                        }
                }
		
		$('#section_network_interface_port').append(list.render());		
	},

  
    drRenderContents: function(rv)
	{
		var self = this;

		var list1 = new L.ui.table({
			columns: [ 
			{ 
				caption: L.tr('Interface'),
				format:  function(v,n) {
					var div = $('<small />').attr('id', 'drinterface_%s'.format(n));
					return div.append(v);
				}
		    },{ 
				caption: L.tr('Start IP Address'),
				format:  function(v,n) {
					var div = $('<small />').attr('id', 'drstartip_%s'.format(n));
					return div.append(v);
				}
			},{ 
				caption: L.tr('End IP Address'),
				format:  function(v,n) {
					var div = $('<small />').attr('id', 'drdhcplimit_%s'.format(n));
					return div.append(v);
				}
			},{ 
				caption: L.tr('Netmask'),
				format:  function(v,n) {
					var div = $('<small />').attr('id', 'drnetmask_%s'.format(n));
					return div.append(v);
				}
			},{ 
				caption: L.tr('Lease Time'),
				format:  function(v,n) {
					var div = $('<small />').attr('id', 'drleasetime_%s'.format(n));
					return div.append(v);
				}
			},{
				caption: L.tr('Actions'),
				format:  function(v, n) {
					return $('<div />')
						.addClass('btn-group btn-group-sm')
						.append(L.ui.button(L.tr('Edit'), 'primary', L.tr('Edit Port Forward'))
							.click({ self: self, drfSectionID: v, drfSectionType: "relay" ,interfaceName: rv[v].interface}, self.drfSectionEdit))
						.append(L.ui.button(L.tr('Delete'), 'danger', L.tr('Delete Port Forward'))
							.click({ self: self, drSectionID: v }, self.drSectionRemove));
				}
			}]
		});
		
		for (var key in rv) 
                {
                        if (rv.hasOwnProperty(key)) 
                        {
                                var obj = rv[key];
								var interface = obj.interface
								var startip = obj.startip
								var endip = obj.endip
								var netmask = obj.netmask
								var leasetime = obj.leasetime
			                
                                 list1.row([interface,startip,endip,netmask,leasetime,key]); 
                        }
                }
		
		$('#section_dhcprelay_port').append(list1.render());		
	},
  
  
  
  
  
	pbSectionRemove: function(ev) {
		var self = ev.data.self;
		var pbSectionID = ev.data.pbSectionID;
		self.deletefirewallconfig(pbSectionID).then(function(rv) {
		self.fDeleteUCISection("networkinterfaces","redirect",pbSectionID).then(function(rv){
			if(rv == 0){
				self.fCommitUCISection("networkinterfaces").then(function(res){
						//if (res != 0){
					//		alert("Error: Delete Port Forward Configuration");
						//}
						//else {
							location.reload();
						//}
				});
			};
		});
	});	
		
	},
	
	
	drSectionRemove: function(ev) {
		var self = ev.data.self;
		var drSectionID = ev.data.drSectionID;
		self.fDeleteUCISection("dhcprelayconfig","relay",drSectionID).then(function(rv){
			if(rv == 0){
				self.fCommitUCISection("dhcprelayconfig").then(function(res){
						if (res != 0){
							alert("Error: Delete Port Forward Configuration");
						}
						else {
							location.reload();
						}
				});
			};
		});
	//});	
		
	},
	
	
	
	pbSectionAdd: function () 
	{
		var self = this;
		var pbinterface = $('#field_netint_redirect_newRedirect_interfacename').val();		
		var pbphysicaldevice = $('#field_vlan_redirect_newRedirect_physicaldevice').val();
		var pbtype = $('#field_lan_wan_redirect_newRedirect_type').val();
		
		var SectionOptions = {interface:pbinterface,ifname:pbphysicaldevice,type:pbtype,enable_dns:"0",EthernetClientPptpMppeEncryption:"0",enable_dhcpserver:"0",enable_zoneforward:"0",internetoverinterface:"0"};
			self.fCreateUCISection("networkinterfaces","redirect",pbinterface,SectionOptions).then(function(rv){
			if(rv){
				if (rv.section){
					self.fCommitUCISection("networkinterfaces").then(function(res){
						//if (res != 0) {
						//	alert("Error: New Port Forward Configuration");
					//	}
						//else {
							location.reload();
					//	}
					});
					
				};
			};
		});
		
	},
     
    drSectionAdd: function () 
	{
		var self = this;
		var drinterface = $('#field_dhcprelay_redirect_newRedirect_interfacename').val();		
		var drstartip = $('#field_dhcprelay_redirect_newRedirect_startip').val();
		var drendip = $('#field_dhcprelay_redirect_newRedirect_endip').val();
		var drnetmask = $('#field_dhcprelay_redirect_newRedirect_netmask').val();
		var drleasetime = $('#field_dhcprelay_redirect_newRedirect_leasetime').val();
		
		if (drinterface === "custom")
		{
			drinterface = $('#field_dhcprelay_redirect_newRedirect_interfacenamezone').val();
		}
		
		var SectionOptions = {interface:drinterface,startip:drstartip,endip:drendip,netmask:drnetmask,leasetime:drleasetime};
			//self.fCreateUCISection("networkinterfaces","redirect",pbinterface,SectionOptions).then(function(rv){
				self.drfCreateUCISection("dhcprelayconfig","relay",SectionOptions).then(function(rv){
			if(rv){
				if (rv.section){
					self.fCommitUCISection("dhcprelayconfig").then(function(res){
						if (res != 0) {
							alert("Error: New Port Forward Configuration");
						}
						else {
							location.reload();
						}
					});
					
				};
			};
		});
		
	},
     
   
	pbfSectionEdit: function(ev) {
		var self = ev.data.self;
		var pbfSectionID = ev.data.pbfSectionID;
		var pbfSectionType = ev.data.pbfSectionType;
		var pbfInterfaceName = ev.data.interfaceName;
		
		return self.pbfCreateForm(L.cbi.Modal, pbfSectionID, pbfSectionType, pbfInterfaceName).show();
		
	},
   
      drfSectionEdit: function(ev) {
		var self = ev.data.self;
		var drfSectionID = ev.data.drfSectionID;
		var drfSectionType = ev.data.drfSectionType;
		
			return self.drfCreateForm(L.cbi.Modal, drfSectionID, drfSectionType).show();
	},
   

        execute:function() {
		
		ValidateIPv4 = function (ev) {
            var input = ev.target.value;
            if (L.parseIPv4(input)) {
                document.getElementById('validateIPAddress').style.display = 'none';
            }
            else {
                document.getElementById('validateIPAddress').style.display = 'block';
            }
        };
		
		ValidateIPv42 = function (ev) {
            var input = ev.target.value;
            if (L.parseIPv4(input)) {
                document.getElementById('validateIPAddress2').style.display = 'none';
            }
            else {
                document.getElementById('validateIPAddress2').style.display = 'block';
            }
        };
		
			
	   
        $('#AddNewPortForward').click(function() {          
			self.pbSectionAdd();
		});
		   
		
		 $('#AddNewRelay').click(function() {          
			self.drSectionAdd();
		});   
		        
        var self = this;
		this.fGetUCISections("networkinterfaces","redirect").then(function(rv) {
			self.pbRenderContents(rv);   
		});
		
		        
        var self = this;
		this.fGetUCISections("dhcprelayconfig","relay").then(function(rv) {
			self.drRenderContents(rv);   
		});
		
		 $('#btn_update').click(function() {
                        L.ui.loading(true);
                        self.updateinterfaceconfig('Update','updateinterface').then(function(rv){
                            L.ui.loading(false);
                                L.ui.dialog(
                                    L.tr('Updated interface configuration'),[
                                        $('<pre />')
                                        .addClass('alert alert-success')
                                        .text(rv)
                                    ],
                                    { style: 'close'}
                                );
                                
                               });
                    });

   var m2 = new L.cbi.Map('sysconfig', {
                });     
   
   var s2 = m2.section(L.cbi.NamedSection, 'wificonfig', {
        caption:L.tr('')
    });
       s2.option(L.cbi.CheckboxValue, 'wifi1enable', {
		caption: L.tr('Enable Wifi'),
		optional: true
		}).depends({'wificonfig' : '1'}); 
		
       s2.option(L.cbi.CheckboxValue, 'InternetOverWifi', {
		caption: L.tr('Internet Over Wifi'),
		optional: true
		}).depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'ap'})
		.depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'apsta'}); 
		
        s2.option(L.cbi.DummyValue, 'generalsettings', {
		  caption: L.tr(''),
        }).depends({'wificonfig':'1','wifi1enable':'1'})
        .ucivalue=function()
          {
            var id="<h3><b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp2.4Ghz WIFI Settings</b> </h3>";
            return id;
          };  
          
        //Wifi Devices
        s2.option( L.cbi.ListValue, 'wifi1mode', {
          caption:        L.tr('Radio Mode'),
		}).depends({'wificonfig':'1','wifi1enable':'1'})
		.value('ap', L.tr('Access Point'))
		.value('sta', L.tr('Client only'))
		.value('apsta', L.tr('Access Point and Client'));  
        
        s2.option( L.cbi.ListValue, 'wifi1protocol', {
		caption:	L.tr('WirelessMode'),
		}).depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'ap'})
		.depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'apsta'})
		.value('0', L.tr('B/G mixed'))
		.value('1', L.tr('B only'))
		.value('4', L.tr('G only'))
		.value('9', L.tr('B/G/GN mode'))
		.value('6', L.tr('N_in_2G mode", --HE Wireless Mode'));
        
          
         s2.option( L.cbi.ListValue, 'CountryCode', {
		caption:	L.tr('Country Code'),
		}).depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'ap'})
		.depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'apsta'})
		.value('none', L.tr('Please choose'))
		.value('AF', L.tr('Afghanistan'))
        .value('AX', L.tr('Åland Islands'))
        .value('AL', L.tr('ALBANIA'))    
        .value('AS', L.tr('American Samoa'))  
        .value('AD', L.tr('Andorra'))  
        .value('AO', L.tr('Angola'))  
        .value('AI', L.tr('Anguilla')) 
        .value('AQ', L.tr('Antarctica')) 
        .value('AG', L.tr('Antigua and Barbuda')) 
        .value('AR', L.tr('ARGENTINA'))  
        .value('AM', L.tr('ARMENIA'))  
        .value('AW', L.tr('Aruba'))  
        .value('AU', L.tr('AUSTRALIA'))  
        .value('AT', L.tr('AUSTRIA'))  
        .value('AZ', L.tr('AZERBAIJAN'))  
        .value('BH', L.tr('BAHRAIN'))  
        .value('BD', L.tr('Bangladesh'))  
        .value('BB', L.tr('Barbados'))  
        .value('BY', L.tr('BELARUS'))  
        .value('BE', L.tr('BELGIUM'))  
        .value('BZ', L.tr('BELIZE'))  
        .value('BJ', L.tr('Benin'))  
        .value('BM', L.tr('Bermuda'))  
        .value('BT', L.tr('Bhutan'))  
        .value('BO', L.tr('BOLIVIA'))  
        .value('BQ', L.tr('Bonaire'))  
        .value('BQ', L.tr('Sint Eustatius'))  
        .value('BQ', L.tr('Saba'))  
        .value('BA', L.tr('Bosnia and Herzegovina'))  
        .value('BW', L.tr('Botswana'))  
        .value('BV', L.tr('Bouvet Island'))  
        .value('BR', L.tr('BRAZIL'))  
        .value('IO', L.tr('British Indian Ocean Territory'))  
        .value('BN', L.tr('BRUNEI DARUSSALAM'))  
        .value('BG', L.tr('BULGARIA'))  
        .value('BF', L.tr('Burkina Faso'))  
        .value('BI', L.tr('Burundi'))  
        .value('CV', L.tr('Cabo Verde'))  
        .value('KH', L.tr('Cambodia'))  
        .value('CM', L.tr('Cameroon'))  
        .value('CA', L.tr('CANADA'))  
        .value('KY', L.tr('Cayman Islands '))  
        .value('CF', L.tr('Central African Republic'))  
        .value('TD', L.tr('Chad'))  
        .value('CL', L.tr('CHILE'))  
        .value('CN', L.tr('CHINA'))  
        .value('CX', L.tr('Christmas Island'))  
        .value('CC', L.tr('Cocos (Keeling) Islands (the)'))  
        .value('CO', L.tr('COLOMBIA'))  
        .value('KM', L.tr('Comoros'))  
        .value('CD', L.tr('Congo(the Democratic Republic of the)'))  
        .value('CG', L.tr('Congo'))  
        .value('CK', L.tr('Cook Islands'))    
        .value('CR', L.tr('COSTA RICA'))  
        .value('CI', L.tr('Côte dIvoire'))  
        .value('HR', L.tr('CROATIA'))  
        .value('CU', L.tr('Cuba'))  
        .value('CW', L.tr('Curaçao'))  
        .value('CY', L.tr('CYPRUS'))  
        .value('CZ', L.tr('CZECH REPUBLIC'))  
        .value('DK', L.tr('DENMARK'))  
        .value('DJ', L.tr('Djibouti'))  
        .value('DM', L.tr('Dominica'))  
        .value('DO', L.tr('DOMINICAN REPUBLIC'))  
        .value('EC', L.tr('ECUADOR'))  
        .value('EG', L.tr('EGYPT'))  
        .value('SV', L.tr('EL SALVADOR'))  
        .value('GQ', L.tr('Equatorial Guinea'))  
        .value('ER', L.tr('Eritrea'))  
        .value('EE', L.tr('ESTONIA'))  
        .value('ET', L.tr('Ethiopia'))  
        .value('FK', L.tr('Falkland Islands'))  
        .value('FO', L.tr('Faroe Islands'))  
        .value('FJ', L.tr('Fiji'))  
        .value('FI', L.tr('FINLAND'))  
        .value('FR', L.tr('FRANCE'))  
        .value('GF', L.tr('French Guiana'))  
        .value('PF', L.tr('French Polynesia'))  
        .value('TF', L.tr('French Southern Territories'))  
        .value('GA', L.tr('Gabon'))  
        .value('GM', L.tr('Gambia'))  
        .value('GE', L.tr('GEORGIA'))  
        .value('DE', L.tr('GERMANY'))  
        .value('GH', L.tr('Ghana'))  
        .value('GI', L.tr('Gibraltar'))  
        .value('GR', L.tr('GREECE'))  
        .value('GL', L.tr('Greenland'))  
        .value('GD', L.tr('Grenada'))  
        .value('GP', L.tr('Guadeloupe'))  
        .value('GU', L.tr('Guam'))  
        .value('GT', L.tr('GUATEMALA'))  
        .value('GG', L.tr('Guernsey'))  
        .value('GW', L.tr('Guinea-Bissau'))  
        .value('GY', L.tr('Guyana'))  
        .value('HT', L.tr('Haiti'))  
        .value('HM', L.tr('Heard Island and McDonald Islands'))  
        .value('VA', L.tr('Holy See'))  
        .value('HN', L.tr('HONDURAS'))  
        .value('HK', L.tr('HONG KONG'))  
        .value('HU', L.tr('HUNGARY'))  
        .value('IS', L.tr('ICELAND'))  
        .value('IN', L.tr('INDIA'))  
        .value('ID', L.tr('INDONESIA'))  
        .value('IR', L.tr('IRAN'))  
        .value('IQ', L.tr('Iraq'))  
        .value('IE', L.tr('IRELAND'))  
        .value('IL', L.tr('ISRAEL'))  
        .value('IT', L.tr('ITALY'))  
        .value('JM', L.tr('Jamaica'))  
        .value('JP', L.tr('JAPAN'))  
        .value('JE', L.tr('Jersey'))  
        .value('JO', L.tr('JORDAN'))  
        .value('KZ', L.tr('KAZAKHSTAN'))  
        .value('KE', L.tr('Kenya'))  
        .value('KI', L.tr('Kiribati'))  
        .value('KP', L.tr('KOREA DEMOCRATIC'))  
        .value('KR', L.tr('REPUBLIC OF KOREA '))  
        .value('KW', L.tr('KUWAIT'))  
        .value('KG', L.tr('Kyrgyzstan'))  
        .value('LA', L.tr('Lao People Democratic Republic'))  
        .value('LV', L.tr('LATVIA'))  
        .value('LB', L.tr('LEBANON'))  
        .value('LS', L.tr('Lesotho'))  
        .value('LR', L.tr('Liberia'))  
        .value('LY', L.tr('Libya'))  
        .value('LI', L.tr('LIECHTENSTEIN'))  
        .value('LT', L.tr('LITHUANIA'))  
        .value('LU', L.tr('LUXEMBOURG'))  
        .value('MO', L.tr('MACAO'))  
        .value('MK', L.tr('MACEDONIA'))  
        .value('MG', L.tr('Madagascar'))  
        .value('MW', L.tr('Malawi'))  
        .value('MY', L.tr('MALAYSIA'))  
        .value('MV', L.tr('Maldives'))  
        .value('ML', L.tr('Mali'))  
        .value('MT', L.tr('Malta'))  
        .value('MH', L.tr('Marshall Islands'))  
        .value('MQ', L.tr('Martinique'))  
        .value('MR', L.tr('Mauritania'))  
        .value('MU', L.tr('Mauritius'))  
        .value('YT', L.tr('Mayotte'))  
        .value('MX', L.tr('MEXICO'))  
        .value('FM', L.tr('Micronesia'))  
        .value('MD', L.tr('Moldova'))  
        .value('MC', L.tr('MONACO'))  
        .value('MN', L.tr('Mongolia'))  
        .value('ME', L.tr('Montenegro'))  
        .value('MS', L.tr('Montserrat'))  
        .value('MA', L.tr('MOROCCO'))  
        .value('MZ', L.tr('Mozambique'))  
        .value('MM', L.tr('Myanmar'))  
        .value('NA', L.tr('Namibia'))  
        .value('NR', L.tr('Nauru'))  
        .value('NP', L.tr('Nepal'))  
        .value('NL', L.tr('NETHERLANDS'))  
        .value('NC', L.tr('New Caledonia '))  
        .value('NZ', L.tr('NEW ZEALAND'))   
        .value('NI', L.tr('Nicaragua'))  
        .value('NE', L.tr('Niger'))  
        .value('NG', L.tr('Nigeria'))  
        .value('NU', L.tr('Niue'))  
        .value('NF', L.tr('Norfolk Island'))  
        .value('MP', L.tr('Northern Mariana Islands'))  
        .value('NO', L.tr('NORWAY')) 
        .value('OM', L.tr('OMAN'))  
        .value('PK', L.tr('PAKISTAN'))  
        .value('PW', L.tr('Palau'))  
        .value('PS', L.tr('Palestine'))  
        .value('PA', L.tr('PANAMA'))  
        .value('PG', L.tr('Papua New Guinea'))  
        .value('PY', L.tr('Paraguay'))  
        .value('PE', L.tr('PERU'))  
        .value('PH', L.tr('PHILIPPINES'))  
        .value('PN', L.tr('Pitcairn'))  
        .value('PL', L.tr('POLAND'))  
        .value('PT', L.tr('PORTUGAL'))  
        .value('PR', L.tr('PUERTO RICO'))  
        .value('QA', L.tr('QATAR'))  
        .value('RE', L.tr('Réunion'))  
        .value('RO', L.tr('ROMANIA'))  
        .value('RU', L.tr('RUSSIA FEDERATION'))  
        .value('RW', L.tr('Rwanda'))  
        .value('BL', L.tr('Saint Barthélemy'))  
        .value('SH', L.tr('Saint Helena'))  
        .value('SH', L.tr('Ascension Island'))  
        .value('SH', L.tr('Tristan da Cunha'))  
        .value('KN', L.tr('Saint Kitts and Nevis'))  
        .value('LC', L.tr('Saint Lucia'))  
        .value('MF', L.tr('Saint Martin '))  
        .value('PM', L.tr('Saint Pierre and Miquelon'))  
        .value('VC', L.tr('Saint Vincent and the Grenadines'))  
        .value('WS', L.tr('Samoa'))  
        .value('SM', L.tr('San Marino'))  
        .value('ST', L.tr('Sao Tome and Principe'))  
        .value('SA', L.tr('SAUDI ARABIA'))  
        .value('SN', L.tr('Senegal'))  
        .value('RS', L.tr('Serbia'))  
        .value('SC', L.tr('Seychelles'))  
        .value('SL', L.tr('Sierra Leone'))  
        .value('SG', L.tr('SINGAPORE'))  
        .value('SX', L.tr('Sint Maarten'))  
        .value('SK', L.tr('SLOVAKIA'))  
        .value('SI', L.tr('SLOVENIA'))  
        .value('SB', L.tr('Solomon Islands'))  
        .value('SO', L.tr('Somalia'))  
        .value('ZA', L.tr('SOUTH AFRICA'))  
        .value('GS', L.tr('South Georgia and the South Sandwich Islands'))  
        .value('SS', L.tr('South Sudan'))  
        .value('ES', L.tr('SPAIN'))  
        .value('LK', L.tr('Sri Lanka'))  
        .value('SD', L.tr('Sudan'))  
        .value('SR', L.tr('Suriname'))  
        .value('SJ', L.tr('Svalbard'))  
        .value('SJ', L.tr('Jan Mayen'))  
        .value('SE', L.tr('SWEDEN'))  
        .value('CH', L.tr('SWITZERLAND'))  
        .value('SY', L.tr('SYRIAN ARAB REPUBLIC'))  
        .value('TW', L.tr('TAIWAN'))  
        .value('TJ', L.tr('Tajikistan'))  
        .value('TZ', L.tr('Tanzania'))  
        .value('TH', L.tr('THAILAND'))  
        .value('TL', L.tr('Timor-Leste'))  
        .value('TG', L.tr('Togo'))  
        .value('TK', L.tr('Tokelau'))  
        .value('TO', L.tr('Tonga'))  
        .value('TT', L.tr('TRINIDAD AND TOBAGO'))  
        .value('TN', L.tr('TUNISIA'))  
        .value('TR', L.tr('TURKEY'))  
        .value('TM', L.tr('Turkmenistan'))  
        .value('TC', L.tr('Turks and Caicos Islands'))  
        .value('TV', L.tr('Tuvalu'))  
        .value('UG', L.tr('Uganda'))  
        .value('UA', L.tr('UKRAINE'))  
        .value('AE', L.tr('UNITED ARAB EMIRATES'))  
        .value('GB', L.tr('UNITED KINGDOM'))  
        .value('US', L.tr('UNITED STATES'))  
        .value('UY', L.tr('URUGUAY'))  
        .value('UZ', L.tr('UZBEKISTAN'))  
        .value('VU', L.tr('Vanuatu'))  
        .value('VE', L.tr('VENEZUELA'))  
        .value('VN', L.tr('VIET NAM'))  
        .value('VG', L.tr('Virgin Islands'))  
        .value('WF', L.tr('Wallis and Futuna'))  
        .value('EH', L.tr('Western Sahara '))  
        .value('YE', L.tr('YEMEN'))  
        .value('ZM', L.tr('Zambia'))  
        .value('ZW', L.tr('ZIMBABWE')); 
        
        s2.option( L.cbi.ListValue, 'wifi1CountryRegion', {
			caption:	L.tr('CountryRegion'),
			initial:	'none'
		}).depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'ap'})
		.depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'apsta'})
		.value('0', L.tr('0: Ch1-11'))
		.value('1', L.tr('1: Ch1-13'))
		.value('2', L.tr('2: Ch10-11'))
		.value('3', L.tr('3: Ch10-13'))
		.value('4', L.tr('4: Ch14'))
		.value('5', L.tr('5: Ch1-14'))
		.value('6', L.tr('6: Ch3-9'))
		.value('7', L.tr('7: Ch5-13'))
		.value('31', L.tr('31: Ch1-11,Ch12-14'))
		.value('32', L.tr('32: Ch1-11,Ch12-13'))
		.value('33', L.tr('33: Ch1-14'));
        
         s2.option(L.cbi.ListValue, 'wifideviceschannel', {
			caption:	L.tr('Channel'),
			description: L.tr('Select Channel depending on CountryRegion')
		}).depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'ap'})
		.value('1', L.tr('1'))
		.value('2', L.tr('2'))
		.value('3', L.tr('3'))
		.value('4', L.tr('4'))
		.value('5', L.tr('5'))
		.value('6', L.tr('6'))
		.value('7', L.tr('7'))
		.value('8', L.tr('8'))
		.value('9', L.tr('9'))
		.value('10', L.tr('10'))
		.value('11', L.tr('11'))
		.value('12', L.tr('12'))
		.value('13', L.tr('13'))
		.value('14', L.tr('14'))
		.value('auto', L.tr('auto'));
         
		s2.option( L.cbi.ListValue, 'channelwidth', {
		caption:	L.tr('Channel BandWidth'),
		}).depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'ap'})
		.depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'apsta'})
		.value('0', L.tr('20 MHz'))
		.value('1', L.tr('20/40 MHz')); 
				
	    s2.option( L.cbi.InputValue, 'TxPower', {
		caption:	L.tr('TX Power'),
		}).depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'ap'})
		.depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'apsta'});
					       
        s2.option( L.cbi.InputValue, 'wifi1ssid', {
			caption:	'Radio SSID'
				}).depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'ap'})
		.depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'apsta'});
		  
		s2.option( L.cbi.PasswordValue, 'wifi1key', {
			caption:	L.tr('Radio Passphrase'),
			datatype:'rangelength(8,11)',
			optional:	true
				}).depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'ap'})
		.depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'apsta'});
		
                s2.option( L.cbi.ListValue, 'wifi1encryption', {
                        caption:        L.tr('Radio Encryption'),
                        initial:        'none'
        		}).depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'ap'})
		.depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'apsta'})
		        .value('NONE', L.tr('NONE'))
                .value('TKIP', L.tr('TKIP'))
                .value('AES', L.tr('AES'));

                         s2.option(L.cbi.InputValue, 'radio0dhcpip', {
           caption: L.tr('Radio DHCP Local IP'), 
           datatype: 'ip4addr',
        		}).depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'ap'})
		.depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'apsta'});

	s2.option(L.cbi.CheckboxValue, 'enable_dhcpserver', {
           caption: L.tr('Enable DHCP Server'),
        }).depends({'wificonfig':'1','wifi1enable':'1'});
        
           s2.option(L.cbi.InputValue, 'Radio0DHCPrange', {
           caption: L.tr('Radio DHCP Start Address'),
            		}).depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'ap','enable_dhcpserver' : '1'})
		.depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'apsta','enable_dhcpserver' : '1'});
        
          s2.option(L.cbi.InputValue, 'Radio0DHCPlimit', {
           caption: L.tr('Radio DHCP Limit'), 
           		}).depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'ap','enable_dhcpserver' : '1'})
		.depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'apsta','enable_dhcpserver' : '1'});
		s2.option(L.cbi.ListValue, 'wifi2leasetime_duration', {
          caption: L.tr('Lease Time Duration'),
       }).value("h", L.tr('Hours-(H)'))
          .value("m", L.tr('Minutes-(M)'))
          .value("s", L.tr('Seconds-(S)'))
          .depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'ap','enable_dhcpserver' : '1'})
          .depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'apsta','enable_dhcpserver' : '1'});
                 
         s2.option(L.cbi.InputValue, 'wifi2leasetime', {
            caption: L.tr('Lease time'), 
            datatype: 'uinteger',
            optional: true
         }).depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'ap','enable_dhcpserver' : '1'})
			.depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'apsta','enable_dhcpserver' : '1'});
                
		s2.option(L.cbi.InputValue, 'wifistassid', {
		caption: L.tr('Client SSID'), 
		}).depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'sta'})
		.depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'apsta'});
		
		s2.option( L.cbi.PasswordValue, 'wifistakey', {
		caption:	L.tr('Client Radio Passphrase'),
		datatype:'rangelength(8,11)',
		optional:	true
		}).depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'sta'})
		.depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'apsta'});
		
		s2.option( L.cbi.InputValue, 'wifistaauth', {
		caption:        L.tr('Client Radio Authentication'),
		optional:	true
		}).depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'sta'})
		.depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'apsta'});

		s2.option( L.cbi.InputValue, 'wifistaencryption', {
		caption:        L.tr('Client Radio Encryption'),
		optional:	true
		}).depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'sta'})
		.depends({'wificonfig':'1','wifi1enable':'1','wifi1mode' : 'apsta'});
		
      //5Ghz WIFI Settings		
      s2.option(L.cbi.DummyValue, 'WIFI5Settings', {
		  caption: L.tr(''),
		}).depends({'wificonfig':'1','wifi1enable':'1'})
        .ucivalue=function()
          {
            var id="<h3><b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp5Ghz WIFI Settings</b> </h3>";
            return id;
          };  
          
        //
        
         s2.option( L.cbi.ListValue, 'Wifi5Mode', {
			caption:	L.tr('Radio Mode'),
		}).depends({'wificonfig':'1','wifi1enable':'1','wifi51enable':'1'})
		.value('ap', L.tr('Access Point'));
		
        s2.option( L.cbi.ListValue, 'wifi51protocol', {
		caption:	L.tr('WirelessMode'),
		}).depends({'wificonfig':'1','wifi1enable':'1'})
		.value('5g', L.tr('mixed'));
        
          
         s2.option( L.cbi.ListValue, 'wifi5CountryCode', {
		caption:	L.tr('Country Code'),
		}).depends({'wificonfig':'1','wifi1enable':'1'})
		.value('none', L.tr('Please choose'))
		.value('AF', L.tr('Afghanistan'))
        .value('AX', L.tr('Åland Islands'))
        .value('AL', L.tr('ALBANIA'))    
        .value('AS', L.tr('American Samoa'))  
        .value('AD', L.tr('Andorra'))  
        .value('AO', L.tr('Angola'))  
        .value('AI', L.tr('Anguilla')) 
        .value('AQ', L.tr('Antarctica')) 
        .value('AG', L.tr('Antigua and Barbuda')) 
        .value('AR', L.tr('ARGENTINA'))  
        .value('AM', L.tr('ARMENIA'))  
        .value('AW', L.tr('Aruba'))  
        .value('AU', L.tr('AUSTRALIA'))  
        .value('AT', L.tr('AUSTRIA'))  
        .value('AZ', L.tr('AZERBAIJAN'))  
        .value('BH', L.tr('BAHRAIN'))  
        .value('BD', L.tr('Bangladesh'))  
        .value('BB', L.tr('Barbados'))  
        .value('BY', L.tr('BELARUS'))  
        .value('BE', L.tr('BELGIUM'))  
        .value('BZ', L.tr('BELIZE'))  
        .value('BJ', L.tr('Benin'))  
        .value('BM', L.tr('Bermuda'))  
        .value('BT', L.tr('Bhutan'))  
        .value('BO', L.tr('BOLIVIA'))  
        .value('BQ', L.tr('Bonaire'))  
        .value('BQ', L.tr('Sint Eustatius'))  
        .value('BQ', L.tr('Saba'))  
        .value('BA', L.tr('Bosnia and Herzegovina'))  
        .value('BW', L.tr('Botswana'))  
        .value('BV', L.tr('Bouvet Island'))  
        .value('BR', L.tr('BRAZIL'))  
        .value('IO', L.tr('British Indian Ocean Territory'))  
        .value('BN', L.tr('BRUNEI DARUSSALAM'))  
        .value('BG', L.tr('BULGARIA'))  
        .value('BF', L.tr('Burkina Faso'))  
        .value('BI', L.tr('Burundi'))  
        .value('CV', L.tr('Cabo Verde'))  
        .value('KH', L.tr('Cambodia'))  
        .value('CM', L.tr('Cameroon'))  
        .value('CA', L.tr('CANADA'))  
        .value('KY', L.tr('Cayman Islands '))  
        .value('CF', L.tr('Central African Republic'))  
        .value('TD', L.tr('Chad'))  
        .value('CL', L.tr('CHILE'))  
        .value('CN', L.tr('CHINA'))  
        .value('CX', L.tr('Christmas Island'))  
        .value('CC', L.tr('Cocos (Keeling) Islands (the)'))  
        .value('CO', L.tr('COLOMBIA'))  
        .value('KM', L.tr('Comoros'))  
        .value('CD', L.tr('Congo(the Democratic Republic of the)'))  
        .value('CG', L.tr('Congo'))  
        .value('CK', L.tr('Cook Islands'))    
        .value('CR', L.tr('COSTA RICA'))  
        .value('CI', L.tr('Côte dIvoire'))  
        .value('HR', L.tr('CROATIA'))  
        .value('CU', L.tr('Cuba'))  
        .value('CW', L.tr('Curaçao'))  
        .value('CY', L.tr('CYPRUS'))  
        .value('CZ', L.tr('CZECH REPUBLIC'))  
        .value('DK', L.tr('DENMARK'))  
        .value('DJ', L.tr('Djibouti'))  
        .value('DM', L.tr('Dominica'))  
        .value('DO', L.tr('DOMINICAN REPUBLIC'))  
        .value('EC', L.tr('ECUADOR'))  
        .value('EG', L.tr('EGYPT'))  
        .value('SV', L.tr('EL SALVADOR'))  
        .value('GQ', L.tr('Equatorial Guinea'))  
        .value('ER', L.tr('Eritrea'))  
        .value('EE', L.tr('ESTONIA'))  
        .value('ET', L.tr('Ethiopia'))  
        .value('FK', L.tr('Falkland Islands'))  
        .value('FO', L.tr('Faroe Islands'))  
        .value('FJ', L.tr('Fiji'))  
        .value('FI', L.tr('FINLAND'))  
        .value('FR', L.tr('FRANCE'))  
        .value('GF', L.tr('French Guiana'))  
        .value('PF', L.tr('French Polynesia'))  
        .value('TF', L.tr('French Southern Territories'))  
        .value('GA', L.tr('Gabon'))  
        .value('GM', L.tr('Gambia'))  
        .value('GE', L.tr('GEORGIA'))  
        .value('DE', L.tr('GERMANY'))  
        .value('GH', L.tr('Ghana'))  
        .value('GI', L.tr('Gibraltar'))  
        .value('GR', L.tr('GREECE'))  
        .value('GL', L.tr('Greenland'))  
        .value('GD', L.tr('Grenada'))  
        .value('GP', L.tr('Guadeloupe'))  
        .value('GU', L.tr('Guam'))  
        .value('GT', L.tr('GUATEMALA'))  
        .value('GG', L.tr('Guernsey'))  
        .value('GW', L.tr('Guinea-Bissau'))  
        .value('GY', L.tr('Guyana'))  
        .value('HT', L.tr('Haiti'))  
        .value('HM', L.tr('Heard Island and McDonald Islands'))  
        .value('VA', L.tr('Holy See'))  
        .value('HN', L.tr('HONDURAS'))  
        .value('HK', L.tr('HONG KONG'))  
        .value('HU', L.tr('HUNGARY'))  
        .value('IS', L.tr('ICELAND'))  
        .value('IN', L.tr('INDIA'))  
        .value('ID', L.tr('INDONESIA'))  
        .value('IR', L.tr('IRAN'))  
        .value('IQ', L.tr('Iraq'))  
        .value('IE', L.tr('IRELAND'))  
        .value('IL', L.tr('ISRAEL'))  
        .value('IT', L.tr('ITALY'))  
        .value('JM', L.tr('Jamaica'))  
        .value('JP', L.tr('JAPAN'))  
        .value('JE', L.tr('Jersey'))  
        .value('JO', L.tr('JORDAN'))  
        .value('KZ', L.tr('KAZAKHSTAN'))  
        .value('KE', L.tr('Kenya'))  
        .value('KI', L.tr('Kiribati'))  
        .value('KP', L.tr('KOREA DEMOCRATIC'))  
        .value('KR', L.tr('REPUBLIC OF KOREA '))  
        .value('KW', L.tr('KUWAIT'))  
        .value('KG', L.tr('Kyrgyzstan'))  
        .value('LA', L.tr('Lao People Democratic Republic'))  
        .value('LV', L.tr('LATVIA'))  
        .value('LB', L.tr('LEBANON'))  
        .value('LS', L.tr('Lesotho'))  
        .value('LR', L.tr('Liberia'))  
        .value('LY', L.tr('Libya'))  
        .value('LI', L.tr('LIECHTENSTEIN'))  
        .value('LT', L.tr('LITHUANIA'))  
        .value('LU', L.tr('LUXEMBOURG'))  
        .value('MO', L.tr('MACAO'))  
        .value('MK', L.tr('MACEDONIA'))  
        .value('MG', L.tr('Madagascar'))  
        .value('MW', L.tr('Malawi'))  
        .value('MY', L.tr('MALAYSIA'))  
        .value('MV', L.tr('Maldives'))  
        .value('ML', L.tr('Mali'))  
        .value('MT', L.tr('Malta'))  
        .value('MH', L.tr('Marshall Islands'))  
        .value('MQ', L.tr('Martinique'))  
        .value('MR', L.tr('Mauritania'))  
        .value('MU', L.tr('Mauritius'))  
        .value('YT', L.tr('Mayotte'))  
        .value('MX', L.tr('MEXICO'))  
        .value('FM', L.tr('Micronesia'))  
        .value('MD', L.tr('Moldova'))  
        .value('MC', L.tr('MONACO'))  
        .value('MN', L.tr('Mongolia'))  
        .value('ME', L.tr('Montenegro'))  
        .value('MS', L.tr('Montserrat'))  
        .value('MA', L.tr('MOROCCO'))  
        .value('MZ', L.tr('Mozambique'))  
        .value('MM', L.tr('Myanmar'))  
        .value('NA', L.tr('Namibia'))  
        .value('NR', L.tr('Nauru'))  
        .value('NP', L.tr('Nepal'))  
        .value('NL', L.tr('NETHERLANDS'))  
        .value('NC', L.tr('New Caledonia '))  
        .value('NZ', L.tr('NEW ZEALAND'))   
        .value('NI', L.tr('Nicaragua'))  
        .value('NE', L.tr('Niger'))  
        .value('NG', L.tr('Nigeria'))  
        .value('NU', L.tr('Niue'))  
        .value('NF', L.tr('Norfolk Island'))  
        .value('MP', L.tr('Northern Mariana Islands'))  
        .value('NO', L.tr('NORWAY')) 
        .value('OM', L.tr('OMAN'))  
        .value('PK', L.tr('PAKISTAN'))  
        .value('PW', L.tr('Palau'))  
        .value('PS', L.tr('Palestine'))  
        .value('PA', L.tr('PANAMA'))  
        .value('PG', L.tr('Papua New Guinea'))  
        .value('PY', L.tr('Paraguay'))  
        .value('PE', L.tr('PERU'))  
        .value('PH', L.tr('PHILIPPINES'))  
        .value('PN', L.tr('Pitcairn'))  
        .value('PL', L.tr('POLAND'))  
        .value('PT', L.tr('PORTUGAL'))  
        .value('PR', L.tr('PUERTO RICO'))  
        .value('QA', L.tr('QATAR'))  
        .value('RE', L.tr('Réunion'))  
        .value('RO', L.tr('ROMANIA'))  
        .value('RU', L.tr('RUSSIA FEDERATION'))  
        .value('RW', L.tr('Rwanda'))  
        .value('BL', L.tr('Saint Barthélemy'))  
        .value('SH', L.tr('Saint Helena'))  
        .value('SH', L.tr('Ascension Island'))  
        .value('SH', L.tr('Tristan da Cunha'))  
        .value('KN', L.tr('Saint Kitts and Nevis'))  
        .value('LC', L.tr('Saint Lucia'))  
        .value('MF', L.tr('Saint Martin '))  
        .value('PM', L.tr('Saint Pierre and Miquelon'))  
        .value('VC', L.tr('Saint Vincent and the Grenadines'))  
        .value('WS', L.tr('Samoa'))  
        .value('SM', L.tr('San Marino'))  
        .value('ST', L.tr('Sao Tome and Principe'))  
        .value('SA', L.tr('SAUDI ARABIA'))  
        .value('SN', L.tr('Senegal'))  
        .value('RS', L.tr('Serbia'))  
        .value('SC', L.tr('Seychelles'))  
        .value('SL', L.tr('Sierra Leone'))  
        .value('SG', L.tr('SINGAPORE'))  
        .value('SX', L.tr('Sint Maarten'))  
        .value('SK', L.tr('SLOVAKIA'))  
        .value('SI', L.tr('SLOVENIA'))  
        .value('SB', L.tr('Solomon Islands'))  
        .value('SO', L.tr('Somalia'))  
        .value('ZA', L.tr('SOUTH AFRICA'))  
        .value('GS', L.tr('South Georgia and the South Sandwich Islands'))  
        .value('SS', L.tr('South Sudan'))  
        .value('ES', L.tr('SPAIN'))  
        .value('LK', L.tr('Sri Lanka'))  
        .value('SD', L.tr('Sudan'))  
        .value('SR', L.tr('Suriname'))  
        .value('SJ', L.tr('Svalbard'))  
        .value('SJ', L.tr('Jan Mayen'))  
        .value('SE', L.tr('SWEDEN'))  
        .value('CH', L.tr('SWITZERLAND'))  
        .value('SY', L.tr('SYRIAN ARAB REPUBLIC'))  
        .value('TW', L.tr('TAIWAN'))  
        .value('TJ', L.tr('Tajikistan'))  
        .value('TZ', L.tr('Tanzania'))  
        .value('TH', L.tr('THAILAND'))  
        .value('TL', L.tr('Timor-Leste'))  
        .value('TG', L.tr('Togo'))  
        .value('TK', L.tr('Tokelau'))  
        .value('TO', L.tr('Tonga'))  
        .value('TT', L.tr('TRINIDAD AND TOBAGO'))  
        .value('TN', L.tr('TUNISIA'))  
        .value('TR', L.tr('TURKEY'))  
        .value('TM', L.tr('Turkmenistan'))  
        .value('TC', L.tr('Turks and Caicos Islands'))  
        .value('TV', L.tr('Tuvalu'))  
        .value('UG', L.tr('Uganda'))  
        .value('UA', L.tr('UKRAINE'))  
        .value('AE', L.tr('UNITED ARAB EMIRATES'))  
        .value('GB', L.tr('UNITED KINGDOM'))  
        .value('US', L.tr('UNITED STATES'))  
        .value('UY', L.tr('URUGUAY'))  
        .value('UZ', L.tr('UZBEKISTAN'))  
        .value('VU', L.tr('Vanuatu'))  
        .value('VE', L.tr('VENEZUELA'))  
        .value('VN', L.tr('VIET NAM'))  
        .value('VG', L.tr('Virgin Islands'))  
        .value('WF', L.tr('Wallis and Futuna'))  
        .value('EH', L.tr('Western Sahara '))  
        .value('YE', L.tr('YEMEN'))  
        .value('ZM', L.tr('Zambia'))  
        .value('ZW', L.tr('ZIMBABWE')); 

		//s2.option( L.cbi.ListValue, 'wifi5CountryRegion', {
			//caption:	L.tr('CountryRegion'),
			//initial:	'none'
		//}).depends({'wificonfig':'1','wifi1enable':'1','wifi51enable':'1'})
		//.value('0', L.tr('0: Ch36-64, Ch149-165'))
		//.value('1', L.tr('1: Ch36-64, Ch100-140'))
		//.value('2', L.tr('2: Ch36-64'))
		//.value('3', L.tr('3: Ch52-64, Ch149-161'))
		//.value('4', L.tr('4: Ch149-165'))
		//.value('5', L.tr('5: Ch149-161'))
		//.value('6', L.tr('6: Ch36-48'))
		//.value('7', L.tr('7: Ch36-64, Ch100-140, Ch149-165'))
		//.value('8', L.tr('8: Ch52-64'))
		//.value('9', L.tr('9: Ch36-64, Ch100-116, Ch132-140, Ch149-165'))
		//.value('10', L.tr('10: Ch36-48, Ch149-165'))
		//.value('11', L.tr('11: Ch36-64, Ch100-120, Ch149-161'))
		//.value('12', L.tr('12: Ch36-64, Ch100-144'))
		//.value('13', L.tr('13: Ch36-64, Ch100-144, Ch149-165'))
		//.value('14', L.tr('14: Ch36-64, Ch100-116, Ch132-144, Ch149-165'))
		//.value('15', L.tr('15: Ch149-173'))
		//.value('16', L.tr('16: Ch52-64, Ch149-165'))
		//.value('17', L.tr('17: Ch36-48, Ch149-161'))
		//.value('18', L.tr('18: Ch36-64, Ch100-116, Ch132-140'))
		//.value('19', L.tr('19: Ch56-64, Ch100-140, Ch149-161'))
		//.value('20', L.tr('20: Ch36-64, Ch100-124, Ch149-161'))
		//.value('21', L.tr('21: Ch36-64, Ch100-140, Ch149-161'))
		//.value('22', L.tr('22: Ch100-140'))
		//.value('30', L.tr('30: Ch36-48, Ch52-64, Ch100-140, Ch149-165'))
		//.value('31', L.tr('31: Ch52-64, Ch100-140, Ch149-165'))
		//.value('32', L.tr('32: Ch36-48, Ch52-64, Ch100-140, Ch149-161'))
		//.value('33', L.tr('33: Ch36-48, Ch52-64, Ch100-140'))
		//.value('34', L.tr('34: Ch36-48, Ch52-64, Ch149-165'))
		//.value('35', L.tr('35: Ch36-48, Ch52-64'))
		//.value('36', L.tr('36: Ch36-48, Ch100-140, Ch149-165'))
		//.value('37', L.tr('37: Ch36-48, Ch52-64, Ch149-165, Ch173'));        
        
         s2.option(L.cbi.ListValue, 'wifi5deviceschannel', {
			caption:	L.tr('Channel'),
		}).depends({'wificonfig':'1','wifi1enable':'1'})
		.value('1', L.tr('0'))
		.value('36', L.tr('36'))
		.value('40', L.tr('40'))
		.value('44', L.tr('44'))
		.value('48', L.tr('48'))
		.value('52', L.tr('52'))
		.value('56', L.tr('56'))
		.value('60', L.tr('60'))
		.value('64', L.tr('64'))
		.value('100', L.tr('100'))
		.value('104', L.tr('104'))
		.value('108', L.tr('108'))
		.value('112', L.tr('112'))
		.value('116', L.tr('116'))
		.value('132', L.tr('132'))
		.value('136', L.tr('136'))
		.value('140', L.tr('140'))
		.value('149', L.tr('149'))
		.value('153', L.tr('153'))
		.value('157', L.tr('157'))
		.value('161', L.tr('161'))
		.value('165', L.tr('165'))
		.value('auto', L.tr('auto'));
   		
	s2.option( L.cbi.ListValue, 'wifi5channelwidth', {
	caption:	L.tr('Channel BandWidth'),
	}).depends({'wificonfig':'1','wifi1enable':'1'})
	.value('0', L.tr('disable'))
	.value('VHT20', L.tr('20 MHz'))
	.value('VHT40', L.tr('20/40MHz'))
	.value('VHT80', L.tr('80 MHz'));     
	
	  s2.option( L.cbi.InputValue, 'wifi5TxPower', {
	caption:	L.tr('TX Power'),
	}).depends({'wificonfig':'1','wifi1enable':'1'})

			s2.option( L.cbi.InputValue, 'wifi5ssid', {
		caption:	'Radio SSID'
	}).depends({'wificonfig':'1','wifi1enable':'1'});
	  
	s2.option( L.cbi.PasswordValue, 'wifi5key', {
		caption:	L.tr('Radio Passphrase'),
		datatype:'rangelength(8,11)',
		optional:	true	
	}).depends({'wificonfig':'1','wifi1enable':'1'})

		s2.option( L.cbi.ListValue, 'wifi5encryption', {
			caption:	L.tr('Radio Encryption'),
			initial:	'none'
		}).depends({'wificonfig':'1','wifi1enable':'1','wifi51enable':'1'})
		.value('none', L.tr('NONE'))
		.value('psk2', L.tr('WPA Personal (PSK)'))
		.value('psk2+aes', L.tr('WPA Personal (PSK) + AES'))
		.value('psk2+ccmp', L.tr('WPA Personal (PSK) + CCMP'))
		.value('psk+tkip+ccmp', L.tr('WPA Personal (PSK)+TKIP+CCMP'))
		.value('psk+tkip+aes', L.tr('WPA Personal (PSK)+TKIP+AES'));
		
		 s2.option(L.cbi.InputValue, 'wifi5radio0dhcpip', {
           caption: L.tr('Radio DHCP Local IP'), 
           datatype: 'ip4addr',
		}).depends({'wificonfig':'1','wifi1enable':'1','wifi51enable':'1'});
      
		s2.option(L.cbi.CheckboxValue, 'wifi5enable_dhcpserver', {
           caption: L.tr('Enable DHCP Server'),
        }).depends({'wificonfig':'1','wifi1enable':'1'});
        
        s2.option(L.cbi.InputValue, 'wifi5Radio0DHCPrange', {
           caption: L.tr('Radio DHCP Start Address'), 
		}).depends({'wificonfig':'1','wifi1enable':'1','wifi51enable':'1','wifi5enable_dhcpserver':'1'});
		        
        s2.option(L.cbi.InputValue, 'wifi5Radio0DHCPlimit', {
           caption: L.tr('Radio DHCP Limit'), 
		}).depends({'wificonfig':'1','wifi1enable':'1','wifi51enable':'1','wifi5enable_dhcpserver':'1'});
		
		s2.option(L.cbi.ListValue, 'wifi5leasetime_duration', {
          caption: L.tr('Lease Time Duration'),
       }).value("h", L.tr('Hours-(H)'))
          .value("m", L.tr('Minutes-(M)'))
          .value("s", L.tr('Seconds-(S)'))
          .depends({'wificonfig':'1','wifi1enable':'1','wifi51enable':'1','wifi5enable_dhcpserver':'1'});
                 
         s2.option(L.cbi.InputValue, 'wifi5leasetime', {
            caption: L.tr('Lease time'), 
            datatype: 'uinteger',
            optional: true
         }).depends({'wificonfig':'1','wifi1enable':'1','wifi51enable':'1','wifi5enable_dhcpserver':'1'});
    
   m2.insertInto('#section_wifi');  
   
   //Guest Wifi 2.4/5Ghz
    var m3 = new L.cbi.Map('sysconfig', {
                });     
   
   var s3 = m3.section(L.cbi.NamedSection, 'guestwifi', {
        caption:L.tr('')
    });
    
		//Guest WIFI 2.4Ghz
		   s3.option(L.cbi.DummyValue, 'generalsettings', {
		  caption: L.tr(''),
        })
        .ucivalue=function()
          {
            var id="<h3><b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbspGuest WIFI 2.4Ghz </b> </h3>";
            return id;
          }; 
               
         s3.option(L.cbi.CheckboxValue, 'guestwifienable2', {
			caption:	L.tr('Enable 2.4Ghz Guest Wifi')
		}).depends({'guest':'1'});
		  		
      
         s3.option( L.cbi.InputValue, 'guestwifissid2', {
			caption:	'SSID'
		}).depends({'guest':'1','guestwifienable2':'1'});
		
		s3.option( L.cbi.PasswordValue, 'guestwifikey2', {
			caption:	L.tr('Passphrase'),
			datatype:'rangelength(8,11)',
			optional:	true
		}).depends({'guest':'1','guestwifienable2':'1'});
		
       s3.option(L.cbi.InputValue, 'guestradio0dhcpip2', {
           caption: L.tr('Radio DHCP Server IP'), 
           datatype: 'ip4addr',
		}).depends({'guest':'1','guestwifienable2':'1'});
				
       s3.option(L.cbi.InputValue, 'guestRadio0DHCPrange2', {
           caption: L.tr('Radio DHCP Start Address'), 
		}).depends({'guest':'1','guestwifienable2':'1'});
		
       s3.option(L.cbi.InputValue, 'guestRadio0DHCPlimit2', {
           caption: L.tr('Radio DHCP Limit'), 
		}).depends({'guest':'1','guestwifienable2':'1'});

		//Guest WIFI 5Ghz
		   s3.option(L.cbi.DummyValue, 'generalsettings', {
		  caption: L.tr(''),
        })
        .ucivalue=function()
          {
            var id="<h3><b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbspGuest WIFI 5Ghz </b> </h3>";
            return id;
          }; 
                        
         s3.option(L.cbi.CheckboxValue, 'guestwifienable5', {
			caption:	L.tr('Enable 5Ghz Guest Wifi')
		}).depends({'guest':'1'});
		  		
      
         s3.option(L.cbi.InputValue, 'guestwifissid5', {
			caption:	'SSID'
		}).depends({'guest':'1','guestwifienable5':'1'});
		
		s3.option(L.cbi.PasswordValue, 'guestwifikey5', {
			caption:	L.tr('Passphrase'),
			datatype:'rangelength(8,11)',
			optional:	true
		}).depends({'guest':'1','guestwifienable5':'1'});
		
        s3.option(L.cbi.InputValue, 'guestradio0dhcpip5', {
           caption: L.tr('Radio DHCP Server IP'), 
           datatype: 'ip4addr',
		}).depends({'guest':'1','guestwifienable5':'1'});
						
       s3.option(L.cbi.InputValue, 'guestRadio0DHCPrange5', {
           caption: L.tr('Radio DHCP Start Address'), 
		}).depends({'guest':'1','guestwifienable5':'1'});
		
       s3.option(L.cbi.InputValue, 'guestRadio0DHCPlimit5', {
           caption: L.tr('Radio DHCP Limit'), 
		}).depends({'guest':'1','guestwifienable5':'1'});
            
   m3.insertInto('#section_guestwifi');  
   
    var m4 = new L.cbi.Map('sysconfig', {
                });     
   
   var s4 = m4.section(L.cbi.NamedSection, 'wirelessschedule', {
        caption:L.tr('')
    });
    
  s4.option(L.cbi.DummyValue, 'Schedule', {
		  caption: L.tr(''),
        }).depends({'wificonfig':'1'})
        .depends({'wifi1enable':'1' })
        .ucivalue=function()
          {
            var id="<h3><b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbspWifi Schedule Settings </b> </h3>";
            return id;
          }; 
		
		//s4.option(L.cbi.DummyValue, 'generalsettings', {
		  //caption: L.tr(''),
        //}).depends({'wificonfig':'1','wifi1enable':'0' })
        //.ucivalue=function()
          //{
            //var id="<h3><b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbspPlease Enable wifi to configure Schedule ON/OFF settings</b> </h3>";
            //return id;
          //}; 
		
		 s4.option( L.cbi.CheckboxValue, 'ScheduledOnOff', {
			caption:	L.tr('Scheduled Wifi Off'),
		}).depends({'wificonfig':'1','wifi1enable':'1','wificonfigschedule':'1'});
		
        s4.option( L.cbi.DynamicList, 'DayOfWeek', {
            caption: L.tr('Day Of Week'),
            optional: true,
            listlimit: 12,
            listcustom:false
        }).depends({'wificonfig':'1','wifi1enable':'1','wificonfigschedule':'1','ScheduledOnOff':'1'})
        .value('*', L.tr('All'))
        .value('0', L.tr('Sunday'))
        .value('1', L.tr('Monday'))
        .value('2', L.tr('Tuesday'))
        .value('3', L.tr('Wednesday'))
        .value('4', L.tr('Thursday'))
        .value('5', L.tr('Friday'))
        .value('6', L.tr('Saturday'));
        		
		
		s4.option(L.cbi.DummyValue, 'from', {
		  caption: L.tr(''),
        }).depends({'wificonfig':'1','wifi1enable':'1' ,'wificonfigschedule':'1'})
        .ucivalue=function()
          {
            var id="<h5><b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp From: </b> </h5>";
            return id;
          }; 
		
		
		
		var fromHourVal = s4.option( L.cbi.DynamicList, 'fromHours', {
            caption: L.tr('Hours'),
            optional: true,
            listlimit: 24,
            listcustom:false,
        }).depends({'wificonfig':'1','wifi1enable':'1','wificonfigschedule':'1','ScheduledOnOff':'1'})
        .value('',L.tr('-- Please choose --'))
        .value('*', L.tr('All'));

        fromHourVal.load = function(sid) {
            var hours = [ ];
            for (var i = 0; i < 24; i++)
                hours.push(i);
            hours.sort();
            for (var i = 0; i < hours.length; i++)
                fromHourVal.value(i);
        };
		
		
		var fromMinuteVal = s4.option( L.cbi.DynamicList, 'fromMinutes', {
            caption: L.tr('Minutes'),
            optional: true,
            listlimit: 60,
            listcustom: false
        }).depends({'wificonfig':'1','wifi1enable':'1','wificonfigschedule':'1','ScheduledOnOff':'1'})
        .value('',L.tr('-- Please choose --'))
        .value('*', L.tr('All'));

        fromMinuteVal.load = function(sid) {
            var minutes = [ ];
            for (var i = 0; i < 60; i++)
                minutes.push(i);
            minutes.sort();
            for (var i = 0; i < minutes.length; i++)
                fromMinuteVal.value(i);
        };

        
        s4.option(L.cbi.DummyValue, 'to', {
		  caption: L.tr(''),
        }).depends({'wificonfig':'1'})
        .depends({'wifi1enable':'1' })
        .ucivalue=function()
          {
            var id="<h5><b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp To: </b> </h5>";
            return id;
          }; 
        
        var HourVal = s4.option(L.cbi.DynamicList, 'toHours', {
            caption: L.tr('Hours'),
            optional: true,
            listlimit: 24,
            listcustom:false,
        }).depends({'wificonfig':'1','wifi1enable':'1','wificonfigschedule':'1','ScheduledOnOff':'1'})
        .value('',L.tr('-- Please choose --'))
        .value('*', L.tr('All'));

        HourVal.load = function(sid) {
            var hours = [ ];
            for (var i = 0; i < 24; i++)
                hours.push(i);
            hours.sort();
            for (var i = 0; i < hours.length; i++)
                HourVal.value(i);
        };
		
		
		var MinuteVal = s4.option(L.cbi.DynamicList, 'toMinutes', {
            caption: L.tr('Minutes'),
            optional: true,
            listlimit: 60,
            listcustom: false
        }).depends({'wificonfig':'1','wifi1enable':'1','wificonfigschedule':'1','ScheduledOnOff':'1'})
        .value('',L.tr('-- Please choose --'))
        .value('*', L.tr('All'));

        MinuteVal.load = function(sid) {
            var minutes = [ ];
            for (var i = 0; i < 60; i++)
                minutes.push(i);
            minutes.sort();
            for (var i = 0; i < minutes.length; i++)
                MinuteVal.value(i);
        };
   m4.insertInto('#section_wireless');
   

   
     
   
   var m6 = new L.cbi.Map('sysconfig', {
                });     
   
   var s6 = m6.section(L.cbi.NamedSection, 'loopbackip', {
        caption:L.tr('')
    });

          s6.option(L.cbi.InputValue, 'loopbackip', {
           caption: L.tr('Loopback IP'), 
           datatype: 'ip4addr',
           placeholder:'8.8.8.8',
           optional: true
        }).depends({'loopbackipconfig':'1'}); 
        
       s6.option(L.cbi.InputValue, 'loopbacknetmask', {
           caption: L.tr('Loopback NetMask'),
           placeholder:'8.8.8.8', 
           datatype: 'ip4addr',
           optional: true
        }).depends({'loopbackipconfig':'1'});
   		   		
   m6.insertInto('#section_loopback'); 
   
     var m7 = new L.cbi.Map('sysconfig', {
                });     
   
   var s7 = m7.section(L.cbi.NamedSection, 'offloading', {
        caption:L.tr('')
    });
		s7.option(L.cbi.CheckboxValue, 'enableflowoffloading', {
		caption: L.tr('Enable Flow Offloading'), 
		}).depends({'flowoffloading':'1'}); 
		
		s7.option(L.cbi.CheckboxValue, 'smpirqaffinity', {
		caption: L.tr('Smp IRQ Affinity'),
		}).depends({'loopbackipconfig':'1'});

       m7.insertInto('#section_offloading');  
     
  
    }
});
