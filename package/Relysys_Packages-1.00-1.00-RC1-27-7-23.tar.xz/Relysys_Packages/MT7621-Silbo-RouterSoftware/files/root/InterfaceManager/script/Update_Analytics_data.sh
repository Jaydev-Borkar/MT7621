#!/bin/sh

. /lib/functions.sh

IMEI=$(uci get boardconfig.board.imei)

cellularwan1interface="CWAN1"
cellularwan2interface="CWAN2"
cellularwan3interface="CWAN3"
cellularwan1sim1interface="CWAN1_0"
cellularwan1sim2interface="CWAN1_1"

SystemConfigFile="/etc/config/sysconfig"

ReadSystemConfigFile()
{
   	config_load "$SystemConfigFile"
   	config_get CellularOperationModelocal sysconfig CellularOperationMode
   	config_get EnableCellular sysconfig enablecellular
}

Signal_strength(){
	
	ComPort="$1"
	modem_number="$2"
	ModemAnalyticsFile="/tmp/ModemAnalytics${modem_number}.txt"
	
	Operator_Code=$(gcom -d "$ComPort" -s /etc/gcom/getcarrier.gcom | awk NR==2)

	Operator=$(echo "$Operator_Code" | cut -d "," -f 2 | tr -d '\011\012\013\014\015\040')

	Operator=$(echo "$Operator" | tr -d '"')

	#Quality_Signal_Noise=$(gcom -d "$ComPort" -s /etc/gcom/getquality.gcom | awk NR==2)
	#Connected=$(echo "$Quality_Signal_Noise" | cut -d "," -f 3 | tr -d '\011\012\013\014\015\040')
	
	Quality_Signal_Noise_Full=$(gcom -d "$ComPort" -s /etc/gcom/getquality.gcom)
	Connected_LTE=$(echo "$Quality_Signal_Noise_Full" | grep -o LTE | tr -d '\011\012\013\014\015\040')
	Connected_NSA=$(echo "$Quality_Signal_Noise_Full" | grep -o NR5G-NSA | tr -d '\011\012\013\014\015\040')
	Connected_SA=$(echo "$Quality_Signal_Noise_Full" | grep -o NR5G-SA | tr -d '\011\012\013\014\015\040')
	Connected_EDGE=$(echo "$Quality_Signal_Noise_Full" | grep -o EDGE | tr -d '\011\012\013\014\015\040')
	Connected_GPRS=$(echo "$Quality_Signal_Noise_Full" | grep -o GPRS | tr -d '\011\012\013\014\015\040')
	Connected_CDMA=$(echo "$Quality_Signal_Noise_Full" | grep -o CDMA | tr -d '\011\012\013\014\015\040')
	
	if [ "$Connected_LTE" = "LTE" ] && [ "$Connected_NSA" = "NR5G-NSA" ]
	then
		Connected="NSA"
		Quality_Signal_Noise1=$(echo "$Quality_Signal_Noise_Full" | awk NR==3)
		Quality_Signal_Noise2=$(echo "$Quality_Signal_Noise_Full" | awk NR==4)
	
	elif [ "$Connected_LTE" = "LTE" ]
	then
		Connected="LTE"
		Quality_Signal_Noise=$(echo "$Quality_Signal_Noise_Full" | awk NR==2)
		
	elif [ "$Connected_SA" = "NR5G-SA" ]
	then
		Connected="SA"
		Quality_Signal_Noise=$(echo "$Quality_Signal_Noise_Full" | awk NR==2)
	elif [ "$Connected_EDGE" = "EDGE" ]
	then
		Connected="EDGE"
		Quality_Signal_Noise=$(echo "$Quality_Signal_Noise_Full" | awk NR==2)
	elif [ "$Connected_GPRS" = "GPRS" ]
	then
		Connected="GPRS"
		Quality_Signal_Noise=$(echo "$Quality_Signal_Noise_Full" | awk NR==2)
	elif [ "$Connected_CDMA" = "CDMA" ]
	then
		Connected="CDMA"
		Quality_Signal_Noise=$(echo "$Quality_Signal_Noise_Full" | awk NR==2)
	fi
	
	if [ "$Connected" = "SA" ] 
	then
		MODE=$(echo "$Quality_Signal_Noise" | cut -d "," -f 4 | tr -d '\011\012\013\014\015\040')
		MODE=$(echo "$MODE" | tr -d '"')
		MCC=$(echo "$Quality_Signal_Noise" | cut -d "," -f 5 | tr -d '\011\012\013\014\015\040')
		MNC=$(echo "$Quality_Signal_Noise" | cut -d "," -f 6 | tr -d '\011\012\013\014\015\040')
		LAC="-"
		CELLID=$(echo "$Quality_Signal_Noise" | cut -d "," -f 7 | tr -d '\011\012\013\014\015\040')
		BSIC=$(echo "$Quality_Signal_Noise" | cut -d "," -f 8 | tr -d '\011\012\013\014\015\040')
		ARFCN=$(echo "$Quality_Signal_Noise" | cut -d "," -f 10 | tr -d '\011\012\013\014\015\040')
		BAND=$(echo "$Quality_Signal_Noise" | cut -d "," -f 11 | tr -d '\011\012\013\014\015\040')
		ULBAND="-"
		
		DLBAND_VAL=$(echo "$Quality_Signal_Noise" | cut -d "," -f 12 | tr -d '\011\012\013\014\015\040')
		
		if [ "${DLBAND_VAL}" = "1" ]                                                                    
		then                                                                                            
			DLBAND="3 MHz"                                                                               
		elif [ "${DLBAND_VAL}" = "2" ]                                                                  
		then                                                                                            
			DLBAND="5 MHz"                                                                                                                             
		elif [ "${DLBAND_VAL}" = "3" ]                                                                                                                
		then                                                                                                                                          
			DLBAND="10 MHz"                                                                                                                            
		elif [ "${DLBAND_VAL}" = "4" ]                                                                                                                
		then                                                                                                                                          
			DLBAND="15 MHz"                                                                                                                            
		else                                                                                                                                          
			DLBAND="20 MHz"                                                                                                                            
		fi 
		
		TAC=$(echo "$Quality_Signal_Noise" | cut -d "," -f 9 | tr -d '\011\012\013\014\015\040')
		RSRP=$(echo "$Quality_Signal_Noise" | cut -d "," -f 13 | tr -d '\011\012\013\014\015\040')
		RSRQ=$(echo "$Quality_Signal_Noise" | cut -d "," -f 14 | tr -d '\011\012\013\014\015\040')
		RSSI="-"
		SINR=$(echo "$Quality_Signal_Noise" | cut -d "," -f 15 | tr -d '\011\012\013\014\015\040')
		echo "$Operator,$Connected,$MODE,$MCC,$MNC,$LAC,$CELLID,$BSIC,$ARFCN,$BAND,$ULBAND,$DLBAND,$TAC,$RSRP,$RSRQ,$RSSI,$SINR" > $ModemAnalyticsFile

		#signal status controller and simswitch signal 
		sh /root/InterfaceManager/script/signal_strength_led_controller.sh "$Connected" "$RSRP" "$modem_number"
		#sh /root/InterfaceManager/script/Simswitchsignal.sh "$RSRP" "$SINR"
		
	elif [ "$Connected" = "LTE" ] 
	then
		MODE=$(echo "$Quality_Signal_Noise" | cut -d "," -f 4 | tr -d '\011\012\013\014\015\040')
		MODE=$(echo "$MODE" | tr -d '"')
		MCC=$(echo "$Quality_Signal_Noise" | cut -d "," -f 5 | tr -d '\011\012\013\014\015\040')
		MNC=$(echo "$Quality_Signal_Noise" | cut -d "," -f 6 | tr -d '\011\012\013\014\015\040')
		LAC="-"
		CELLID=$(echo "$Quality_Signal_Noise" | cut -d "," -f 7 | tr -d '\011\012\013\014\015\040')
		BSIC=$(echo "$Quality_Signal_Noise" | cut -d "," -f 8 | tr -d '\011\012\013\014\015\040')
		ARFCN=$(echo "$Quality_Signal_Noise" | cut -d "," -f 9 | tr -d '\011\012\013\014\015\040')
		BAND=$(echo "$Quality_Signal_Noise" | cut -d "," -f 10 | tr -d '\011\012\013\014\015\040')
		ULBAND_VAL=$(echo "$Quality_Signal_Noise" | cut -d "," -f 11 | tr -d '\011\012\013\014\015\040')
		
		if [ "${ULBAND_VAL}" = "1" ]
		then
			ULBAND="3 MHz"
		elif [ "${ULBAND_VAL}" = "2" ]
		then
			ULBAND="5 MHz"
		elif [ "${ULBAND_VAL}" = "3" ]                                                                                                                
		then
			ULBAND="10 MHz"
		elif [ "${ULBAND_VAL}" = "4" ]                                                                                                                
		then 
			ULBAND="15 MHz"
		else
			ULBAND="20 MHz"
		fi 
		
		DLBAND_VAL=$(echo "$Quality_Signal_Noise" | cut -d "," -f 12 | tr -d '\011\012\013\014\015\040')
		
		if [ "${DLBAND_VAL}" = "1" ]                                                                    
		then                                                                                            
			DLBAND="3 MHz"                                                                               
		elif [ "${DLBAND_VAL}" = "2" ]                                                                  
		then                                                                                            
			DLBAND="5 MHz"                                                                                                                             
		elif [ "${DLBAND_VAL}" = "3" ]                                                                                                                
		then                                                                                                                                          
			DLBAND="10 MHz"                                                                                                                            
		elif [ "${DLBAND_VAL}" = "4" ]                                                                                                                
		then                                                                                                                                          
			DLBAND="15 MHz"                                                                                                                            
		else                                                                                                                                          
			DLBAND="20 MHz"                                                                                                                            
		fi 
		
		TAC=$(echo "$Quality_Signal_Noise" | cut -d "," -f 13 | tr -d '\011\012\013\014\015\040')
		RSRP=$(echo "$Quality_Signal_Noise" | cut -d "," -f 14 | tr -d '\011\012\013\014\015\040')
		RSRQ=$(echo "$Quality_Signal_Noise" | cut -d "," -f 15 | tr -d '\011\012\013\014\015\040')
		RSSI=$(echo "$Quality_Signal_Noise" | cut -d "," -f 16 | tr -d '\011\012\013\014\015\040')
		SINR=$(echo "$Quality_Signal_Noise" | cut -d "," -f 17 | tr -d '\011\012\013\014\015\040')
		echo "$Operator,$Connected,$MODE,$MCC,$MNC,$LAC,$CELLID,$BSIC,$ARFCN,$BAND,$ULBAND,$DLBAND,$TAC,$RSRP,$RSRQ,$RSSI,$SINR" > $ModemAnalyticsFile

		#signal status controller and simswitch signal 
		sh /root/InterfaceManager/script/signal_strength_led_controller.sh "$Connected" "$RSRP" "$modem_number"
		#sh /root/InterfaceManager/script/Simswitchsignal.sh "$RSRP" "$SINR"
		
	elif [ "$Connected" = "NSA" ]
	then
		MODE=$(echo "$Quality_Signal_Noise1" | cut -d "," -f 2 | tr -d '\011\012\013\014\015\040')
		MODE=$(echo "$MODE" | tr -d '"')
		MCC=$(echo "$Quality_Signal_Noise2" | cut -d "," -f 2 | tr -d '\011\012\013\014\015\040')
		MNC=$(echo "$Quality_Signal_Noise2" | cut -d "," -f 3 | tr -d '\011\012\013\014\015\040')
		LAC="-"
		CELLID=$(echo "$Quality_Signal_Noise2" | cut -d "," -f 10 | tr -d '\011\012\013\014\015\040')
		BSIC=$(echo "$Quality_Signal_Noise2" | cut -d "," -f 4 | tr -d '\011\012\013\014\015\040')
		ARFCN=$(echo "$Quality_Signal_Noise2" | cut -d "," -f 8 | tr -d '\011\012\013\014\015\040')
		BAND=$(echo "$Quality_Signal_Noise2" | cut -d "," -f 9 | tr -d '\011\012\013\014\015\040')
		ULBAND_VAL=$(echo "$Quality_Signal_Noise1" | cut -d "," -f 9 | tr -d '\011\012\013\014\015\040')
		
		if [ "${ULBAND_VAL}" = "1" ]
		then
			ULBAND="3 MHz"
		elif [ "${ULBAND_VAL}" = "2" ]
		then
			ULBAND="5 MHz"
		elif [ "${ULBAND_VAL}" = "3" ]                                                                                                                
		then
			ULBAND="10 MHz"
		elif [ "${ULBAND_VAL}" = "4" ]                                                                                                                
		then 
			ULBAND="15 MHz"
		else
			ULBAND="20 MHz"
		fi 
		
		DLBAND_VAL=$(echo "$Quality_Signal_Noise1" | cut -d "," -f 10 | tr -d '\011\012\013\014\015\040')
		
		if [ "${DLBAND_VAL}" = "1" ]                                                                    
		then                                                                                            
			DLBAND="3 MHz"                                                                               
		elif [ "${DLBAND_VAL}" = "2" ]                                                                  
		then                                                                                            
			DLBAND="5 MHz"                                                                                                                             
		elif [ "${DLBAND_VAL}" = "3" ]                                                                                                                
		then                                                                                                                                          
			DLBAND="10 MHz"                                                                                                                            
		elif [ "${DLBAND_VAL}" = "4" ]                                                                                                                
		then                                                                                                                                          
			DLBAND="15 MHz"                                                                                                                            
		else                                                                                                                                          
			DLBAND="20 MHz"                                                                                                                            
		fi 
		
		TAC=$(echo "$Quality_Signal_Noise2" | cut -d "," -f 11 | tr -d '\011\012\013\014\015\040')
		RSRP=$(echo "$Quality_Signal_Noise2" | cut -d "," -f 5 | tr -d '\011\012\013\014\015\040')
		RSRQ=$(echo "$Quality_Signal_Noise2" | cut -d "," -f 7 | tr -d '\011\012\013\014\015\040')
		RSSI=$(echo "$Quality_Signal_Noise1" | cut -d "," -f 14 | tr -d '\011\012\013\014\015\040')
		SINR=$(echo "$Quality_Signal_Noise2" | cut -d "," -f 6 | tr -d '\011\012\013\014\015\040')
		echo "$Operator,$Connected,$MODE,$MCC,$MNC,$LAC,$CELLID,$BSIC,$ARFCN,$BAND,$ULBAND,$DLBAND,$TAC,$RSRP,$RSRQ,$RSSI,$SINR" > $ModemAnalyticsFile

		#signal status controller and simswitch signal 
		sh /root/InterfaceManager/script/signal_strength_led_controller.sh "$Connected" "$RSRP" "$modem_number"
		#sh /root/InterfaceManager/script/Simswitchsignal.sh "$RSRP" "$SINR"
	else	
		MODE="-"       
		MCC=$(echo "$Quality_Signal_Noise" | cut -d "," -f 4 | tr -d '\011\012\013\014\015\040')                                                      
		MNC=$(echo "$Quality_Signal_Noise" | cut -d "," -f 5 | tr -d '\011\012\013\014\015\040')                                                      
		LAC=$(echo "$Quality_Signal_Noise" | cut -d "," -f 6 | tr -d '\011\012\013\014\015\040')                                                                                                                                       
		CELLID=$(echo "$Quality_Signal_Noise" | cut -d "," -f 7 | tr -d '\011\012\013\014\015\040')                                                   
		BSIC=$(echo "$Quality_Signal_Noise" | cut -d "," -f 8 | tr -d '\011\012\013\014\015\040')                                                     
		ARFCN=$(echo "$Quality_Signal_Noise" | cut -d "," -f 9 | tr -d '\011\012\013\014\015\040')                                                    
		BAND_VAL=$(echo "$Quality_Signal_Noise" | cut -d "," -f 10 | tr -d '\011\012\013\014\015\040')
		
		if [ "${BAND_VAL}" = "0" ]
		then
			BAND="DCS1800"
		elif [ "${BAND_VAL}" = "1" ]
		then
			BAND="PCS1900" 
		else
			BAND="GSM900"
		fi                                                    
		
		ULBAND="-"                                                                              
		DLBAND="-"                                                                                                                            
		TAC="-"                                                    
		RSRP="-"                                                    
		RSRQ="-"                                                    
		SINR="-"                         
		RSSI=$(at-cmd "$ComPort" at+csq | grep +CSQ | cut -d " " -f 2 | cut -d "," -f 1 | tr -d '\011\012\013\014\015\040')
		RSSI=$((31-RSSI))
		RSSI=$((RSSI*2))
		RSSI=$((-51-RSSI))
		echo "$Operator,$Connected,$MODE,$MCC,$MNC,$LAC,$CELLID,$BSIC,$ARFCN,$BAND,$ULBAND,$DLBAND,$TAC,$RSRP,$RSRQ,$RSSI,$SINR" > $ModemAnalyticsFile

		#signal status controller and simswitch signal 
		sh /root/InterfaceManager/script/signal_strength_led_controller.sh "$Connected" "$RSSI" "$modem_number"
	fi
}

ReadSystemConfigFile

if [ "$EnableCellular" = "1" ]
then
	if [ "$CellularOperationModelocal" = "dualcellularsinglesim" ]
	then
		ComPort1=$(uci get modem.CWAN1.ComPortSymLink)
		ComPort2=$(uci get modem.CWAN2.ComPortSymLink)
		
		Signal_strength $ComPort1 1		
		Signal_strength $ComPort2 2
		    		
	elif [ "$CellularOperationModelocal" = "singlecellulardualsim" ]
	then
		simnum=$(cat /tmp/simnumfile)                                                                                         
		if [ "$simnum" = "1" ]                                                                                                
		then
			ComPort=$(uci get modem.CWAN1_0.ComPortSymLink)
			
			Signal_strength $ComPort 1
		else
			ComPort=$(uci get modem.CWAN1_1.ComPortSymLink)
			
			Signal_strength $ComPort 1
		fi
	else
		ComPort=$(uci get modem.CWAN1.ComPortSymLink)
		
		Signal_strength $ComPort 1
	fi
	
#Exit if cellular is not enabled.
else
	exit 0
fi

exit 0
